"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { useSupabase } from "./supabase-provider"
import { useAuth } from "@/contexts/auth-context"
import { Bug, ChevronDown, ChevronUp, RefreshCw } from "lucide-react"

export function DebugInfo() {
  const { supabase } = useSupabase()
  const { user, loading } = useAuth()
  const [isOpen, setIsOpen] = useState(false)
  const [supabaseInfo, setSupabaseInfo] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  const fetchSupabaseInfo = async () => {
    setIsLoading(true)
    try {
      // Получение информации о сессии
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

      // Получение информации о таблицах
      const tableNames = [
        "Users",
        "users",
        "Patients",
        "patients",
        "Doctors",
        "doctors",
        "Appointments",
        "appointments",
        "MedicalRecords",
        "medicalrecords",
      ]

      const tableInfo = {}

      for (const tableName of tableNames) {
        try {
          const { count, error } = await supabase.from(tableName).select("*", { count: "exact", head: true })
          if (!error) {
            tableInfo[tableName] = { exists: true, count }
          } else {
            tableInfo[tableName] = { exists: false, error: error.message }
          }
        } catch (e) {
          tableInfo[tableName] = { exists: false, error: e.message }
        }
      }

      setSupabaseInfo({
        session: sessionData,
        sessionError: sessionError?.message,
        tables: tableInfo,
        timestamp: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Ошибка при получении отладочной информации:", error)
      setSupabaseInfo({
        error: error.message,
        timestamp: new Date().toISOString(),
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="border-dashed border-yellow-300 bg-yellow-50">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center">
          <Bug className="h-4 w-4 mr-2 text-yellow-600" />
          Отладочная информация
        </CardTitle>
        <CardDescription className="text-xs text-yellow-700">Информация для разработчиков и отладки</CardDescription>
      </CardHeader>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <Button variant="ghost" size="sm" className="w-full flex justify-between text-yellow-800">
            {isOpen ? "Скрыть детали" : "Показать детали"}
            {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="pt-2 pb-0">
            <div className="space-y-2 text-xs">
              <div>
                <span className="font-medium">Статус аутентификации:</span>{" "}
                {loading ? "Загрузка..." : user ? "Авторизован" : "Не авторизован"}
              </div>
              {user && (
                <div>
                  <span className="font-medium">Пользователь:</span> {user.full_name} (ID: {user.id}, Роль: {user.role})
                </div>
              )}
              <div>
                <span className="font-medium">URL Supabase:</span> {process.env.NEXT_PUBLIC_SUPABASE_URL || "Не задан"}
              </div>

              {supabaseInfo && (
                <div className="mt-2 space-y-2">
                  <div>
                    <span className="font-medium">Время проверки:</span>{" "}
                    {new Date(supabaseInfo.timestamp).toLocaleString()}
                  </div>

                  {supabaseInfo.error ? (
                    <div className="text-red-600">
                      <span className="font-medium">Ошибка:</span> {supabaseInfo.error}
                    </div>
                  ) : (
                    <>
                      <div>
                        <span className="font-medium">Сессия:</span>{" "}
                        {supabaseInfo.session?.session ? "Активна" : "Отсутствует"}
                        {supabaseInfo.sessionError && (
                          <span className="text-red-600"> (Ошибка: {supabaseInfo.sessionError})</span>
                        )}
                      </div>

                      <div>
                        <span className="font-medium">Таблицы:</span>
                        <ul className="mt-1 space-y-1 pl-4">
                          {Object.entries(supabaseInfo.tables || {}).map(([tableName, info]: [string, any]) => (
                            <li key={tableName} className={info.exists ? "text-green-600" : "text-red-600"}>
                              {tableName}:{" "}
                              {info.exists ? `Существует (${info.count} записей)` : `Не существует (${info.error})`}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="pt-2">
            <Button
              variant="outline"
              size="sm"
              className="w-full text-xs"
              onClick={fetchSupabaseInfo}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-3 w-3 mr-2 animate-spin" />
                  Проверка...
                </>
              ) : (
                <>
                  <RefreshCw className="h-3 w-3 mr-2" />
                  Проверить соединение
                </>
              )}
            </Button>
          </CardFooter>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  )
}
