"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { createClient, type SupabaseClient } from "@supabase/supabase-js"

interface SupabaseContextType {
  supabase: SupabaseClient
  user: any
  loading: boolean
}

const SupabaseContext = createContext<SupabaseContextType | undefined>(undefined)

export function SupabaseProvider({ children }: { children: ReactNode }) {
  const [supabase] = useState(() => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""
    return createClient(supabaseUrl, supabaseAnonKey)
  })

  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const getUser = async () => {
      try {
        setLoading(true)

        // Получение текущей сессии
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

        if (sessionError) {
          console.error("Ошибка получения сессии:", sessionError)
          setUser(null)
          setLoading(false)
          return
        }

        if (sessionData?.session?.user) {
          const email = sessionData.session.user.email

          if (!email) {
            console.warn("Email пользователя отсутствует в сессии")
            setUser(null)
            setLoading(false)
            return
          }

          // Исправление: Проверяем обе версии имени таблицы
          let userData = null
          const userError = null

          try {
            // Сначала пробуем с заглавной буквы
            const { data: upperCaseData, error: upperCaseError } = await supabase
              .from("Users")
              .select("*")
              .eq("email", email)
              .maybeSingle()

            if (upperCaseError) {
              console.log("Попытка с заглавной буквой не удалась, пробуем строчную:", upperCaseError)
              // Затем пробуем со строчной буквы
              const { data: lowerCaseData, error: lowerCaseError } = await supabase
                .from("users")
                .select("*")
                .eq("email", email)
                .maybeSingle()

              if (lowerCaseError) {
                console.error("Ошибка получения данных пользователя:", lowerCaseError)
                userData = null
              } else {
                userData = lowerCaseData
              }
            } else {
              userData = upperCaseData
            }
          } catch (err) {
            console.error("Ошибка при запросе данных пользователя:", err)
            userData = null
          }

          setUser(userData)
        } else {
          setUser(null)
        }
      } catch (error) {
        console.error("Непредвиденная ошибка в getUser:", error)
        setUser(null)
      } finally {
        setLoading(false)
      }
    }

    getUser()

    // Настройка слушателя изменений состояния аутентификации
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === "SIGNED_IN" || event === "TOKEN_REFRESHED") {
        if (session?.user?.email) {
          try {
            // Исправление: Проверяем обе версии имени таблицы
            let userData = null

            // Сначала пробуем с заглавной буквы
            const { data: upperCaseData, error: upperCaseError } = await supabase
              .from("Users")
              .select("*")
              .eq("email", session.user.email)
              .maybeSingle()

            if (upperCaseError) {
              console.log("Попытка с заглавной буквой не удалась, пробуем строчную:", upperCaseError)
              // Затем пробуем со строчной буквы
              const { data: lowerCaseData, error: lowerCaseError } = await supabase
                .from("users")
                .select("*")
                .eq("email", session.user.email)
                .maybeSingle()

              if (lowerCaseError) {
                console.error("Ошибка получения данных пользователя:", lowerCaseError)
                userData = null
              } else {
                userData = lowerCaseData
              }
            } else {
              userData = upperCaseData
            }

            setUser(userData)
          } catch (error) {
            console.error("Ошибка при обновлении данных пользователя:", error)
            setUser(null)
          }
        }
      } else if (event === "SIGNED_OUT") {
        setUser(null)
      }
    })

    return () => {
      authListener.subscription.unsubscribe()
    }
  }, [supabase])

  return <SupabaseContext.Provider value={{ supabase, user, loading }}>{children}</SupabaseContext.Provider>
}

export function useSupabase() {
  const context = useContext(SupabaseContext)
  if (context === undefined) {
    throw new Error("useSupabase должен использоваться внутри SupabaseProvider")
  }
  return context
}
