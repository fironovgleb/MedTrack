"use client"

import { useEffect, useState } from "react"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { CheckCircle2, XCircle } from "lucide-react"

export function SupabaseConnectionTest() {
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const [message, setMessage] = useState("")

  useEffect(() => {
    const checkConnection = async () => {
      try {
        // Check if environment variables are defined
        const url = process.env.NEXT_PUBLIC_SUPABASE_URL
        const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

        if (!url || !key) {
          setStatus("error")
          setMessage("Supabase environment variables are not properly defined")
          return
        }

        // If we have the variables, we can consider it a success
        // In a real app, you might want to actually test the connection
        setStatus("success")
        setMessage("Supabase environment variables are properly loaded")
      } catch (error: any) {
        setStatus("error")
        setMessage(`Error checking Supabase connection: ${error.message}`)
      }
    }

    checkConnection()
  }, [])

  if (status === "loading") {
    return <div>Checking Supabase connection...</div>
  }

  return (
    <Alert variant={status === "success" ? "default" : "destructive"}>
      <div className="flex items-center">
        {status === "success" ? (
          <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
        ) : (
          <XCircle className="h-5 w-5 mr-2" />
        )}
        <AlertTitle>{status === "success" ? "Connection Successful" : "Connection Error"}</AlertTitle>
      </div>
      <AlertDescription>{message}</AlertDescription>
    </Alert>
  )
}
