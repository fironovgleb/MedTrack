"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Clock } from "lucide-react"
import { useSupabase } from "@/components/supabase-provider"

interface TimeSlotPickerProps {
  date: string
  doctorId: string
  onSelectTime: (time: string) => void
  selectedTime: string
}

export function TimeSlotPicker({ date, doctorId, onSelectTime, selectedTime }: TimeSlotPickerProps) {
  const { supabase } = useSupabase()
  const [availableSlots, setAvailableSlots] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [bookedSlots, setBookedSlots] = useState<string[]>([])
  const [workingHours, setWorkingHours] = useState<{ start: number; end: number }>({ start: 9, end: 18 })
  const [error, setError] = useState<string | null>(null)

  // Generate time slots based on doctor's working hours with 30-minute intervals
  useEffect(() => {
    if (!date || !doctorId) {
      setAvailableSlots([])
      return
    }

    setLoading(true)
    setError(null)

    // Fetch doctor's working hours - using default hours if not available
    const fetchDoctorWorkingHours = async () => {
      try {
        console.log("Fetching doctor information for doctor ID:", doctorId)

        // First, check if the doctors table exists and what columns it has
        const { data: tableInfo, error: tableError } = await supabase.from("doctors").select("*").limit(1)

        if (tableError) {
          console.error("Error checking doctors table:", tableError)
          // If we can't query the table at all, use default working hours
          console.log("Using default working hours (9-18)")
          return
        }

        // If the table exists but doesn't have working_hours column, use default
        if (!tableInfo || tableInfo.length === 0 || !("working_hours" in tableInfo[0])) {
          console.log("doctors table exists but no working_hours column found, using default hours")
          return
        }

        // If we got here, the table and column exist, so query for this doctor's hours
        const { data, error } = await supabase.from("doctors").select("working_hours").eq("user_id", doctorId).single()

        if (error) {
          console.error("Error fetching doctor working hours:", error)
          // Don't throw, just use default hours
          return
        }

        console.log("Doctor working hours data:", data)

        // Parse working hours if available
        if (data?.working_hours) {
          // Expected format: "9:00-18:00" or similar
          const hours = data.working_hours.split("-")
          if (hours.length === 2) {
            const startHour = Number.parseInt(hours[0].split(":")[0])
            const endHour = Number.parseInt(hours[1].split(":")[0])

            if (!isNaN(startHour) && !isNaN(endHour)) {
              setWorkingHours({ start: startHour, end: endHour })
            }
          }
        }
      } catch (error) {
        console.error("Error in fetchDoctorWorkingHours:", error)
        // Don't set error state, just use default hours
      }
    }

    // Fetch booked slots
    const fetchBookedSlots = async () => {
      try {
        const selectedDate = new Date(date)
        // Set time to 00:00:00
        selectedDate.setHours(0, 0, 0, 0)

        const nextDay = new Date(selectedDate)
        nextDay.setDate(nextDay.getDate() + 1)

        console.log("Fetching booked slots for date range:", selectedDate.toISOString(), "to", nextDay.toISOString())

        // Check if appointments table exists
        const { data, error } = await supabase
          .from("appointments")
          .select("appointment_time")
          .eq("doctor_id", doctorId)
          .eq("status", "scheduled")
          .gte("appointment_time", selectedDate.toISOString())
          .lt("appointment_time", nextDay.toISOString())

        if (error) {
          console.error("Error fetching booked slots:", error)
          // Continue with empty booked slots
          return []
        }

        console.log("Booked slots data:", data)

        // Extract the time part from the appointment_time
        const booked = data.map((item) => {
          const time = new Date(item.appointment_time)
          return `${time.getHours().toString().padStart(2, "0")}:${time.getMinutes().toString().padStart(2, "0")}`
        })

        setBookedSlots(booked)
      } catch (error) {
        console.error("Error in fetchBookedSlots:", error)
        // Continue with empty booked slots
      }
    }

    // Generate all possible time slots based on working hours
    const generateTimeSlots = () => {
      const slots = []

      for (let hour = workingHours.start; hour < workingHours.end; hour++) {
        slots.push(`${hour.toString().padStart(2, "0")}:00`)
        slots.push(`${hour.toString().padStart(2, "0")}:30`)
      }

      // Filter out past time slots if the date is today
      const today = new Date()
      const selectedDate = new Date(date)

      if (selectedDate.toDateString() === today.toDateString()) {
        const currentHour = today.getHours()
        const currentMinute = today.getMinutes()

        return slots.filter((slot) => {
          const [slotHour, slotMinute] = slot.split(":").map(Number)
          return slotHour > currentHour || (slotHour === currentHour && slotMinute > currentMinute + 30) // Add 30 min buffer
        })
      }

      return slots
    }

    // Run all fetches and generate slots
    const initializeTimeSlots = async () => {
      try {
        await fetchDoctorWorkingHours()
        await fetchBookedSlots()
        setAvailableSlots(generateTimeSlots())
      } catch (error) {
        console.error("Error initializing time slots:", error)
        setError("Не удалось загрузить доступные слоты времени")
      } finally {
        setLoading(false)
      }
    }

    initializeTimeSlots()
  }, [date, doctorId, supabase, workingHours.start, workingHours.end])

  const isSlotBooked = (slot: string) => {
    return bookedSlots.includes(slot)
  }

  // Check if a slot is in the past
  const isSlotInPast = (slot: string) => {
    const today = new Date()
    const selectedDate = new Date(date)

    if (selectedDate < today && selectedDate.toDateString() !== today.toDateString()) {
      return true
    }

    if (selectedDate.toDateString() === today.toDateString()) {
      const [slotHour, slotMinute] = slot.split(":").map(Number)
      const currentHour = today.getHours()
      const currentMinute = today.getMinutes()

      return slotHour < currentHour || (slotHour === currentHour && slotMinute <= currentMinute)
    }

    return false
  }

  return (
    <Card>
      <CardContent className="p-4">
        {loading ? (
          <div className="flex justify-center p-4">
            <div className="animate-spin h-6 w-6 border-2 border-blue-500 rounded-full border-t-transparent"></div>
          </div>
        ) : error ? (
          <div className="text-center text-red-500 p-4">{error}</div>
        ) : availableSlots.length > 0 ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
            {availableSlots.map((slot) => {
              const isBooked = isSlotBooked(slot)
              const isPast = isSlotInPast(slot)
              const isDisabled = isBooked || isPast

              return (
                <Button
                  key={slot}
                  variant={selectedTime === slot ? "default" : "outline"}
                  size="sm"
                  className={`flex items-center justify-center ${isDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
                  onClick={() => !isDisabled && onSelectTime(slot)}
                  disabled={isDisabled}
                >
                  <Clock className="h-3 w-3 mr-1" />
                  {slot}
                </Button>
              )
            })}
          </div>
        ) : (
          <div className="text-center text-gray-500 p-4">
            {!date || !doctorId
              ? "Выберите дату и врача для просмотра доступных слотов"
              : "Нет доступных слотов на выбранную дату"}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
