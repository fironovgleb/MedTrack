"use client"

import { Calendar, Clock, MapPin, User, ChevronRight, X } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { formatAppointmentDate, formatAppointmentTime, getAppointmentStatusColor } from "@/lib/appointment-utils"

interface AppointmentCardProps {
  appointment: {
    id: number
    appointment_time: string
    status: string
    doctor?: {
      specialization: string
      office: string
      user: {
        full_name: string
      }
    }
    patient?: {
      user: {
        full_name: string
      }
    }
  }
  userRole: "patient" | "doctor"
  onViewDetails: (id: number) => void
  onCancel?: (id: number) => void
}

export function AppointmentCard({ appointment, userRole, onViewDetails, onCancel }: AppointmentCardProps) {
  const isPatient = userRole === "patient"
  const name = isPatient ? appointment.doctor?.user?.full_name : appointment.patient?.user?.full_name

  const specialization = isPatient ? appointment.doctor?.specialization : null

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className="flex flex-col sm:flex-row">
          <div className={`p-4 sm:p-6 flex-1 ${appointment.status === "canceled" ? "opacity-70" : ""}`}>
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">{name}</span>
                </div>
                {specialization && <div className="text-sm text-muted-foreground mt-1">{specialization}</div>}

                <div className="flex flex-wrap gap-x-4 gap-y-2 mt-3">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span className="text-sm">{formatAppointmentDate(appointment.appointment_time)}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span className="text-sm">{formatAppointmentTime(appointment.appointment_time)}</span>
                  </div>
                  {isPatient && appointment.doctor?.office && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                      <span className="text-sm">Кабинет {appointment.doctor.office}</span>
                    </div>
                  )}
                </div>
              </div>

              <div
                className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${getAppointmentStatusColor(
                  appointment.status,
                )}`}
              >
                {appointment.status === "scheduled" && "Запланирован"}
                {appointment.status === "completed" && "Завершен"}
                {appointment.status === "canceled" && "Отменен"}
              </div>
            </div>
          </div>

          <div className="flex sm:flex-col border-t sm:border-t-0 sm:border-l divide-x sm:divide-x-0 sm:divide-y">
            <Button
              variant="ghost"
              className="flex-1 rounded-none h-12 px-3 sm:px-4"
              onClick={() => onViewDetails(appointment.id)}
            >
              <span className="sr-only sm:not-sr-only sm:mr-2">Детали</span>
              <ChevronRight className="h-4 w-4" />
            </Button>
            {onCancel && appointment.status === "scheduled" && (
              <Button
                variant="ghost"
                className="flex-1 rounded-none h-12 px-3 sm:px-4 text-red-600 hover:text-red-700 hover:bg-red-50"
                onClick={() => onCancel(appointment.id)}
              >
                <span className="sr-only sm:not-sr-only sm:mr-2">Отменить</span>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
