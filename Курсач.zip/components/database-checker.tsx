"use client"

import { useState, useEffect } from "react"
import { useSupabase } from "./supabase-provider"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { CheckCircle, AlertTriangle, XCircle, Database } from "lucide-react"

interface TableStatus {
  name: string
  exists: boolean
  error?: string
}

export function DatabaseChecker() {
  const { supabase } = useSupabase()
  const [loading, setLoading] = useState(true)
  const [tables, setTables] = useState<TableStatus[]>([])
  const [showDetails, setShowDetails] = useState(false)
  const [overallStatus, setOverallStatus] = useState<"success" | "warning" | "error">("warning")

  useEffect(() => {
    checkDatabase()
  }, [])

  const checkDatabase = async () => {
    setLoading(true)
    const requiredTables = [
      { name: "Users", altName: "users" },
      { name: "Patients", altName: "patients" },
      { name: "Doctors", altName: "doctors" },
      { name: "Appointments", altName: "appointments" },
      { name: "MedicalRecords", altName: "medicalrecords" },
      { name: "AuditLogs", altName: "auditlogs" },
    ]

    const tableStatuses: TableStatus[] = []
    let hasErrors = false
    let allTablesExist = true

    for (const table of requiredTables) {
      try {
        // Проверяем основное имя таблицы
        const { error: mainError } = await supabase.from(table.name).select("*").limit(1)

        if (mainError) {
          // Если основное имя не работает, проверяем альтернативное
          const { error: altError } = await supabase.from(table.altName).select("*").limit(1)

          if (altError) {
            // Ни одно из имен не работает
            tableStatuses.push({
              name: `${table.name} / ${table.altName}`,
              exists: false,
              error: altError.message,
            })
            allTablesExist = false
          } else {
            // Альтернативное имя работает
            tableStatuses.push({
              name: table.altName,
              exists: true,
            })
          }
        } else {
          // Основное имя работает
          tableStatuses.push({
            name: table.name,
            exists: true,
          })
        }
      } catch (error: any) {
        tableStatuses.push({
          name: `${table.name} / ${table.altName}`,
          exists: false,
          error: error.message,
        })
        hasErrors = true
        allTablesExist = false
      }
    }

    setTables(tableStatuses)
    setOverallStatus(allTablesExist ? "success" : hasErrors ? "error" : "warning")
    setLoading(false)
  }

  if (loading) {
    return (
      <Alert className="bg-blue-50 border-blue-200">
        <Database className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800">Проверка базы данных...</AlertTitle>
        <AlertDescription className="text-blue-700">
          Пожалуйста, подождите, идет проверка структуры базы данных.
        </AlertDescription>
      </Alert>
    )
  }

  return (
    <>
      <Alert
        className={
          overallStatus === "success"
            ? "bg-green-50 border-green-200"
            : overallStatus === "error"
              ? "bg-red-50 border-red-200"
              : "bg-yellow-50 border-yellow-200"
        }
      >
        {overallStatus === "success" ? (
          <CheckCircle className="h-4 w-4 text-green-600" />
        ) : overallStatus === "error" ? (
          <XCircle className="h-4 w-4 text-red-600" />
        ) : (
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
        )}
        <AlertTitle
          className={
            overallStatus === "success"
              ? "text-green-800"
              : overallStatus === "error"
                ? "text-red-800"
                : "text-yellow-800"
          }
        >
          {overallStatus === "success"
            ? "База данных в порядке"
            : overallStatus === "error"
              ? "Проблемы с базой данных"
              : "Предупреждение о базе данных"}
        </AlertTitle>
        <AlertDescription
          className={
            overallStatus === "success"
              ? "text-green-700"
              : overallStatus === "error"
                ? "text-red-700"
                : "text-yellow-700"
          }
        >
          {overallStatus === "success"
            ? "Все необходимые таблицы существуют и доступны."
            : overallStatus === "error"
              ? "Обнаружены ошибки при проверке базы данных. Некоторые функции могут не работать."
              : "Некоторые таблицы не найдены. Система попытается использовать альтернативные имена."}
          <Button
            variant="link"
            className={
              overallStatus === "success"
                ? "text-green-800"
                : overallStatus === "error"
                  ? "text-red-800"
                  : "text-yellow-800"
            }
            onClick={() => setShowDetails(!showDetails)}
          >
            {showDetails ? "Скрыть детали" : "Показать детали"}
          </Button>
        </AlertDescription>
      </Alert>

      {showDetails && (
        <div className="mt-4 border rounded-md p-4 bg-gray-50">
          <h3 className="font-medium mb-2">Статус таблиц базы данных:</h3>
          <ul className="space-y-2">
            {tables.map((table, index) => (
              <li key={index} className="flex items-start">
                {table.exists ? (
                  <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 mr-2" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-600 mt-0.5 mr-2" />
                )}
                <div>
                  <span className={table.exists ? "text-green-700" : "text-red-700"}>
                    {table.name}: {table.exists ? "Доступна" : "Не найдена"}
                  </span>
                  {table.error && <p className="text-sm text-red-600 mt-1">{table.error}</p>}
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  )
}
