interface LoadingSkeletonProps {
  count?: number
  type?: "card" | "list" | "stats"
}

export function LoadingSkeleton({ count = 3, type = "card" }: LoadingSkeletonProps) {
  if (type === "stats") {
    return <div className="h-8 w-16 bg-muted animate-pulse rounded" />
  }

  if (type === "list") {
    return (
      <div className="space-y-4">
        {[...Array(count)].map((_, i) => (
          <div key={i} className="flex flex-col space-y-2">
            <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
            <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
            <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {[...Array(count)].map((_, i) => (
        <div key={i} className="flex flex-col space-y-2 p-4 border rounded-lg">
          <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
          <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
          <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
        </div>
      ))}
    </div>
  )
}
