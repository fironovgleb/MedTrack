import { Calendar, Clock } from "lucide-react"
import { formatDate, formatTime } from "@/lib/utils"

interface DateTimeDisplayProps {
  date: string
  showTime?: boolean
  className?: string
}

export function DateTimeDisplay({ date, showTime = true, className }: DateTimeDisplayProps) {
  return (
    <div className={`flex items-center text-sm text-muted-foreground ${className || ""}`}>
      <Calendar className="h-4 w-4 mr-1" />
      <span>{formatDate(date)}</span>
      {showTime && (
        <>
          <Clock className="h-4 w-4 ml-2 mr-1" />
          <span>{formatTime(date)}</span>
        </>
      )}
    </div>
  )
}
