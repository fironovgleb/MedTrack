import { Badge } from "@/components/ui/badge"
import { getAppointmentStatusText } from "@/lib/utils"

interface StatusBadgeProps {
  status: string
}

export function StatusBadge({ status }: StatusBadgeProps) {
  switch (status) {
    case "scheduled":
      return (
        <Badge variant="outline" className="text-blue-500 border-blue-500">
          {getAppointmentStatusText(status)}
        </Badge>
      )
    case "completed":
      return (
        <Badge variant="outline" className="text-green-500 border-green-500">
          {getAppointmentStatusText(status)}
        </Badge>
      )
    case "canceled":
      return (
        <Badge variant="outline" className="text-red-500 border-red-500">
          {getAppointmentStatusText(status)}
        </Badge>
      )
    default:
      return <Badge variant="outline">{getAppointmentStatusText(status)}</Badge>
  }
}
