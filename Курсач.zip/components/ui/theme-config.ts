// Simple theme configuration
export const themeConfig = {
  colors: {
    primary: "blue",
    secondary: "gray",
    accent: "cyan",
  },
  borderRadius: "md",
  fontSizes: {
    small: "0.875rem",
    medium: "1rem",
    large: "1.25rem",
    xlarge: "1.5rem",
  },
}
