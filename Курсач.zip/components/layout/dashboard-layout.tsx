"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"
import Link from "next/link"
import {
  Activity,
  BarChart3,
  Calendar,
  ChevronsLeft,
  ChevronsRight,
  ClipboardList,
  FileText,
  LogOut,
  Menu,
  Settings,
  User,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { useMediaQuery } from "@/hooks/use-media-query"

interface MenuItem {
  title: string
  href: string
  icon: React.ReactNode
}

interface DashboardLayoutProps {
  children: React.ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout, loading } = useAuth()
  const { toast } = useToast()
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const isMobile = useMediaQuery("(max-width: 768px)")

  useEffect(() => {
    if (isMobile) {
      setCollapsed(true)
    }
  }, [isMobile])

  useEffect(() => {
    if (!loading) {
      if (!user) {
        toast({
          title: "Не авторизован",
          description: "Пожалуйста, войдите в систему",
          variant: "destructive",
        })
        router.push("/login")
      } else if (pathname) {
        // Улучшенная проверка доступа к разделам
        const pathSegments = pathname.split("/").filter(Boolean)
        if (pathSegments.length > 0 && pathSegments[0] !== user.role) {
          toast({
            title: "Доступ запрещен",
            description: "У вас нет доступа к этому разделу",
            variant: "destructive",
          })
          router.push(`/${user.role}/dashboard`)
        }
      }
    }
  }, [user, loading, router, toast, pathname])

  if (loading || !user) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-blue-600 border-t-transparent rounded-full"></div>
      </div>
    )
  }

  // Получение пунктов меню в зависимости от роли пользователя
  const getMenuItems = (): MenuItem[] => {
    switch (user.role) {
      case "admin":
        return [
          {
            title: "Панель управления",
            href: "/admin/dashboard",
            icon: <BarChart3 className="h-5 w-5" />,
          },
          {
            title: "Пользователи",
            href: "/admin/users",
            icon: <Users className="h-5 w-5" />,
          },
          {
            title: "Аудит",
            href: "/admin/audit",
            icon: <Activity className="h-5 w-5" />,
          },
          {
            title: "Настройки",
            href: "/admin/settings",
            icon: <Settings className="h-5 w-5" />,
          },
        ]
      case "doctor":
        return [
          {
            title: "Панель управления",
            href: "/doctor/dashboard",
            icon: <BarChart3 className="h-5 w-5" />,
          },
          {
            title: "Пациенты",
            href: "/doctor/patients",
            icon: <Users className="h-5 w-5" />,
          },
          {
            title: "Расписание",
            href: "/doctor/schedule",
            icon: <Calendar className="h-5 w-5" />,
          },
          {
            title: "Консультации",
            href: "/doctor/appointments",
            icon: <ClipboardList className="h-5 w-5" />,
          },
          {
            title: "Медкарты",
            href: "/doctor/records",
            icon: <FileText className="h-5 w-5" />,
          },
          {
            title: "Профиль",
            href: "/doctor/profile",
            icon: <User className="h-5 w-5" />,
          },
        ]
      case "patient":
        return [
          {
            title: "Панель управления",
            href: "/patient/dashboard",
            icon: <BarChart3 className="h-5 w-5" />,
          },
          {
            title: "Записи на приём",
            href: "/patient/appointments",
            icon: <Calendar className="h-5 w-5" />,
          },
          {
            title: "Медицинская карта",
            href: "/patient/records",
            icon: <FileText className="h-5 w-5" />,
          },
          {
            title: "Профиль",
            href: "/patient/profile",
            icon: <User className="h-5 w-5" />,
          },
        ]
      default:
        return []
    }
  }

  const menuItems = getMenuItems()

  const handleLogout = async () => {
    try {
      await logout()
      toast({
        title: "Выход выполнен",
        description: "Вы успешно вышли из системы",
      })
    } catch (error) {
      console.error("Ошибка при выходе:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось выйти из системы",
        variant: "destructive",
      })
      // Принудительное перенаправление на страницу входа в случае ошибки
      router.push("/login")
    }
  }

  const Sidebar = () => (
    <div
      className={`flex h-screen flex-col border-r bg-background transition-all duration-300 ${
        collapsed ? "w-16" : "w-64"
      }`}
    >
      <div className="flex h-14 items-center border-b px-3 py-4">
        {!collapsed && (
          <Link href="/" className="flex items-center">
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
              MedTrack
            </h1>
          </Link>
        )}
        <Button
          variant="ghost"
          size="icon"
          className={`${collapsed ? "mx-auto" : "ml-auto"}`}
          onClick={() => setCollapsed(!collapsed)}
        >
          {collapsed ? <ChevronsRight className="h-5 w-5" /> : <ChevronsLeft className="h-5 w-5" />}
        </Button>
      </div>
      <nav className="flex-1 overflow-auto py-4">
        <ul className="space-y-2 px-2">
          {menuItems.map((item, index) => (
            <li key={index}>
              <Link
                href={item.href}
                className={`flex items-center rounded-md px-3 py-2 text-sm ${
                  pathname === item.href
                    ? "bg-muted text-foreground"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                } ${collapsed ? "justify-center" : ""}`}
              >
                {item.icon}
                {!collapsed && <span className="ml-3">{item.title}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      <div className="flex items-center border-t p-3">
        <div className={`flex items-center ${collapsed ? "justify-center" : "space-x-3"}`}>
          <Avatar className="h-8 w-8">
            <AvatarImage
              src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.full_name}`}
              alt={user.full_name}
            />
            <AvatarFallback>
              {user.full_name
                .split(" ")
                .map((n: string) => n[0])
                .join("")
                .toUpperCase()
                .substring(0, 2)}
            </AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-medium truncate">{user.full_name}</span>
              <span className="text-xs text-muted-foreground truncate">{user.email}</span>
            </div>
          )}
        </div>
        {!collapsed && (
          <Button variant="ghost" size="icon" className="ml-auto" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
          </Button>
        )}
        {collapsed && (
          <Button variant="ghost" size="icon" className="mx-auto mt-2" onClick={handleLogout}>
            <LogOut className="h-5 w-5" />
          </Button>
        )}
      </div>
    </div>
  )

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Настольная версия боковой панели */}
      {!isMobile && <Sidebar />}

      {/* Мобильная версия боковой панели */}
      {isMobile && (
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" className="fixed left-4 top-4 z-50 md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0">
            <div className="w-full">
              <Sidebar />
            </div>
          </SheetContent>
        </Sheet>
      )}

      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-14 items-center border-b bg-background px-4 lg:px-6">
          {isMobile && (
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500 ml-10">
              MedTrack
            </h1>
          )}
        </header>
        <main className="flex-1 overflow-auto bg-background p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
