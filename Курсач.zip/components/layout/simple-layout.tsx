"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { LogOut, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/contexts/auth-context"

interface SimpleLayoutProps {
  children: React.ReactNode
}

export function SimpleLayout({ children }: SimpleLayoutProps) {
  const pathname = usePathname()
  const { user, logout } = useAuth()
  const [menuOpen, setMenuOpen] = useState(false)

  if (!user) {
    return <div className="p-4">{children}</div>
  }

  // Определение навигации на основе роли пользователя
  const getNavItems = () => {
    const commonItems = [
      { title: "Панель управления", href: `/${user.role}/dashboard` },
      { title: "Профиль", href: `/${user.role}/profile` },
    ]

    switch (user.role) {
      case "admin":
        return [
          ...commonItems,
          { title: "Пользователи", href: "/admin/users" },
          { title: "Аудит", href: "/admin/audit" },
        ]
      case "doctor":
        return [
          ...commonItems,
          { title: "Пациенты", href: "/doctor/patients" },
          { title: "Приёмы", href: "/doctor/appointments" },
          { title: "Записи", href: "/doctor/records" },
        ]
      case "patient":
        return [
          ...commonItems,
          { title: "Записи на приём", href: "/patient/appointments" },
          { title: "Медицинская карта", href: "/patient/records" },
        ]
      default:
        return commonItems
    }
  }

  const navItems = getNavItems()

  return (
    <div className="min-h-screen flex flex-col">
      {/* Простой заголовок */}
      <header className="bg-white border-b p-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/" className="text-xl font-bold text-blue-600">
            MedTrack
          </Link>
        </div>

        {/* Кнопка мобильного меню */}
        <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X /> : <Menu />}
        </Button>

        {/* Навигация для десктопа */}
        <nav className="hidden md:flex items-center space-x-4">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`px-3 py-2 text-sm rounded-md transition-colors ${
                pathname === item.href ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-gray-100"
              }`}
            >
              {item.title}
            </Link>
          ))}
          <Button variant="ghost" size="sm" onClick={logout} className="text-gray-600">
            <LogOut className="h-4 w-4 mr-2" />
            Выйти
          </Button>
        </nav>
      </header>

      {/* Мобильная навигация */}
      {menuOpen && (
        <div className="md:hidden bg-white border-b">
          <nav className="flex flex-col p-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`px-3 py-2 text-sm rounded-md mb-1 ${
                  pathname === item.href ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-gray-100"
                }`}
                onClick={() => setMenuOpen(false)}
              >
                {item.title}
              </Link>
            ))}
            <Button variant="ghost" size="sm" onClick={logout} className="text-gray-600 justify-start px-3">
              <LogOut className="h-4 w-4 mr-2" />
              Выйти
            </Button>
          </nav>
        </div>
      )}

      {/* Основное содержимое */}
      <main className="flex-1 p-4 bg-gray-50">{children}</main>
    </div>
  )
}
