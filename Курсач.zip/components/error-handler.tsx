"use client"

import { useEffect, useState } from "react"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

interface ErrorHandlerProps {
  error?: Error | null
  resetErrorBoundary?: () => void
  userMessage?: string
}

export function ErrorHandler({
  error,
  resetErrorBoundary,
  userMessage = "Произошла ошибка. Пожалуйста, попробуйте еще раз.",
}: ErrorHandlerProps) {
  const [showDetails, setShowDetails] = useState(false)
  const [isProduction, setIsProduction] = useState(true)

  useEffect(() => {
    // В продакшене не показываем технические детали
    setIsProduction(process.env.NODE_ENV === "production")
  }, [])

  return (
    <Alert variant="destructive" className="my-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Ошибка</AlertTitle>
      <AlertDescription>
        <p>{userMessage}</p>

        {!isProduction && error && (
          <>
            <Button variant="outline" size="sm" className="mt-2" onClick={() => setShowDetails(!showDetails)}>
              {showDetails ? "Скрыть детали" : "Показать детали"}
            </Button>

            {showDetails && (
              <div className="mt-2 p-2 bg-muted/50 rounded text-xs font-mono overflow-auto max-h-40">
                <p className="font-semibold">
                  {error.name}: {error.message}
                </p>
                <pre>{error.stack}</pre>
              </div>
            )}
          </>
        )}

        {resetErrorBoundary && (
          <Button variant="outline" size="sm" className="mt-2" onClick={resetErrorBoundary}>
            Попробовать снова
          </Button>
        )}
      </AlertDescription>
    </Alert>
  )
}
