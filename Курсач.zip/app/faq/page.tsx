import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, HelpCircle } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FaqPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex items-center justify-between h-16 mx-auto px-4">
          <Link href="/" className="flex items-center">
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
              MedTrack
            </h1>
          </Link>
          <div className="space-x-4">
            <Link href="/login">
              <Button variant="outline">Войти</Button>
            </Link>
            <Link href="/register">
              <Button>Регистрация</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-12">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Вернуться на главную
          </Link>

          <div className="max-w-4xl mx-auto">
            <div className="flex items-center mb-8">
              <HelpCircle className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-4xl font-bold">Часто задаваемые вопросы</h1>
            </div>

            <p className="text-xl text-muted-foreground mb-12">
              Здесь вы найдете ответы на наиболее распространенные вопросы о платформе MedTrack. Если вы не нашли ответ
              на свой вопрос, пожалуйста, свяжитесь с нами.
            </p>

            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-semibold mb-4">Общие вопросы</h2>
                <Accordion type="single" collapsible className="border rounded-lg">
                  <AccordionItem value="item-1">
                    <AccordionTrigger className="px-4">Что такое MedTrack?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      MedTrack — это современная платформа для управления медицинскими записями и консультациями. Она
                      позволяет пациентам хранить свою медицинскую историю, записываться на приём к врачам и получать
                      доступ к своим медицинским данным в любое время. Для врачей платформа предоставляет удобные
                      инструменты для ведения медицинской документации и управления расписанием приёмов.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-2">
                    <AccordionTrigger className="px-4">Кто может пользоваться платформой?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Платформой могут пользоваться как пациенты, так и медицинские работники. Для пациентов доступны
                      функции записи на приём и просмотра медицинской карты. Врачи могут вести медицинские записи,
                      управлять расписанием и взаимодействовать с пациентами. Также есть административный доступ для
                      управления системой.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-3">
                    <AccordionTrigger className="px-4">Сколько стоит использование платформы?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Базовый функционал платформы доступен бесплатно для всех пользователей. Для медицинских учреждений
                      и врачей доступны расширенные планы с дополнительными возможностями. Подробную информацию о
                      тарифах можно получить, связавшись с нашей службой поддержки.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              <div>
                <h2 className="text-2xl font-semibold mb-4">Регистрация и вход</h2>
                <Accordion type="single" collapsible className="border rounded-lg">
                  <AccordionItem value="item-4">
                    <AccordionTrigger className="px-4">Как зарегистрироваться на платформе?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Для регистрации нажмите кнопку "Регистрация" в верхнем меню сайта. Выберите тип аккаунта (пациент
                      или врач) и заполните необходимые поля. После заполнения формы вы получите подтверждение на
                      указанный email. Перейдите по ссылке в письме для активации аккаунта.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-5">
                    <AccordionTrigger className="px-4">Что делать, если я забыл пароль?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      На странице входа нажмите на ссылку "Забыли пароль?". Введите email, указанный при регистрации, и
                      вы получите инструкции по восстановлению пароля. Если вы не получили письмо, проверьте папку
                      "Спам" или обратитесь в службу поддержки.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-6">
                    <AccordionTrigger className="px-4">Как изменить данные в профиле?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      После входа в систему перейдите в раздел "Профиль" в личном кабинете. Нажмите кнопку
                      "Редактировать" и внесите необходимые изменения. После завершения редактирования нажмите
                      "Сохранить" для применения изменений.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              <div>
                <h2 className="text-2xl font-semibold mb-4">Для пациентов</h2>
                <Accordion type="single" collapsible className="border rounded-lg">
                  <AccordionItem value="item-7">
                    <AccordionTrigger className="px-4">Как записаться на приём к врачу?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      После входа в систему перейдите в раздел "Записи на приём" и нажмите кнопку "Новая запись".
                      Выберите специализацию врача, затем конкретного специалиста, дату и время приёма. Подтвердите
                      запись, и она появится в вашем личном кабинете.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-8">
                    <AccordionTrigger className="px-4">Как отменить или перенести запись на приём?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      В разделе "Записи на приём" найдите нужную запись и нажмите кнопку "Отменить" или "Перенести". При
                      отмене запись будет удалена из вашего расписания. При переносе вам будет предложено выбрать новую
                      дату и время приёма.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-9">
                    <AccordionTrigger className="px-4">Как получить доступ к медицинской карте?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Медицинская карта доступна в личном кабинете пациента в разделе "Медицинская карта". Там вы
                      найдете все ваши медицинские записи, диагнозы и назначения, сделанные врачами. Вы можете
                      просматривать записи по дате или фильтровать их по врачу или диагнозу.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              <div>
                <h2 className="text-2xl font-semibold mb-4">Для врачей</h2>
                <Accordion type="single" collapsible className="border rounded-lg">
                  <AccordionItem value="item-10">
                    <AccordionTrigger className="px-4">Как управлять расписанием приёмов?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      В личном кабинете врача перейдите в раздел "Расписание". Здесь вы можете просматривать
                      запланированные приёмы, отмечать их как завершенные или отменять. Также вы можете настроить свое
                      рабочее время и дни приёма.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-11">
                    <AccordionTrigger className="px-4">Как создать медицинскую запись для пациента?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      После завершения приёма перейдите в раздел "Медицинские записи" и нажмите "Новая запись". Выберите
                      пациента из списка, заполните информацию о диагнозе, назначенном лечении и рекомендациях.
                      Сохраните запись, и она будет доступна как вам, так и пациенту.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-12">
                    <AccordionTrigger className="px-4">Как просмотреть историю пациента?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      В разделе "Пациенты" найдите нужного пациента и перейдите на его страницу. Там вы увидите полную
                      историю медицинских записей, созданных вами для этого пациента. Вы можете фильтровать записи по
                      дате или диагнозу для удобства поиска.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>

              <div>
                <h2 className="text-2xl font-semibold mb-4">Безопасность и конфиденциальность</h2>
                <Accordion type="single" collapsible className="border rounded-lg">
                  <AccordionItem value="item-13">
                    <AccordionTrigger className="px-4">Как защищены мои данные?</AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Мы используем современные технологии шифрования для защиты всех данных на платформе. Доступ к
                      медицинской информации строго контролируется и предоставляется только авторизованным
                      пользователям. Все соединения защищены протоколом SSL, а данные хранятся на защищенных серверах.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-14">
                    <AccordionTrigger className="px-4">
                      Кто имеет доступ к моей медицинской информации?
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Доступ к вашей медицинской информации имеете вы и те врачи, которые создали соответствующие
                      записи. Администраторы системы имеют ограниченный доступ только для технического обслуживания. Мы
                      не передаем ваши данные третьим лицам без вашего явного согласия.
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-15">
                    <AccordionTrigger className="px-4">
                      Соответствует ли платформа требованиям законодательства?
                    </AccordionTrigger>
                    <AccordionContent className="px-4 pb-4">
                      Да, наша платформа полностью соответствует требованиям законодательства РФ в области защиты
                      персональных данных и медицинской информации. Мы регулярно проводим аудит безопасности и обновляем
                      наши системы в соответствии с новыми требованиями.
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            </div>

            <div className="mt-12 text-center">
              <p className="text-lg mb-4">Не нашли ответ на свой вопрос?</p>
              <Link href="/contact">
                <Button className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600">
                  Связаться с нами
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Link href="/" className="flex items-center">
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
                  MedTrack
                </h1>
              </Link>
              <p className="mt-4 text-muted-foreground">Управляйте медицинскими записями и консультациями эффективно</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Ссылки</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                    О нас
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                    Контакты
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Правовая информация</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                    Политика конфиденциальности
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                    Условия использования
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} MedTrack. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
