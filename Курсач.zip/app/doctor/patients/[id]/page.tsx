"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Calendar, FileText, Mail, MapPin, Phone, Plus, User } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"

interface PatientInfo {
  user_id: number
  birth_date: string | null
  gender: string | null
  insurance_number: string | null
  address: string | null
  user: {
    full_name: string
    email: string
    phone: string | null
  }
}

interface MedicalRecord {
  id: number
  visit_date: string
  diagnosis: string
  treatment: string
}

export default function PatientProfile() {
  const router = useRouter()
  const params = useParams()
  const patientId = params.id as string

  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [patientInfo, setPatientInfo] = useState<PatientInfo | null>(null)
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!loading && user && user.role === "doctor" && patientId) {
      fetchPatientData()
    }
  }, [user, loading, patientId])

  const fetchPatientData = async () => {
    setIsLoading(true)
    try {
      // Получение информации о пациенте
      const { data: patientData, error: patientError } = await supabase
        .from("Patients")
        .select(`
          user_id,
          birth_date,
          gender,
          insurance_number,
          address,
          user:Users(
            full_name,
            email,
            phone
          )
        `)
        .eq("user_id", patientId)
        .single()

      if (patientError) throw patientError
      setPatientInfo(patientData)

      // Получение медицинских записей пациента от этого врача
      const { data: recordsData, error: recordsError } = await supabase
        .from("MedicalRecords")
        .select(`
          id,
          visit_date,
          diagnosis,
          treatment
        `)
        .eq("patient_id", patientId)
        .eq("doctor_id", user.id)
        .order("visit_date", { ascending: false })
        .limit(5)

      if (recordsError) throw recordsError
      setMedicalRecords(recordsData || [])
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить данные пациента",
        variant: "destructive",
      })
      router.push("/doctor/patients")
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Не указана"
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const getGenderText = (gender: string | null) => {
    if (!gender) return "Не указан"
    switch (gender) {
      case "male":
        return "Мужской"
      case "female":
        return "Женский"
      default:
        return "Другой"
    }
  }

  const getAgeFromBirthDate = (birthDate: string | null) => {
    if (!birthDate) return "Не указан"

    const today = new Date()
    const birth = new Date(birthDate)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }

    return `${age} лет`
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Профиль пациента</h1>
            <p className="text-muted-foreground">Просмотр информации о пациенте</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => router.push("/doctor/patients")}>
              Назад к списку
            </Button>
            <Button onClick={() => router.push(`/doctor/records/new?patient=${patientId}`)}>
              <Plus className="mr-2 h-4 w-4" />
              Новая запись
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex flex-col items-center justify-center text-center">
                    <div className="w-24 h-24 bg-muted animate-pulse rounded-full mb-4" />
                    <div className="h-6 bg-muted animate-pulse rounded w-3/4 mb-2" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                  </div>
                  <div className="space-y-3">
                    {[...Array(4)].map((_, i) => (
                      <div key={i} className="h-4 bg-muted animate-pulse rounded" />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="lg:col-span-2">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex flex-col space-y-2">
                      <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>Личная информация</CardTitle>
                <CardDescription>Основные данные пациента</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center justify-center text-center">
                  <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
                    <User className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold">{patientInfo?.user?.full_name}</h3>
                  <p className="text-sm text-muted-foreground">Пациент</p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 text-muted-foreground mr-2" />
                    <span className="text-sm">{patientInfo?.user?.email}</span>
                  </div>
                  {patientInfo?.user?.phone && (
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                      <span className="text-sm">{patientInfo.user.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 text-muted-foreground mr-2" />
                    <span className="text-sm">
                      {formatDate(patientInfo?.birth_date)} ({getAgeFromBirthDate(patientInfo?.birth_date)})
                    </span>
                  </div>
                  <div className="flex items-center">
                    <User className="h-4 w-4 text-muted-foreground mr-2" />
                    <span className="text-sm">{getGenderText(patientInfo?.gender)}</span>
                  </div>
                  {patientInfo?.address && (
                    <div className="flex items-start">
                      <MapPin className="h-4 w-4 text-muted-foreground mr-2 mt-0.5" />
                      <span className="text-sm">{patientInfo.address}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Медицинские записи</CardTitle>
                <CardDescription>Последние медицинские записи пациента</CardDescription>
              </CardHeader>
              <CardContent>
                {medicalRecords.length > 0 ? (
                  <div className="space-y-4">
                    {medicalRecords.map((record) => (
                      <div
                        key={record.id}
                        className="flex flex-col space-y-2 p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => router.push(`/doctor/records/${record.id}`)}
                      >
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-muted-foreground mr-2" />
                          <span className="font-medium">Запись от {formatDate(record.visit_date)}</span>
                        </div>
                        <div className="text-sm">
                          <span className="font-medium">Диагноз:</span> {record.diagnosis}
                        </div>
                        <div className="text-sm line-clamp-2">
                          <span className="font-medium">Лечение:</span> {record.treatment}
                        </div>
                      </div>
                    ))}
                    <div className="flex justify-center mt-4">
                      <Button variant="outline" onClick={() => router.push(`/doctor/records?patient=${patientId}`)}>
                        Все записи
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 text-muted-foreground">
                    У пациента еще нет медицинских записей
                    <div className="mt-4">
                      <Button onClick={() => router.push(`/doctor/records/new?patient=${patientId}`)}>
                        <Plus className="mr-2 h-4 w-4" />
                        Создать первую запись
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="lg:col-span-3">
              <CardHeader>
                <CardTitle>Дополнительная информация</CardTitle>
                <CardDescription>Медицинские данные пациента</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <h4 className="font-medium">Страховой полис</h4>
                    <p className="text-muted-foreground">{patientInfo?.insurance_number || "Не указан"}</p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Количество визитов</h4>
                    <p className="text-muted-foreground">{medicalRecords.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
