"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Calendar, Search, User, FileText, Plus, Filter, Clock } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { EmptyState } from "@/components/ui/empty-state"

interface Patient {
  user_id: number
  birth_date?: string
  gender?: "male" | "female" | "other"
  insurance_number?: string
  address?: string
  user?: {
    full_name: string
    email: string
    phone?: string
  }
  records_count: number
  appointments_count: number
  last_visit: string | null
  last_appointment: string | null
}

export default function DoctorPatients() {
  const router = useRouter()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState<"all" | "with_records" | "with_appointments" | "recent">("all")
  const [sortBy, setSortBy] = useState<"name" | "last_visit" | "records_count">("last_visit")
  const [activeTab, setActiveTab] = useState<"all" | "recent">("all")

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      fetchPatients()
    }
  }, [user, loading])

  useEffect(() => {
    // Применение фильтров при изменении исходных данных или поискового запроса
    applyFilters()
  }, [patients, searchQuery, filterType, sortBy, activeTab])

  const fetchPatients = async () => {
    setIsLoading(true)
    try {
      // Получение всех пациентов, у которых есть медицинские записи от этого врача
      const { data: recordsData, error: recordsError } = await supabase
        .from("medicalrecords")
        .select(`
          patient_id,
          visit_date
        `)
        .eq("doctor_id", user.id)
        .order("visit_date", { ascending: false })

      if (recordsError) throw recordsError

      // Получение всех пациентов, у которых есть записи на прием к этому врачу
      const { data: appointmentsData, error: appointmentsError } = await supabase
        .from("appointments")
        .select(`
          patient_id,
          appointment_time,
          status
        `)
        .eq("doctor_id", user.id)
        .order("appointment_time", { ascending: false })

      if (appointmentsError) throw appointmentsError

      // Объединение уникальных ID пациентов из обоих запросов
      const patientIdsFromRecords = recordsData.map((record) => record.patient_id)
      const patientIdsFromAppointments = appointmentsData.map((appointment) => appointment.patient_id)
      const allPatientIds = [...new Set([...patientIdsFromRecords, ...patientIdsFromAppointments])]

      if (allPatientIds.length === 0) {
        setPatients([])
        setFilteredPatients([])
        setIsLoading(false)
        return
      }

      // Группировка записей по пациентам
      const patientRecords = recordsData.reduce(
        (acc, record) => {
          if (!acc[record.patient_id]) {
            acc[record.patient_id] = {
              count: 0,
              lastVisit: null,
            }
          }
          acc[record.patient_id].count += 1
          if (
            !acc[record.patient_id].lastVisit ||
            new Date(record.visit_date) > new Date(acc[record.patient_id].lastVisit)
          ) {
            acc[record.patient_id].lastVisit = record.visit_date
          }
          return acc
        },
        {} as Record<number, { count: number; lastVisit: string | null }>,
      )

      // Группировка записей на прием по пациентам
      const patientAppointments = appointmentsData.reduce(
        (acc, appointment) => {
          if (!acc[appointment.patient_id]) {
            acc[appointment.patient_id] = {
              count: 0,
              lastAppointment: null,
            }
          }
          acc[appointment.patient_id].count += 1
          if (
            !acc[appointment.patient_id].lastAppointment ||
            new Date(appointment.appointment_time) > new Date(acc[appointment.patient_id].lastAppointment)
          ) {
            acc[appointment.patient_id].lastAppointment = appointment.appointment_time
          }
          return acc
        },
        {} as Record<number, { count: number; lastAppointment: string | null }>,
      )

      // Получение информации о пациентах
      const { data: patientsData, error: patientsError } = await supabase
        .from("patients")
        .select(`
          user_id,
          birth_date,
          gender,
          insurance_number,
          address,
          user:users(
            full_name,
            email,
            phone
          )
        `)
        .in("user_id", allPatientIds)

      if (patientsError) throw patientsError

      // Объединение данных
      const patientsWithStats = patientsData.map((patient) => ({
        ...patient,
        records_count: patientRecords[patient.user_id]?.count || 0,
        appointments_count: patientAppointments[patient.user_id]?.count || 0,
        last_visit: patientRecords[patient.user_id]?.lastVisit || null,
        last_appointment: patientAppointments[patient.user_id]?.lastAppointment || null,
      }))

      setPatients(patientsWithStats)
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить список пациентов",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const applyFilters = () => {
    let filtered = [...patients]

    // Применение поискового запроса
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (patient) =>
          patient.user?.full_name.toLowerCase().includes(query) ||
          (patient.user?.email && patient.user.email.toLowerCase().includes(query)) ||
          (patient.user?.phone && patient.user.phone.toLowerCase().includes(query)) ||
          (patient.insurance_number && patient.insurance_number.toLowerCase().includes(query)),
      )
    }

    // Применение фильтра по типу
    if (filterType === "with_records") {
      filtered = filtered.filter((patient) => patient.records_count > 0)
    } else if (filterType === "with_appointments") {
      filtered = filtered.filter((patient) => patient.appointments_count > 0)
    } else if (filterType === "recent") {
      // Пациенты с визитами за последние 30 дней
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      filtered = filtered.filter(
        (patient) =>
          (patient.last_visit && new Date(patient.last_visit) >= thirtyDaysAgo) ||
          (patient.last_appointment && new Date(patient.last_appointment) >= thirtyDaysAgo),
      )
    }

    // Применение фильтра по вкладке
    if (activeTab === "recent") {
      // Пациенты с визитами за последние 30 дней
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
      filtered = filtered.filter(
        (patient) =>
          (patient.last_visit && new Date(patient.last_visit) >= thirtyDaysAgo) ||
          (patient.last_appointment && new Date(patient.last_appointment) >= thirtyDaysAgo),
      )
    }

    // Сортировка результатов
    if (sortBy === "name") {
      filtered.sort((a, b) => a.user?.full_name.localeCompare(b.user?.full_name || "") || 0)
    } else if (sortBy === "last_visit") {
      filtered.sort((a, b) => {
        if (!a.last_visit && !a.last_appointment) return 1
        if (!b.last_visit && !b.last_appointment) return -1

        const lastA = a.last_visit
          ? new Date(a.last_visit)
          : a.last_appointment
            ? new Date(a.last_appointment)
            : new Date(0)

        const lastB = b.last_visit
          ? new Date(b.last_visit)
          : b.last_appointment
            ? new Date(b.last_appointment)
            : new Date(0)

        return lastB.getTime() - lastA.getTime()
      })
    } else if (sortBy === "records_count") {
      filtered.sort((a, b) => b.records_count - a.records_count)
    }

    setFilteredPatients(filtered)
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Нет данных"
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const getGenderText = (gender: string | null) => {
    if (!gender) return "Не указан"
    switch (gender) {
      case "male":
        return "Мужской"
      case "female":
        return "Женский"
      default:
        return "Другой"
    }
  }

  const getAgeFromBirthDate = (birthDate: string | null) => {
    if (!birthDate) return "Не указан"

    const today = new Date()
    const birth = new Date(birthDate)
    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }

    return `${age} лет`
  }

  const getLastInteractionDate = (patient: Patient) => {
    if (!patient.last_visit && !patient.last_appointment) return "Нет данных"

    if (!patient.last_visit) return formatDate(patient.last_appointment)
    if (!patient.last_appointment) return formatDate(patient.last_visit)

    const visitDate = new Date(patient.last_visit)
    const appointmentDate = new Date(patient.last_appointment)

    return formatDate(visitDate > appointmentDate ? patient.last_visit : patient.last_appointment)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Пациенты</h1>
            <p className="text-muted-foreground">Управление списком ваших пациентов</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => router.push("/doctor/appointments")}>
              <Calendar className="mr-2 h-4 w-4" />
              Записи на приём
            </Button>
            <Button onClick={() => router.push("/doctor/records/new")}>
              <Plus className="mr-2 h-4 w-4" />
              Новая запись
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Все пациенты</CardTitle>
            <CardDescription>Просмотр и управление информацией о пациентах</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs
              defaultValue="all"
              className="mb-6"
              onValueChange={(value) => setActiveTab(value as "all" | "recent")}
            >
              <TabsList className="mb-4">
                <TabsTrigger value="all">Все пациенты</TabsTrigger>
                <TabsTrigger value="recent">Недавние пациенты</TabsTrigger>
              </TabsList>

              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Поиск по имени, email, телефону или номеру страховки..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                <div className="flex gap-2">
                  <Select value={filterType} onValueChange={(value) => setFilterType(value as any)}>
                    <SelectTrigger className="w-[180px]">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Фильтр" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все пациенты</SelectItem>
                      <SelectItem value="with_records">С записями</SelectItem>
                      <SelectItem value="with_appointments">С приёмами</SelectItem>
                      <SelectItem value="recent">Недавние (30 дней)</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={sortBy} onValueChange={(value) => setSortBy(value as any)}>
                    <SelectTrigger className="w-[180px]">
                      <Clock className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Сортировка" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="last_visit">По последнему визиту</SelectItem>
                      <SelectItem value="name">По имени</SelectItem>
                      <SelectItem value="records_count">По количеству записей</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <TabsContent value="all">
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="flex flex-col space-y-2 p-4 border rounded-lg">
                        <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                        <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                        <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                      </div>
                    ))}
                  </div>
                ) : filteredPatients.length > 0 ? (
                  <div className="space-y-4">
                    {filteredPatients.map((patient) => (
                      <div
                        key={patient.user_id}
                        className="flex flex-col space-y-3 p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => router.push(`/doctor/patients/${patient.user_id}`)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <User className="h-5 w-5 text-muted-foreground mr-2" />
                            <span className="font-medium">{patient.user?.full_name}</span>
                            <div className="ml-3 flex gap-1">
                              {patient.records_count > 0 && (
                                <Badge variant="outline" className="bg-blue-50">
                                  Записей: {patient.records_count}
                                </Badge>
                              )}
                              {patient.appointments_count > 0 && (
                                <Badge variant="outline" className="bg-green-50">
                                  Приёмов: {patient.appointments_count}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                router.push(`/doctor/records?patient=${patient.user_id}`)
                              }}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              Записи
                            </Button>
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                router.push(`/doctor/records/new?patient=${patient.user_id}`)
                              }}
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Новая запись
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          <div className="text-sm">
                            <span className="text-muted-foreground">Возраст:</span>{" "}
                            {getAgeFromBirthDate(patient.birth_date)}
                          </div>
                          <div className="text-sm">
                            <span className="text-muted-foreground">Пол:</span> {getGenderText(patient.gender)}
                          </div>
                          <div className="text-sm">
                            <span className="text-muted-foreground">Последнее взаимодействие:</span>{" "}
                            {getLastInteractionDate(patient)}
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {patient.user?.phone && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Телефон:</span> {patient.user.phone}
                            </div>
                          )}
                          <div className="text-sm">
                            <span className="text-muted-foreground">Email:</span> {patient.user?.email}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={<User className="h-10 w-10 text-muted-foreground" />}
                    title="Пациенты не найдены"
                    description={
                      patients.length > 0
                        ? "Не найдено пациентов, соответствующих поисковому запросу"
                        : "У вас еще нет пациентов"
                    }
                    action={
                      <Button onClick={() => router.push("/doctor/appointments")}>
                        <Calendar className="mr-2 h-4 w-4" />
                        Перейти к записям на приём
                      </Button>
                    }
                  />
                )}
              </TabsContent>

              <TabsContent value="recent">
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex flex-col space-y-2 p-4 border rounded-lg">
                        <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                        <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                        <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                      </div>
                    ))}
                  </div>
                ) : filteredPatients.length > 0 ? (
                  <div className="space-y-4">
                    {filteredPatients.map((patient) => (
                      <div
                        key={patient.user_id}
                        className="flex flex-col space-y-3 p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => router.push(`/doctor/patients/${patient.user_id}`)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <User className="h-5 w-5 text-muted-foreground mr-2" />
                            <span className="font-medium">{patient.user?.full_name}</span>
                            <div className="ml-3 flex gap-1">
                              {patient.records_count > 0 && (
                                <Badge variant="outline" className="bg-blue-50">
                                  Записей: {patient.records_count}
                                </Badge>
                              )}
                              {patient.appointments_count > 0 && (
                                <Badge variant="outline" className="bg-green-50">
                                  Приёмов: {patient.appointments_count}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                router.push(`/doctor/records?patient=${patient.user_id}`)
                              }}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              Записи
                            </Button>
                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                router.push(`/doctor/records/new?patient=${patient.user_id}`)
                              }}
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Новая запись
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          <div className="text-sm">
                            <span className="text-muted-foreground">Возраст:</span>{" "}
                            {getAgeFromBirthDate(patient.birth_date)}
                          </div>
                          <div className="text-sm">
                            <span className="text-muted-foreground">Пол:</span> {getGenderText(patient.gender)}
                          </div>
                          <div className="text-sm">
                            <span className="text-muted-foreground">Последнее взаимодействие:</span>{" "}
                            {getLastInteractionDate(patient)}
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {patient.user?.phone && (
                            <div className="text-sm">
                              <span className="text-muted-foreground">Телефон:</span> {patient.user.phone}
                            </div>
                          )}
                          <div className="text-sm">
                            <span className="text-muted-foreground">Email:</span> {patient.user?.email}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={<Clock className="h-10 w-10 text-muted-foreground" />}
                    title="Нет недавних пациентов"
                    description="За последние 30 дней у вас не было пациентов"
                    action={
                      <Button onClick={() => setActiveTab("all")}>
                        <User className="mr-2 h-4 w-4" />
                        Показать всех пациентов
                      </Button>
                    }
                  />
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
