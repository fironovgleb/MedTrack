"use client"

import { useState, useEffect } from "react"
import { CalendarIcon, ChevronLeft, ChevronRight, Clock } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"

interface Appointment {
  id: number
  patient_id: number
  appointment_time: string
  status: string
  appointment_type: string
  patient: {
    user: {
      full_name: string
    }
  }
}

export default function DoctorSchedule() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentDate, setCurrentDate] = useState(new Date())
  const [view, setView] = useState<"day" | "week">("day")

  // Calculate dates for the current view
  const startOfDay = new Date(currentDate)
  startOfDay.setHours(0, 0, 0, 0)

  const endOfDay = new Date(currentDate)
  endOfDay.setHours(23, 59, 59, 999)

  const startOfWeek = new Date(currentDate)
  startOfWeek.setDate(currentDate.getDate() - currentDate.getDay()) // Start from Sunday
  startOfWeek.setHours(0, 0, 0, 0)

  const endOfWeek = new Date(startOfWeek)
  endOfWeek.setDate(startOfWeek.getDate() + 6) // End on Saturday
  endOfWeek.setHours(23, 59, 59, 999)

  // Working hours
  const workingHours = {
    start: 9, // 9 AM
    end: 18, // 6 PM
  }

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      fetchAppointments()
    }
  }, [user, loading, currentDate, view])

  const fetchAppointments = async () => {
    setIsLoading(true)
    try {
      const start = view === "day" ? startOfDay : startOfWeek
      const end = view === "day" ? endOfDay : endOfWeek

      const { data, error } = await supabase
        .from("appointments")
        .select(`
          id,
          patient_id,
          appointment_time,
          status,
          appointment_type,
          patient:patients(
            user:users(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .gte("appointment_time", start.toISOString())
        .lte("appointment_time", end.toISOString())
        .order("appointment_time", { ascending: true })

      if (error) throw error
      setAppointments(data || [])
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить расписание",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("ru-RU", {
      day: "numeric",
      month: "long",
      year: "numeric",
    })
  }

  const formatShortDate = (date: Date) => {
    return date.toLocaleDateString("ru-RU", {
      day: "numeric",
      month: "short",
    })
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const formatDayOfWeek = (date: Date) => {
    const days = ["Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"]
    return days[date.getDay()]
  }

  const navigateDate = (direction: "prev" | "next") => {
    const newDate = new Date(currentDate)
    if (view === "day") {
      newDate.setDate(currentDate.getDate() + (direction === "next" ? 1 : -1))
    } else {
      newDate.setDate(currentDate.getDate() + (direction === "next" ? 7 : -7))
    }
    setCurrentDate(newDate)
  }

  const goToToday = () => {
    setCurrentDate(new Date())
  }

  const toggleView = () => {
    setView(view === "day" ? "week" : "day")
  }

  // Generate time slots for the day view
  const generateTimeSlots = () => {
    const slots = []
    for (let hour = workingHours.start; hour < workingHours.end; hour++) {
      slots.push(hour)
    }
    return slots
  }

  // Generate days for the week view
  const generateWeekDays = () => {
    const days = []
    const start = new Date(startOfWeek)

    for (let i = 0; i < 7; i++) {
      const day = new Date(start)
      day.setDate(start.getDate() + i)
      days.push(day)
    }

    return days
  }

  // Get appointments for a specific time slot
  const getAppointmentsForTimeSlot = (hour: number, date: Date) => {
    const slotStart = new Date(date)
    slotStart.setHours(hour, 0, 0, 0)

    const slotEnd = new Date(date)
    slotEnd.setHours(hour + 1, 0, 0, 0)

    return appointments.filter((appointment) => {
      const appointmentTime = new Date(appointment.appointment_time)
      return appointmentTime >= slotStart && appointmentTime < slotEnd && appointment.status === "scheduled"
    })
  }

  // Check if a date is today
  const isToday = (date: Date) => {
    const today = new Date()
    return (
      date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear()
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Расписание</h1>
            <p className="text-muted-foreground">Управление вашим расписанием приёмов</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={goToToday}>
              Сегодня
            </Button>
            <Button variant="outline" size="sm" onClick={toggleView}>
              {view === "day" ? "Неделя" : "День"}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
            <div>
              <CardTitle className="flex items-center">
                <CalendarIcon className="h-5 w-5 mr-2" />
                {view === "day"
                  ? formatDate(currentDate)
                  : `${formatShortDate(startOfWeek)} - ${formatShortDate(endOfWeek)}`}
              </CardTitle>
              <CardDescription>
                {view === "day" ? `Расписание на ${formatDayOfWeek(currentDate)}` : "Расписание на неделю"}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={() => navigateDate("prev")}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => navigateDate("next")}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="h-16 bg-muted animate-pulse rounded" />
                ))}
              </div>
            ) : view === "day" ? (
              // Day view
              <div className="space-y-1">
                {generateTimeSlots().map((hour) => {
                  const timeSlotAppointments = getAppointmentsForTimeSlot(hour, currentDate)

                  return (
                    <div key={hour} className="flex border-t pt-1">
                      <div className="w-16 py-2 text-muted-foreground text-sm">{`${hour}:00`}</div>
                      <div className="flex-1 min-h-[60px]">
                        {timeSlotAppointments.length > 0 ? (
                          <div className="space-y-1">
                            {timeSlotAppointments.map((appointment) => (
                              <div
                                key={appointment.id}
                                className="bg-blue-50 border-l-4 border-blue-500 p-2 rounded-r-md"
                              >
                                <div className="flex justify-between items-center">
                                  <div className="font-medium">{appointment.patient?.user?.full_name}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {formatTime(new Date(appointment.appointment_time))}
                                  </div>
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  {appointment.appointment_type || "Консультация"}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="h-full border border-dashed rounded-md flex items-center justify-center text-sm text-muted-foreground">
                            Нет записей
                          </div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            ) : (
              // Week view
              <div className="overflow-x-auto">
                <div className="min-w-[768px]">
                  {/* Week header */}
                  <div className="grid grid-cols-7 gap-1 mb-2">
                    {generateWeekDays().map((day, index) => (
                      <div
                        key={index}
                        className={`text-center p-2 rounded-md ${isToday(day) ? "bg-blue-50 text-blue-700" : ""}`}
                      >
                        <div className="font-medium">{formatDayOfWeek(day)}</div>
                        <div className="text-sm">{formatShortDate(day)}</div>
                      </div>
                    ))}
                  </div>

                  {/* Week content */}
                  <div className="space-y-1">
                    {generateTimeSlots().map((hour) => (
                      <div key={hour} className="flex border-t pt-1">
                        <div className="w-16 py-2 text-muted-foreground text-sm">{`${hour}:00`}</div>
                        <div className="flex-1 grid grid-cols-7 gap-1">
                          {generateWeekDays().map((day, index) => {
                            const timeSlotAppointments = getAppointmentsForTimeSlot(hour, day)

                            return (
                              <div
                                key={index}
                                className={`min-h-[60px] border rounded-md ${isToday(day) ? "bg-blue-50/30" : ""}`}
                              >
                                {timeSlotAppointments.length > 0 ? (
                                  <div className="p-1 space-y-1">
                                    {timeSlotAppointments.map((appointment) => (
                                      <div key={appointment.id} className="bg-blue-100 p-1 rounded-md text-xs">
                                        <div className="font-medium truncate">
                                          {appointment.patient?.user?.full_name}
                                        </div>
                                        <div className="flex items-center text-muted-foreground">
                                          <Clock className="h-3 w-3 mr-1" />
                                          {formatTime(new Date(appointment.appointment_time))}
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                ) : null}
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {appointments.length === 0 && !isLoading && (
              <div className="text-center py-10 text-muted-foreground">
                {view === "day"
                  ? "На этот день нет запланированных приёмов"
                  : "На эту неделю нет запланированных приёмов"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
