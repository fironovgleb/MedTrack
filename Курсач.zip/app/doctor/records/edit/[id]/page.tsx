"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { formatDate, getGenderText } from "@/lib/utils"

interface PatientInfo {
  id: number
  full_name: string
  birth_date: string | null
  gender: string | null
  insurance_number: string | null
}

interface MedicalRecord {
  id: number
  patient_id: number
  doctor_id: number
  visit_date: string
  diagnosis: string
  treatment: string
  comments: string | null
}

export default function EditMedicalRecord() {
  const router = useRouter()
  const params = useParams()
  const recordId = params.id as string
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [patientInfo, setPatientInfo] = useState<PatientInfo | null>(null)
  const [record, setRecord] = useState<MedicalRecord | null>(null)
  const [diagnosis, setDiagnosis] = useState("")
  const [treatment, setTreatment] = useState("")
  const [comments, setComments] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (!loading && user && user.role === "doctor" && recordId) {
      fetchRecord()
    }
  }, [user, loading, recordId])

  const fetchRecord = async () => {
    setIsLoading(true)
    try {
      // Получение медицинской записи
      const { data: recordData, error: recordError } = await supabase
        .from("MedicalRecords")
        .select("*")
        .eq("id", recordId)
        .single()

      if (recordError) throw recordError

      // Проверка, что запись принадлежит этому врачу
      if (recordData.doctor_id !== user.id) {
        toast({
          title: "Ошибка доступа",
          description: "У вас нет прав на редактирование этой записи",
          variant: "destructive",
        })
        router.push("/doctor/records")
        return
      }

      setRecord(recordData)
      setDiagnosis(recordData.diagnosis)
      setTreatment(recordData.treatment)
      setComments(recordData.comments || "")

      // Получение информации о пациенте
      const { data: patientData, error: patientError } = await supabase
        .from("Patients")
        .select(`
          user_id,
          birth_date,
          gender,
          insurance_number,
          user:Users(
            full_name
          )
        `)
        .eq("user_id", recordData.patient_id)
        .single()

      if (patientError) throw patientError

      setPatientInfo({
        id: patientData.user_id,
        full_name: patientData.user.full_name,
        birth_date: patientData.birth_date,
        gender: patientData.gender,
        insurance_number: patientData.insurance_number,
      })
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить медицинскую запись",
        variant: "destructive",
      })
      router.push("/doctor/records")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!diagnosis || !treatment) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните обязательные поля",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Обновление медицинской записи
      const { error } = await supabase
        .from("MedicalRecords")
        .update({
          diagnosis,
          treatment,
          comments: comments || null,
        })
        .eq("id", recordId)
        .eq("doctor_id", user.id)

      if (error) throw error

      // Добавление записи в аудит
      await supabase.from("AuditLogs").insert([
        {
          user_id: user.id,
          action: "update_medical_record",
          target_type: "medical_record",
          target_id: recordId,
        },
      ])

      toast({
        title: "Успешно",
        description: "Медицинская запись успешно обновлена",
      })

      router.push("/doctor/records")
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось обновить медицинскую запись",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Редактирование медицинской записи</h1>
            <p className="text-muted-foreground">Изменение информации о диагнозе и лечении</p>
          </div>
          <Button variant="outline" onClick={() => router.push("/doctor/records")}>
            Назад к записям
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/3" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-4">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-20 bg-muted animate-pulse rounded" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-20 bg-muted animate-pulse rounded" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Информация о пациенте</CardTitle>
                  <CardDescription>Основная информация о пациенте</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>ФИО пациента</Label>
                      <div className="p-2 bg-muted rounded-md">{patientInfo?.full_name}</div>
                    </div>
                    <div className="space-y-2">
                      <Label>Дата рождения</Label>
                      <div className="p-2 bg-muted rounded-md">{formatDate(patientInfo?.birth_date)}</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Пол</Label>
                      <div className="p-2 bg-muted rounded-md">{getGenderText(patientInfo?.gender)}</div>
                    </div>
                    <div className="space-y-2">
                      <Label>Номер страхового полиса</Label>
                      <div className="p-2 bg-muted rounded-md">{patientInfo?.insurance_number || "Не указан"}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Медицинская запись</CardTitle>
                  <CardDescription>Введите информацию о диагнозе и лечении</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="diagnosis">Диагноз *</Label>
                    <Input
                      id="diagnosis"
                      value={diagnosis}
                      onChange={(e) => setDiagnosis(e.target.value)}
                      placeholder="Введите диагноз"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="treatment">Назначенное лечение *</Label>
                    <Textarea
                      id="treatment"
                      value={treatment}
                      onChange={(e) => setTreatment(e.target.value)}
                      placeholder="Опишите назначенное лечение"
                      rows={5}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="comments">Комментарии</Label>
                    <Textarea
                      id="comments"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder="Дополнительные комментарии"
                      rows={3}
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.push("/doctor/records")}
                    disabled={isSubmitting}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Сохранение..." : "Сохранить изменения"}
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </form>
        )}
      </div>
    </DashboardLayout>
  )
}
