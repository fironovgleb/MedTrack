"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Calendar, User, FileText, Edit, ArrowLeft } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { formatDate, getGenderText, getAgeFromBirthDate } from "@/lib/utils"

interface MedicalRecord {
  id: number
  patient_id: number
  doctor_id: number
  visit_date: string
  diagnosis: string
  treatment: string
  comments: string | null
  patient: {
    user_id: number
    birth_date: string | null
    gender: string | null
    insurance_number: string | null
    user: {
      full_name: string
    }
  }
}

export default function ViewMedicalRecord() {
  const router = useRouter()
  const params = useParams()
  const recordId = params.id as string
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [record, setRecord] = useState<MedicalRecord | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!loading && user && user.role === "doctor" && recordId) {
      fetchRecord()
    }
  }, [user, loading, recordId])

  const fetchRecord = async () => {
    setIsLoading(true)
    try {
      // Получение медицинской записи с информацией о пациенте
      const { data, error } = await supabase
        .from("MedicalRecords")
        .select(`
          id,
          patient_id,
          doctor_id,
          visit_date,
          diagnosis,
          treatment,
          comments,
          patient:Patients(
            user_id,
            birth_date,
            gender,
            insurance_number,
            user:Users(
              full_name
            )
          )
        `)
        .eq("id", recordId)
        .single()

      if (error) throw error

      // Проверка, что запись принадлежит этому врачу
      if (data.doctor_id !== user.id) {
        toast({
          title: "Ошибка доступа",
          description: "У вас нет прав на просмотр этой записи",
          variant: "destructive",
        })
        router.push("/doctor/records")
        return
      }

      setRecord(data)
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить медицинскую запись",
        variant: "destructive",
      })
      router.push("/doctor/records")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Медицинская запись</h1>
            <p className="text-muted-foreground">Просмотр информации о диагнозе и лечении</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => router.push("/doctor/records")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Назад к записям
            </Button>
            {!isLoading && record && (
              <Button onClick={() => router.push(`/doctor/records/edit/${record.id}`)}>
                <Edit className="mr-2 h-4 w-4" />
                Редактировать
              </Button>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/3" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-4">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-20 bg-muted animate-pulse rounded" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-20 bg-muted animate-pulse rounded" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : record ? (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Информация о пациенте</CardTitle>
                <CardDescription>Основная информация о пациенте</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">ФИО пациента</p>
                    <div className="flex items-center">
                      <User className="h-4 w-4 text-muted-foreground mr-2" />
                      <p>{record.patient.user.full_name}</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Дата рождения</p>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 text-muted-foreground mr-2" />
                      <p>
                        {formatDate(record.patient.birth_date)} ({getAgeFromBirthDate(record.patient.birth_date)})
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Пол</p>
                    <p>{getGenderText(record.patient.gender)}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Номер страхового полиса</p>
                    <p>{record.patient.insurance_number || "Не указан"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Детали медицинской записи</CardTitle>
                <CardDescription>Информация о диагнозе и лечении</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Дата визита</p>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 text-muted-foreground mr-2" />
                    <p>{formatDate(record.visit_date)}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Диагноз</p>
                  <p className="p-2 bg-muted rounded-md">{record.diagnosis}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Назначенное лечение</p>
                  <p className="p-2 bg-muted rounded-md whitespace-pre-line">{record.treatment}</p>
                </div>
                {record.comments && (
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Комментарии</p>
                    <p className="p-2 bg-muted rounded-md whitespace-pre-line">{record.comments}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => router.push(`/doctor/patients/${record.patient_id}`)}>
                Профиль пациента
              </Button>
              <Button onClick={() => router.push(`/doctor/records/edit/${record.id}`)}>
                <Edit className="mr-2 h-4 w-4" />
                Редактировать запись
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center py-10">
            <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium">Запись не найдена</h3>
            <p className="text-muted-foreground">Запрошенная медицинская запись не существует или была удалена</p>
            <Button className="mt-4" onClick={() => router.push("/doctor/records")}>
              Вернуться к списку записей
            </Button>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
