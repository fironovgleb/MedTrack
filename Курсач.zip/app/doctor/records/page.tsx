"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Calendar, Filter, FileText, Search, User, Plus, Edit, Eye, Trash2 } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { formatDate } from "@/lib/utils"

interface MedicalRecord {
  id: number
  patient_id: number
  visit_date: string
  diagnosis: string
  treatment: string
  comments: string
  patient: {
    user_id: number
    user: {
      full_name: string
    }
  }
}

interface Patient {
  user_id: number
  user: {
    full_name: string
  }
}

export default function DoctorRecords() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const patientIdParam = searchParams.get("patient")

  const [records, setRecords] = useState<MedicalRecord[]>([])
  const [filteredRecords, setFilteredRecords] = useState<MedicalRecord[]>([])
  const [patients, setPatients] = useState<Patient[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState(patientIdParam || "all")
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null)
  const [openDialog, setOpenDialog] = useState(false)
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [tableNames, setTableNames] = useState({
    medicalRecords: "MedicalRecords",
    patients: "Patients",
    users: "Users",
    auditLogs: "AuditLogs",
  })

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      detectTableNames()
    }
  }, [user, loading])

  useEffect(() => {
    if (!loading && user && user.role === "doctor" && tableNames.medicalRecords) {
      fetchData()
    }
  }, [user, loading, patientIdParam, tableNames])

  useEffect(() => {
    // Применение фильтров при изменении исходных данных, поискового запроса или выбранного пациента
    filterRecords()
  }, [records, searchQuery, selectedPatient])

  // Исправление: Функция для определения правильных имен таблиц
  const detectTableNames = async () => {
    try {
      // Проверка таблицы медицинских записей
      const { error: upperMedicalError } = await supabase.from("MedicalRecords").select("id").limit(1)
      if (upperMedicalError) {
        console.log("Таблица MedicalRecords не найдена, пробуем medicalrecords:", upperMedicalError)
        const { error: lowerMedicalError } = await supabase.from("medicalrecords").select("id").limit(1)
        if (!lowerMedicalError) {
          setTableNames((prev) => ({ ...prev, medicalRecords: "medicalrecords" }))
        }
      }

      // Проверка таблицы пациентов
      const { error: upperPatientsError } = await supabase.from("Patients").select("user_id").limit(1)
      if (upperPatientsError) {
        console.log("Таблица Patients не найдена, пробуем patients:", upperPatientsError)
        const { error: lowerPatientsError } = await supabase.from("patients").select("user_id").limit(1)
        if (!lowerPatientsError) {
          setTableNames((prev) => ({ ...prev, patients: "patients" }))
        }
      }

      // Проверка таблицы пользователей
      const { error: upperUsersError } = await supabase.from("Users").select("id").limit(1)
      if (upperUsersError) {
        console.log("Таблица Users не найдена, пробуем users:", upperUsersError)
        const { error: lowerUsersError } = await supabase.from("users").select("id").limit(1)
        if (!lowerUsersError) {
          setTableNames((prev) => ({ ...prev, users: "users" }))
        }
      }

      // Проверка таблицы аудита
      const { error: upperAuditError } = await supabase.from("AuditLogs").select("id").limit(1)
      if (upperAuditError) {
        console.log("Таблица AuditLogs не найдена, пробуем auditlogs:", upperAuditError)
        const { error: lowerAuditError } = await supabase.from("auditlogs").select("id").limit(1)
        if (!lowerAuditError) {
          setTableNames((prev) => ({ ...prev, auditLogs: "auditlogs" }))
        }
      }

      console.log("Определены имена таблиц:", tableNames)
    } catch (error) {
      console.error("Ошибка при определении имен таблиц:", error)
    }
  }

  const fetchData = async () => {
    setIsLoading(true)
    try {
      // Получение всех пациентов врача
      const { data: patientsData, error: patientsError } = await supabase
        .from(tableNames.medicalRecords)
        .select(`
          patient:${tableNames.patients}(
            user_id,
            user:${tableNames.users}(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .order("visit_date", { ascending: false })

      if (patientsError) throw patientsError

      // Извлечение уникальных пациентов
      const uniquePatients = Array.from(
        new Map(
          patientsData
            .map((record) => record.patient)
            .filter(Boolean)
            .map((patient) => [patient.user_id, patient]),
        ).values(),
      )

      setPatients(uniquePatients)

      // Получение медицинских записей
      let query = supabase
        .from(tableNames.medicalRecords)
        .select(`
          id,
          patient_id,
          visit_date,
          diagnosis,
          treatment,
          comments,
          patient:${tableNames.patients}(
            user_id,
            user:${tableNames.users}(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .order("visit_date", { ascending: false })

      // Если выбран конкретный пациент из параметров URL
      if (patientIdParam) {
        query = query.eq("patient_id", patientIdParam)
        setSelectedPatient(patientIdParam)
      }

      const { data: recordsData, error: recordsError } = await query

      if (recordsError) throw recordsError
      setRecords(recordsData || [])
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить медицинские записи",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filterRecords = () => {
    let filtered = [...records]

    // Фильтрация по поисковому запросу
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (record) =>
          record.diagnosis.toLowerCase().includes(query) ||
          record.treatment.toLowerCase().includes(query) ||
          record.patient?.user?.full_name.toLowerCase().includes(query),
      )
    }

    // Фильтрация по пациенту
    if (selectedPatient && selectedPatient !== "all") {
      filtered = filtered.filter((record) => record.patient_id.toString() === selectedPatient)
    }

    setFilteredRecords(filtered)
  }

  const openRecordDetails = (record: MedicalRecord) => {
    setSelectedRecord(record)
    setOpenDialog(true)
  }

  const confirmDelete = (record: MedicalRecord, e: React.MouseEvent) => {
    e.stopPropagation()
    setSelectedRecord(record)
    setOpenDeleteDialog(true)
  }

  const handleDelete = async () => {
    if (!selectedRecord) return

    setIsDeleting(true)
    try {
      // Удаление медицинской записи
      const { error } = await supabase
        .from(tableNames.medicalRecords)
        .delete()
        .eq("id", selectedRecord.id)
        .eq("doctor_id", user.id)

      if (error) throw error

      // Добавление записи в аудит
      await supabase.from(tableNames.auditLogs).insert([
        {
          user_id: user.id,
          action: "delete_medical_record",
          target_type: "medical_record",
          target_id: selectedRecord.id,
          timestamp: new Date().toISOString(),
        },
      ])

      toast({
        title: "Успешно",
        description: "Медицинская запись успешно удалена",
      })

      // Обновление списка записей
      setRecords(records.filter((record) => record.id !== selectedRecord.id))
      setOpenDeleteDialog(false)
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить медицинскую запись",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Медицинские записи</h1>
            <p className="text-muted-foreground">Управление медицинскими записями пациентов</p>
          </div>
          <Button onClick={() => router.push("/doctor/patients")}>
            <Plus className="mr-2 h-4 w-4" />
            Новая запись
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Все записи</CardTitle>
            <CardDescription>Просмотр и управление медицинскими записями</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по диагнозу, лечению или пациенту..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все пациенты" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все пациенты</SelectItem>
                    {patients.map((patient) => (
                      <SelectItem key={patient.user_id} value={patient.user_id.toString()}>
                        {patient.user.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex flex-col space-y-2 p-4 border rounded-lg">
                    <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  </div>
                ))}
              </div>
            ) : filteredRecords.length > 0 ? (
              <div className="space-y-4">
                {filteredRecords.map((record) => (
                  <div
                    key={record.id}
                    className="flex flex-col space-y-3 p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => router.push(`/doctor/records/${record.id}`)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-muted-foreground mr-2" />
                        <span className="font-medium">Запись от {formatDate(record.visit_date)}</span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-blue-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            router.push(`/doctor/records/${record.id}`)
                          }}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          Просмотр
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-amber-600"
                          onClick={(e) => {
                            e.stopPropagation()
                            router.push(`/doctor/records/edit/${record.id}`)
                          }}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Изменить
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-600"
                          onClick={(e) => confirmDelete(record, e)}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Удалить
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <User className="h-4 w-4 mr-1" />
                      <span>{record.patient?.user?.full_name}</span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Диагноз:</span> {record.diagnosis}
                    </div>
                    <div className="text-sm line-clamp-2">
                      <span className="font-medium">Лечение:</span> {record.treatment}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                {records.length > 0
                  ? "Не найдено записей, соответствующих выбранным фильтрам"
                  : "У вас еще нет медицинских записей"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Медицинская запись</DialogTitle>
            <DialogDescription>Подробная информация о медицинской записи</DialogDescription>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Дата посещения</p>
                  <p className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    {formatDate(selectedRecord.visit_date)}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Пациент</p>
                  <p className="flex items-center">
                    <User className="h-4 w-4 mr-2 text-muted-foreground" />
                    {selectedRecord.patient?.user?.full_name}
                  </p>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Диагноз</p>
                <p className="p-2 bg-muted rounded-md">{selectedRecord.diagnosis}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground">Назначенное лечение</p>
                <p className="p-2 bg-muted rounded-md whitespace-pre-line">{selectedRecord.treatment}</p>
              </div>
              {selectedRecord.comments && (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Комментарии</p>
                  <p className="p-2 bg-muted rounded-md whitespace-pre-line">{selectedRecord.comments}</p>
                </div>
              )}
              <div className="flex justify-between">
                <Button variant="outline" onClick={() => router.push(`/doctor/patients/${selectedRecord.patient_id}`)}>
                  Профиль пациента
                </Button>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => router.push(`/doctor/records/edit/${selectedRecord.id}`)}>
                    <Edit className="mr-2 h-4 w-4" />
                    Редактировать
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => {
                      setOpenDialog(false)
                      setOpenDeleteDialog(true)
                    }}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Удалить
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={openDeleteDialog} onOpenChange={setOpenDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Удаление медицинской записи</DialogTitle>
            <DialogDescription>
              Вы уверены, что хотите удалить эту медицинскую запись? Это действие нельзя отменить.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpenDeleteDialog(false)} disabled={isDeleting}>
              Отмена
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={isDeleting}>
              {isDeleting ? "Удаление..." : "Удалить"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
