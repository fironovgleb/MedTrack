"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { formatDate, getGenderText } from "@/lib/utils"

interface PatientInfo {
  id: number
  full_name: string
  birth_date: string | null
  gender: string | null
  insurance_number: string | null
}

export default function NewMedicalRecord() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const appointmentId = searchParams.get("appointment")
  const patientId = searchParams.get("patient")

  const [patientInfo, setPatientInfo] = useState<PatientInfo | null>(null)
  const [diagnosis, setDiagnosis] = useState("")
  const [treatment, setTreatment] = useState("")
  const [comments, setComments] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [tableNames, setTableNames] = useState({
    medicalRecords: "MedicalRecords",
    patients: "Patients",
    users: "Users",
    appointments: "Appointments",
    auditLogs: "AuditLogs",
  })

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      detectTableNames()
    }
  }, [user, loading])

  useEffect(() => {
    if (!loading && user && user.role === "doctor" && patientId && tableNames.patients) {
      fetchPatientInfo()
    }
  }, [user, loading, patientId, tableNames])

  // Исправление: Функция для определения правильных имен таблиц
  const detectTableNames = async () => {
    try {
      // Проверка таблицы медицинских записей
      const { error: upperMedicalError } = await supabase.from("MedicalRecords").select("id").limit(1)
      if (upperMedicalError) {
        console.log("Таблица MedicalRecords не найдена, пробуем medicalrecords:", upperMedicalError)
        const { error: lowerMedicalError } = await supabase.from("medicalrecords").select("id").limit(1)
        if (!lowerMedicalError) {
          setTableNames((prev) => ({ ...prev, medicalRecords: "medicalrecords" }))
        }
      }

      // Проверка таблицы пациентов
      const { error: upperPatientsError } = await supabase.from("Patients").select("user_id").limit(1)
      if (upperPatientsError) {
        console.log("Таблица Patients не найдена, пробуем patients:", upperPatientsError)
        const { error: lowerPatientsError } = await supabase.from("patients").select("user_id").limit(1)
        if (!lowerPatientsError) {
          setTableNames((prev) => ({ ...prev, patients: "patients" }))
        }
      }

      // Проверка таблицы пользователей
      const { error: upperUsersError } = await supabase.from("Users").select("id").limit(1)
      if (upperUsersError) {
        console.log("Таблица Users не найдена, пробуем users:", upperUsersError)
        const { error: lowerUsersError } = await supabase.from("users").select("id").limit(1)
        if (!lowerUsersError) {
          setTableNames((prev) => ({ ...prev, users: "users" }))
        }
      }

      // Проверка таблицы записей на прием
      const { error: upperAppointmentsError } = await supabase.from("Appointments").select("id").limit(1)
      if (upperAppointmentsError) {
        console.log("Таблица Appointments не найдена, пробуем appointments:", upperAppointmentsError)
        const { error: lowerAppointmentsError } = await supabase.from("appointments").select("id").limit(1)
        if (!lowerAppointmentsError) {
          setTableNames((prev) => ({ ...prev, appointments: "appointments" }))
        }
      }

      // Проверка таблицы аудита
      const { error: upperAuditError } = await supabase.from("AuditLogs").select("id").limit(1)
      if (upperAuditError) {
        console.log("Таблица AuditLogs не найдена, пробуем auditlogs:", upperAuditError)
        const { error: lowerAuditError } = await supabase.from("auditlogs").select("id").limit(1)
        if (!lowerAuditError) {
          setTableNames((prev) => ({ ...prev, auditLogs: "auditlogs" }))
        }
      }

      console.log("Определены имена таблиц:", tableNames)
    } catch (error) {
      console.error("Ошибка при определении имен таблиц:", error)
    }
  }

  const fetchPatientInfo = async () => {
    setIsLoading(true)
    try {
      // Получение информации о пациенте
      const { data: patientData, error: patientError } = await supabase
        .from(tableNames.patients)
        .select(`
          user_id,
          birth_date,
          gender,
          insurance_number,
          user:${tableNames.users}(
            full_name
          )
        `)
        .eq("user_id", patientId)
        .single()

      if (patientError) throw patientError

      setPatientInfo({
        id: patientData.user_id,
        full_name: patientData.user.full_name,
        birth_date: patientData.birth_date,
        gender: patientData.gender,
        insurance_number: patientData.insurance_number,
      })
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить информацию о пациенте",
        variant: "destructive",
      })
      router.push("/doctor/records")
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!diagnosis || !treatment) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните обязательные поля",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Создание новой медицинской записи
      const { data, error } = await supabase
        .from(tableNames.medicalRecords)
        .insert([
          {
            patient_id: patientId,
            doctor_id: user.id,
            visit_date: new Date().toISOString(),
            diagnosis,
            treatment,
            comments: comments || null,
          },
        ])
        .select()

      if (error) throw error

      // Если запись создана из записи на приём, обновляем статус записи
      if (appointmentId) {
        const { error: appointmentError } = await supabase
          .from(tableNames.appointments)
          .update({ status: "completed" })
          .eq("id", appointmentId)
          .eq("doctor_id", user.id)

        if (appointmentError) throw appointmentError
      }

      // Добавление записи в аудит
      await supabase.from(tableNames.auditLogs).insert([
        {
          user_id: user.id,
          action: "create_medical_record",
          target_type: "medical_record",
          target_id: data?.[0]?.id || null,
          timestamp: new Date().toISOString(),
        },
      ])

      toast({
        title: "Успешно",
        description: "Медицинская запись успешно создана",
      })

      router.push("/doctor/records")
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать медицинскую запись",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Новая медицинская запись</h1>
            <p className="text-muted-foreground">Создание медицинской записи для пациента</p>
          </div>
          <Button variant="outline" onClick={() => router.push("/doctor/records")}>
            Назад к записям
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/3" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-4">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-20 bg-muted animate-pulse rounded" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-20 bg-muted animate-pulse rounded" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Информация о пациенте</CardTitle>
                  <CardDescription>Основная информация о пациенте</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>ФИО пациента</Label>
                      <div className="p-2 bg-muted rounded-md">{patientInfo?.full_name}</div>
                    </div>
                    <div className="space-y-2">
                      <Label>Дата рождения</Label>
                      <div className="p-2 bg-muted rounded-md">{formatDate(patientInfo?.birth_date)}</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Пол</Label>
                      <div className="p-2 bg-muted rounded-md">{getGenderText(patientInfo?.gender)}</div>
                    </div>
                    <div className="space-y-2">
                      <Label>Номер страхового полиса</Label>
                      <div className="p-2 bg-muted rounded-md">{patientInfo?.insurance_number || "Не указан"}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Медицинская запись</CardTitle>
                  <CardDescription>Введите информацию о диагнозе и лечении</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="diagnosis">Диагноз *</Label>
                    <Input
                      id="diagnosis"
                      value={diagnosis}
                      onChange={(e) => setDiagnosis(e.target.value)}
                      placeholder="Введите диагноз"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="treatment">Назначенное лечение *</Label>
                    <Textarea
                      id="treatment"
                      value={treatment}
                      onChange={(e) => setTreatment(e.target.value)}
                      placeholder="Опишите назначенное лечение"
                      rows={5}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="comments">Комментарии</Label>
                    <Textarea
                      id="comments"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder="Дополнительные комментарии"
                      rows={3}
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.push("/doctor/records")}
                    disabled={isSubmitting}
                  >
                    Отмена
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? "Сохранение..." : "Сохранить запись"}
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </form>
        )}
      </div>
    </DashboardLayout>
  )
}
