"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Calendar, Filter, Search, FileText, Clock } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import {
  formatAppointmentDate,
  formatAppointmentTime,
  getAppointmentStatusText,
  getAppointmentStatusColor,
} from "@/lib/appointment-utils"

interface Appointment {
  id: number
  patient_id: number
  appointment_time: string
  status: string
  patient: {
    user_id: number
    user: {
      full_name: string
      phone: string | null
    }
  }
}

export default function DoctorAppointments() {
  const router = useRouter()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [dateFilter, setDateFilter] = useState("all")
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  // Dialog state
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)
  const [appointmentDetailsDialog, setAppointmentDetailsDialog] = useState(false)
  const [confirmActionDialog, setConfirmActionDialog] = useState(false)
  const [actionType, setActionType] = useState<"complete" | "cancel" | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  // Set up a refresh interval (every 2 minutes)
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTrigger((prev) => prev + 1)
    }, 120000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      fetchAppointments()
    }
  }, [user, loading, refreshTrigger])

  useEffect(() => {
    // Apply filters when source data, search query, or filters change
    filterAppointments()
  }, [appointments, searchQuery, statusFilter, dateFilter])

  const fetchAppointments = async () => {
    setIsLoading(true)
    try {
      console.log("Fetching appointments for doctor:", user.id)
      const { data, error } = await supabase
        .from("appointments")
        .select(`
        id,
        patient_id,
        appointment_time,
        status,
        patient:patients(
          user_id,
          user:users(
            full_name,
            phone
          )
        )
      `)
        .eq("doctor_id", user.id)
        .order("appointment_time", { ascending: true })

      if (error) {
        console.error("Error fetching appointments:", error)
        throw error
      }

      console.log("Fetched appointments:", data?.length)
      setAppointments(data || [])
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить записи на приём",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filterAppointments = useCallback(() => {
    let filtered = [...appointments]

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter((appointment) => appointment.patient?.user?.full_name.toLowerCase().includes(query))
    }

    // Filter by status
    if (statusFilter !== "all") {
      filtered = filtered.filter((appointment) => appointment.status === statusFilter)
    }

    // Filter by date
    if (dateFilter !== "all") {
      const today = new Date()
      today.setHours(0, 0, 0, 0)

      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)

      const nextWeek = new Date(today)
      nextWeek.setDate(nextWeek.getDate() + 7)

      const nextMonth = new Date(today)
      nextMonth.setMonth(nextMonth.getMonth() + 1)

      switch (dateFilter) {
        case "today":
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.appointment_time)
            return appointmentDate >= today && appointmentDate < tomorrow
          })
          break
        case "week":
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.appointment_time)
            return appointmentDate >= today && appointmentDate < nextWeek
          })
          break
        case "month":
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.appointment_time)
            return appointmentDate >= today && appointmentDate < nextMonth
          })
          break
        case "past":
          filtered = filtered.filter((appointment) => {
            const appointmentDate = new Date(appointment.appointment_time)
            return appointmentDate < today
          })
          break
      }
    }

    setFilteredAppointments(filtered)
  }, [appointments, searchQuery, statusFilter, dateFilter])

  const openAppointmentDetails = (appointmentId: number) => {
    const appointment = appointments.find((a) => a.id === appointmentId)
    if (appointment) {
      setSelectedAppointment(appointment)
      setAppointmentDetailsDialog(true)
    }
  }

  const openActionDialog = (appointmentId: number, action: "complete" | "cancel") => {
    const appointment = appointments.find((a) => a.id === appointmentId)
    if (appointment) {
      setSelectedAppointment(appointment)
      setActionType(action)
      setConfirmActionDialog(true)
    }
  }

  const handleAppointmentAction = async () => {
    if (!selectedAppointment || !actionType) return

    setIsProcessing(true)
    try {
      const newStatus = actionType === "complete" ? "completed" : "canceled"

      const { error } = await supabase
        .from("appointments")
        .update({ status: newStatus })
        .eq("id", selectedAppointment.id)
        .eq("doctor_id", user.id)

      if (error) throw error

      // Add audit log
      await supabase.from("auditlogs").insert([
        {
          user_id: user.id,
          action: actionType === "complete" ? "complete_appointment" : "cancel_appointment",
          target_type: "appointment",
          target_id: selectedAppointment.id,
          timestamp: new Date().toISOString(),
        },
      ])

      toast({
        title: "Успешно",
        description: actionType === "complete" ? "Приём отмечен как завершенный" : "Запись на приём отменена",
      })

      // Update appointments list
      setAppointments(
        appointments.map((appointment) =>
          appointment.id === selectedAppointment.id ? { ...appointment, status: newStatus } : appointment,
        ),
      )

      setConfirmActionDialog(false)
      setAppointmentDetailsDialog(false)

      // If completing appointment, redirect to create medical record
      if (actionType === "complete") {
        router.push(
          `/doctor/records/new?appointment=${selectedAppointment.id}&patient=${selectedAppointment.patient_id}`,
        )
      }
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || `Не удалось ${actionType === "complete" ? "завершить" : "отменить"} запись`,
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const renderAppointmentCard = (appointment: Appointment) => {
    return (
      <div
        key={appointment.id}
        className="p-4 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
        onClick={() => openAppointmentDetails(appointment.id)}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="font-medium">{appointment.patient?.user?.full_name}</div>
            <div className="text-sm text-muted-foreground">Запись на приём</div>
          </div>
          <div className={`flex items-center ${getAppointmentStatusColor(appointment.status)}`}>
            <span>{getAppointmentStatusText(appointment.status)}</span>
          </div>
        </div>
        <div className="mt-3 flex flex-col sm:flex-row gap-4 text-sm">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
            <span>{formatAppointmentDate(appointment.appointment_time)}</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
            <span>{formatAppointmentTime(appointment.appointment_time)}</span>
          </div>
        </div>
        {appointment.status === "scheduled" && (
          <div className="mt-3 flex flex-wrap gap-2">
            <Button
              variant="default"
              size="sm"
              onClick={(e) => {
                e.stopPropagation()
                openActionDialog(appointment.id, "complete")
              }}
            >
              Завершить приём
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-red-600"
              onClick={(e) => {
                e.stopPropagation()
                openActionDialog(appointment.id, "cancel")
              }}
            >
              Отменить запись
            </Button>
          </div>
        )}
      </div>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Записи на приём</h1>
            <p className="text-muted-foreground">Управление записями пациентов на приём</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Все записи</CardTitle>
            <CardDescription>Просмотр и управление записями на приём</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по пациенту или типу приёма..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все статусы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все статусы</SelectItem>
                    <SelectItem value="scheduled">Запланированные</SelectItem>
                    <SelectItem value="completed">Завершенные</SelectItem>
                    <SelectItem value="canceled">Отмененные</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все даты" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все даты</SelectItem>
                    <SelectItem value="today">Сегодня</SelectItem>
                    <SelectItem value="week">Ближайшая неделя</SelectItem>
                    <SelectItem value="month">Ближайший месяц</SelectItem>
                    <SelectItem value="past">Прошедшие</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : filteredAppointments.length > 0 ? (
              <div className="space-y-4">
                {filteredAppointments.map((appointment) => renderAppointmentCard(appointment))}
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                {appointments.length > 0
                  ? "Не найдено записей, соответствующих выбранным фильтрам"
                  : "У вас нет записей на приём"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Appointment Details Dialog */}
      <Dialog open={appointmentDetailsDialog} onOpenChange={setAppointmentDetailsDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Детали записи на приём</DialogTitle>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Пациент</p>
                <p className="font-medium">{selectedAppointment.patient?.user?.full_name}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Дата</p>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span>{formatAppointmentDate(selectedAppointment.appointment_time)}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Время</p>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span>{formatAppointmentTime(selectedAppointment.appointment_time)}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Статус</p>
                <div className={`flex items-center ${getAppointmentStatusColor(selectedAppointment.status)}`}>
                  <span>{getAppointmentStatusText(selectedAppointment.status)}</span>
                </div>
              </div>

              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Тип приёма</p>
                <p>Запись на приём</p>
              </div>

              {selectedAppointment.patient?.user?.phone && (
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Телефон пациента</p>
                  <p className="text-sm">{selectedAppointment.patient.user.phone}</p>
                </div>
              )}

              <DialogFooter>
                {selectedAppointment.status === "scheduled" && (
                  <div className="flex flex-wrap gap-2 w-full">
                    <Button
                      variant="default"
                      onClick={() => {
                        setAppointmentDetailsDialog(false)
                        openActionDialog(selectedAppointment.id, "complete")
                      }}
                    >
                      Завершить приём
                    </Button>
                    <Button
                      variant="outline"
                      className="text-red-600"
                      onClick={() => {
                        setAppointmentDetailsDialog(false)
                        openActionDialog(selectedAppointment.id, "cancel")
                      }}
                    >
                      Отменить запись
                    </Button>
                  </div>
                )}
                {selectedAppointment.status === "completed" && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      setAppointmentDetailsDialog(false)
                      router.push(`/doctor/records?patient=${selectedAppointment.patient_id}`)
                    }}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Просмотр медкарты
                  </Button>
                )}
                <Button onClick={() => setAppointmentDetailsDialog(false)}>Закрыть</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Action Confirmation Dialog */}
      <Dialog open={confirmActionDialog} onOpenChange={setConfirmActionDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{actionType === "complete" ? "Завершение приёма" : "Отмена записи"}</DialogTitle>
            <DialogDescription>
              {actionType === "complete"
                ? "Вы уверены, что хотите отметить приём как завершенный? После этого вы сможете создать медицинскую запись."
                : "Вы уверены, что хотите отменить запись на приём? Это действие нельзя отменить."}
            </DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-4">
              <div className="p-4 border rounded-lg bg-muted/50">
                <div className="font-medium">{selectedAppointment.patient?.user?.full_name}</div>
                <div className="text-sm text-muted-foreground">Запись на приём</div>
                <div className="flex items-center mt-2 text-sm">
                  <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                  <span>{formatAppointmentDate(selectedAppointment.appointment_time)}</span>
                  <Clock className="h-4 w-4 ml-2 mr-1 text-muted-foreground" />
                  <span>{formatAppointmentTime(selectedAppointment.appointment_time)}</span>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setConfirmActionDialog(false)} disabled={isProcessing}>
                  Отмена
                </Button>
                <Button
                  variant={actionType === "cancel" ? "destructive" : "default"}
                  onClick={handleAppointmentAction}
                  disabled={isProcessing}
                >
                  {isProcessing
                    ? "Обработка..."
                    : actionType === "complete"
                      ? "Да, завершить приём"
                      : "Да, отменить запись"}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
