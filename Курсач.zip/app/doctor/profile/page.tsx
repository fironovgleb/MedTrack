"use client"

import { useState, useEffect } from "react"
import {
  User,
  Phone,
  MapPin,
  Pencil,
  Clock,
  Award,
  BookOpen,
  Stethoscope,
  Languages,
  FileText,
  Calendar,
} from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/components/supabase-provider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function DoctorProfile() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [doctorData, setDoctorData] = useState<any>(null)
  const [recentAppointments, setRecentAppointments] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [activeTab, setActiveTab] = useState("personal")
  const [tableNames, setTableNames] = useState({
    doctors: "Doctors",
    users: "Users",
    appointments: "Appointments",
    patients: "Patients",
  })

  // Состояния для редактируемых полей
  const [fullName, setFullName] = useState("")
  const [phone, setPhone] = useState("")
  const [specialization, setSpecialization] = useState("")
  const [office, setOffice] = useState("")
  const [education, setEducation] = useState("")
  const [experience, setExperience] = useState("")
  const [certifications, setCertifications] = useState("")
  const [languages, setLanguages] = useState("")
  const [bio, setBio] = useState("")
  const [workingHours, setWorkingHours] = useState("")

  // Состояние для ошибок валидации
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      detectTableNames()
    }
  }, [user, loading])

  useEffect(() => {
    if (!loading && user && user.role === "doctor" && tableNames.doctors) {
      fetchDoctorData()
      fetchRecentAppointments()
    }
  }, [user, loading, tableNames])

  // Функция для определения правильных имен таблиц
  const detectTableNames = async () => {
    try {
      // Проверка таблицы врачей
      const { error: upperDoctorsError } = await supabase.from("Doctors").select("user_id").limit(1)
      if (upperDoctorsError) {
        const { error: lowerDoctorsError } = await supabase.from("doctors").select("user_id").limit(1)
        if (!lowerDoctorsError) {
          setTableNames((prev) => ({ ...prev, doctors: "doctors" }))
        }
      }

      // Проверка таблицы пользователей
      const { error: upperUsersError } = await supabase.from("Users").select("id").limit(1)
      if (upperUsersError) {
        const { error: lowerUsersError } = await supabase.from("users").select("id").limit(1)
        if (!lowerUsersError) {
          setTableNames((prev) => ({ ...prev, users: "users" }))
        }
      }

      // Проверка таблицы записей на прием
      const { error: upperAppointmentsError } = await supabase.from("Appointments").select("id").limit(1)
      if (upperAppointmentsError) {
        const { error: lowerAppointmentsError } = await supabase.from("appointments").select("id").limit(1)
        if (!lowerAppointmentsError) {
          setTableNames((prev) => ({ ...prev, appointments: "appointments" }))
        }
      }

      // Проверка таблицы пациентов
      const { error: upperPatientsError } = await supabase.from("Patients").select("user_id").limit(1)
      if (upperPatientsError) {
        const { error: lowerPatientsError } = await supabase.from("patients").select("user_id").limit(1)
        if (!lowerPatientsError) {
          setTableNames((prev) => ({ ...prev, patients: "patients" }))
        }
      }
    } catch (error) {
      // Скрываем технические ошибки
    }
  }

  const fetchDoctorData = async () => {
    setIsLoading(true)
    try {
      // Получаем данные пользователя
      const { data: userData, error: userError } = await supabase
        .from(tableNames.users)
        .select("*")
        .eq("id", user.id)
        .single()

      if (userError) throw userError

      // Получаем данные врача
      const { data: doctorData, error: doctorError } = await supabase
        .from(tableNames.doctors)
        .select("*")
        .eq("user_id", user.id)
        .single()

      if (doctorError && doctorError.code !== "PGRST116") throw doctorError

      // Объединяем данные
      const combinedData = {
        ...userData,
        ...(doctorData || {}),
      }

      setDoctorData(combinedData)

      // Устанавливаем состояние формы
      setFullName(combinedData.full_name || "")
      setPhone(combinedData.phone || "")
      setSpecialization(combinedData.specialization || "")
      setOffice(combinedData.office_number || combinedData.office || "")
      setEducation(combinedData.education || "")
      setExperience(combinedData.experience || "")
      setCertifications(combinedData.certifications || "")
      setLanguages(combinedData.languages || "")
      setBio(combinedData.bio || "")
      setWorkingHours(combinedData.working_hours || "")
    } catch (error: any) {
      // Скрываем технические детали ошибки
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные профиля",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const fetchRecentAppointments = async () => {
    try {
      const { data, error } = await supabase
        .from(tableNames.appointments)
        .select(`
          id,
          appointment_time,
          status,
          patient:${tableNames.patients}(
            user:${tableNames.users}(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .order("appointment_time", { ascending: false })
        .limit(3)

      if (error) throw error

      setRecentAppointments(data || [])
    } catch (error: any) {
      // Скрываем технические ошибки
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    let isValid = true

    // Валидация номера телефона (если он указан)
    if (phone && !phone.match(/^\+7 $$\d{3}$$ \d{3}-\d{2}-\d{2}$/)) {
      newErrors.phone = "Пожалуйста, введите корректный номер телефона в формате +7 (XXX) XXX-XX-XX"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  const handleSaveProfile = async () => {
    if (!validateForm()) {
      return
    }

    setIsSaving(true)
    try {
      // Обновление данных в таблице users
      const { error: userError } = await supabase
        .from(tableNames.users)
        .update({
          full_name: fullName,
          phone: phone,
        })
        .eq("id", user.id)

      if (userError) throw userError

      // Определяем, какое поле использовать для номера кабинета
      const officeFieldName = doctorData.hasOwnProperty("office_number") ? "office_number" : "office"

      // Создаем объект с данными для обновления
      const doctorUpdateData: Record<string, any> = {
        specialization: specialization,
        education: education,
        experience: experience,
        certifications: certifications,
        languages: languages,
        bio: bio,
        working_hours: workingHours,
      }

      // Добавляем поле с номером кабинета
      doctorUpdateData[officeFieldName] = office

      // Обновление данных в таблице doctors
      const { error: doctorError } = await supabase
        .from(tableNames.doctors)
        .update(doctorUpdateData)
        .eq("user_id", user.id)

      if (doctorError) throw doctorError

      toast({
        title: "Успешно",
        description: "Профиль успешно обновлен",
      })

      setIsEditing(false)
      fetchDoctorData() // Обновление данных после сохранения
    } catch (error: any) {
      // Скрываем технические детали ошибки
      toast({
        title: "Ошибка",
        description: "Не удалось обновить профиль",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const getCompletionPercentage = () => {
    const fields = [
      fullName,
      phone,
      specialization,
      office,
      education,
      experience,
      certifications,
      languages,
      bio,
      workingHours,
    ]

    const filledFields = fields.filter((field) => field && field.trim() !== "").length
    return Math.round((filledFields / fields.length) * 100)
  }

  const completionPercentage = getCompletionPercentage()

  const getAppointmentStatusBadge = (status: string) => {
    switch (status) {
      case "scheduled":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Запланирован
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Завершен
          </Badge>
        )
      case "canceled":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Отменен
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return "Не указана"
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const formatTime = (dateString: string) => {
    if (!dateString) return ""
    return new Date(dateString).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold">Профиль врача</h1>
            <p className="text-muted-foreground">Управление профессиональной информацией и расписанием</p>
          </div>
          {!isEditing ? (
            <Button onClick={() => setIsEditing(true)} size="sm">
              <Pencil className="mr-2 h-4 w-4" />
              Редактировать
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving} size="sm">
                Отмена
              </Button>
              <Button onClick={handleSaveProfile} disabled={isSaving} size="sm">
                {isSaving ? "Сохранение..." : "Сохранить"}
              </Button>
            </div>
          )}
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Левая колонка - основная информация */}
            <div className="md:col-span-2 space-y-6">
              {isEditing ? (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Редактирование профиля</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="personal">Личные данные</TabsTrigger>
                        <TabsTrigger value="professional">Профессиональная информация</TabsTrigger>
                      </TabsList>
                      <TabsContent value="personal" className="space-y-4 mt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fullName">ФИО</Label>
                            <Input
                              id="fullName"
                              value={fullName}
                              onChange={(e) => setFullName(e.target.value)}
                              placeholder="Иванов Иван Иванович"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Номер телефона</Label>
                            <Input
                              id="phone"
                              value={phone}
                              onChange={(e) => setPhone(e.target.value)}
                              placeholder="+7 (999) 123-45-67"
                            />
                            {errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="office">Номер кабинета</Label>
                            <Input
                              id="office"
                              value={office}
                              onChange={(e) => setOffice(e.target.value)}
                              placeholder="123"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="workingHours">Часы приема</Label>
                            <Input
                              id="workingHours"
                              value={workingHours}
                              onChange={(e) => setWorkingHours(e.target.value)}
                              placeholder="Пн-Пт: 9:00-18:00"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="languages">Языки</Label>
                            <Input
                              id="languages"
                              value={languages}
                              onChange={(e) => setLanguages(e.target.value)}
                              placeholder="Русский, Английский"
                            />
                          </div>
                        </div>
                      </TabsContent>
                      <TabsContent value="professional" className="space-y-4 mt-4">
                        <div className="space-y-2">
                          <Label htmlFor="specialization">Специализация</Label>
                          <Select value={specialization} onValueChange={setSpecialization}>
                            <SelectTrigger id="specialization">
                              <SelectValue placeholder="Выберите специализацию" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Терапевт">Терапевт</SelectItem>
                              <SelectItem value="Кардиолог">Кардиолог</SelectItem>
                              <SelectItem value="Дерматолог">Дерматолог</SelectItem>
                              <SelectItem value="Невролог">Невролог</SelectItem>
                              <SelectItem value="Педиатр">Педиатр</SelectItem>
                              <SelectItem value="Психиатр">Психиатр</SelectItem>
                              <SelectItem value="Хирург">Хирург</SelectItem>
                              <SelectItem value="Офтальмолог">Офтальмолог</SelectItem>
                              <SelectItem value="Отоларинголог">Отоларинголог</SelectItem>
                              <SelectItem value="Гинеколог">Гинеколог</SelectItem>
                              <SelectItem value="Уролог">Уролог</SelectItem>
                              <SelectItem value="Эндокринолог">Эндокринолог</SelectItem>
                              <SelectItem value="Гастроэнтеролог">Гастроэнтеролог</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="education">Образование</Label>
                          <Textarea
                            id="education"
                            value={education}
                            onChange={(e) => setEducation(e.target.value)}
                            placeholder="Укажите ваше образование"
                            rows={2}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="experience">Опыт работы</Label>
                          <Textarea
                            id="experience"
                            value={experience}
                            onChange={(e) => setExperience(e.target.value)}
                            placeholder="Укажите ваш опыт работы"
                            rows={2}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="certifications">Сертификаты и лицензии</Label>
                          <Textarea
                            id="certifications"
                            value={certifications}
                            onChange={(e) => setCertifications(e.target.value)}
                            placeholder="Укажите ваши сертификаты и лицензии"
                            rows={2}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="bio">О себе</Label>
                          <Textarea
                            id="bio"
                            value={bio}
                            onChange={(e) => setBio(e.target.value)}
                            placeholder="Расскажите о себе"
                            rows={2}
                          />
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving}>
                      Отмена
                    </Button>
                    <Button onClick={handleSaveProfile} disabled={isSaving}>
                      {isSaving ? "Сохранение..." : "Сохранить"}
                    </Button>
                  </CardFooter>
                </Card>
              ) : (
                <>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Личная информация</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 mb-6">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                          <Stethoscope className="h-8 w-8 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-xl font-medium">{doctorData?.full_name || "Врач"}</h3>
                            <Badge className="ml-2">{doctorData?.specialization}</Badge>
                          </div>
                          <p className="text-muted-foreground">{doctorData?.email}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Телефон</p>
                          <p className="flex items-center">
                            <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                            {doctorData?.phone || "Не указан"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Кабинет</p>
                          <p className="flex items-center">
                            <MapPin className="h-4 w-4 text-muted-foreground mr-2" />
                            {doctorData?.office_number || doctorData?.office || "Не указан"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Часы приема</p>
                          <p className="flex items-center">
                            <Clock className="h-4 w-4 text-muted-foreground mr-2" />
                            {doctorData?.working_hours || "Не указаны"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Языки</p>
                          <p className="flex items-center">
                            <Languages className="h-4 w-4 text-muted-foreground mr-2" />
                            {doctorData?.languages || "Не указаны"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Профессиональная информация</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {doctorData?.education && (
                          <div>
                            <h4 className="text-sm font-medium mb-2 flex items-center">
                              <BookOpen className="h-4 w-4 mr-2 text-primary" />
                              Образование
                            </h4>
                            <p className="text-sm bg-muted/50 p-3 rounded">{doctorData.education}</p>
                          </div>
                        )}

                        {doctorData?.experience && (
                          <div>
                            <h4 className="text-sm font-medium mb-2 flex items-center">
                              <Award className="h-4 w-4 mr-2 text-amber-500" />
                              Опыт работы
                            </h4>
                            <p className="text-sm bg-muted/50 p-3 rounded">{doctorData.experience}</p>
                          </div>
                        )}

                        {doctorData?.certifications && (
                          <div>
                            <h4 className="text-sm font-medium mb-2 flex items-center">
                              <FileText className="h-4 w-4 mr-2 text-blue-500" />
                              Сертификаты и лицензии
                            </h4>
                            <p className="text-sm bg-muted/50 p-3 rounded">{doctorData.certifications}</p>
                          </div>
                        )}

                        {doctorData?.bio && (
                          <div>
                            <h4 className="text-sm font-medium mb-2 flex items-center">
                              <User className="h-4 w-4 mr-2 text-green-500" />О себе
                            </h4>
                            <p className="text-sm bg-muted/50 p-3 rounded">{doctorData.bio}</p>
                          </div>
                        )}

                        {!doctorData?.education &&
                          !doctorData?.experience &&
                          !doctorData?.certifications &&
                          !doctorData?.bio && (
                            <div className="text-center py-6">
                              <FileText className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                              <p className="text-sm text-muted-foreground">Профессиональная информация не заполнена</p>
                              <Button variant="outline" size="sm" className="mt-2" onClick={() => setIsEditing(true)}>
                                Заполнить информацию
                              </Button>
                            </div>
                          )}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            {/* Правая колонка - дополнительная информация */}
            <div className="space-y-6">
              {!isEditing && (
                <>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Заполненность профиля</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Прогресс</span>
                          <span>{completionPercentage}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2.5">
                          <div
                            className="bg-primary h-2.5 rounded-full"
                            style={{ width: `${completionPercentage}%` }}
                          ></div>
                        </div>
                        {completionPercentage < 70 && (
                          <p className="text-xs text-muted-foreground mt-2">
                            Заполните профессиональную информацию для улучшения доверия пациентов
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {recentAppointments.length > 0 ? (
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Ближайшие приемы</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {recentAppointments.map((appointment) => (
                            <div key={appointment.id} className="text-sm p-3 bg-muted/50 rounded-lg">
                              <div className="flex justify-between items-center">
                                <span className="font-medium">{appointment.patient?.user?.full_name}</span>
                                {getAppointmentStatusBadge(appointment.status)}
                              </div>
                              <div className="flex items-center mt-1 text-xs text-muted-foreground">
                                <Calendar className="h-3 w-3 mr-1" />
                                <span>{formatDate(appointment.appointment_time)}</span>
                                <Clock className="h-3 w-3 ml-2 mr-1" />
                                <span>{formatTime(appointment.appointment_time)}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full mt-3"
                          onClick={() => (window.location.href = "/doctor/appointments")}
                        >
                          Все приемы
                        </Button>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Приемы</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center py-6">
                          <Calendar className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                          <p className="text-sm text-muted-foreground">У вас пока нет запланированных приемов</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <Alert>
                    <Stethoscope className="h-4 w-4" />
                    <AlertTitle>Совет</AlertTitle>
                    <AlertDescription>
                      Заполненный профиль с подробной информацией о вашем опыте и квалификации повышает доверие
                      пациентов.
                    </AlertDescription>
                  </Alert>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
