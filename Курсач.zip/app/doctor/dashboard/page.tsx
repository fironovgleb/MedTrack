"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Clock, FileText, User, Calendar } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { Skeleton } from "@/components/ui/skeleton"

interface Appointment {
  id: number
  patient_id: number
  appointment_time: string
  status: string
  patient: {
    user_id: number
    user: {
      full_name: string
    }
  }
}

interface MedicalRecord {
  id: number
  patient_id: number
  visit_date: string
  diagnosis: string
  patient: {
    user_id: number
    user: {
      full_name: string
    }
  }
}

export default function DoctorDashboard() {
  const router = useRouter()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [todayAppointments, setTodayAppointments] = useState<Appointment[]>([])
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>([])
  const [patientsCount, setPatientsCount] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  useEffect(() => {
    if (!loading && user && user.role === "doctor") {
      fetchData()
    }
  }, [user, loading, refreshTrigger])

  // Set up a refresh interval (every 2 minutes)
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTrigger((prev) => prev + 1)
    }, 120000)

    return () => clearInterval(interval)
  }, [])

  const fetchData = async () => {
    setIsLoading(true)
    try {
      // Получение всех записей на приём
      const { data: appointmentsData, error: appointmentsError } = await supabase
        .from("appointments")
        .select(`
          id,
          patient_id,
          appointment_time,
          status,
          patient:patients(
            user_id,
            user:users(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .eq("status", "scheduled")
        .order("appointment_time", { ascending: true })
        .limit(5)

      if (appointmentsError) {
        console.error("Error fetching appointments:", appointmentsError)
        throw appointmentsError
      }
      setAppointments(appointmentsData || [])

      // Получение записей на сегодня
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)

      const { data: todayData, error: todayError } = await supabase
        .from("appointments")
        .select(`
          id,
          patient_id,
          appointment_time,
          status,
          patient:patients(
            user_id,
            user:users(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .eq("status", "scheduled")
        .gte("appointment_time", today.toISOString())
        .lt("appointment_time", tomorrow.toISOString())
        .order("appointment_time", { ascending: true })

      if (todayError) {
        console.error("Error fetching today's appointments:", todayError)
        throw todayError
      }
      setTodayAppointments(todayData || [])

      // Получение последних медицинских записей
      const { data: recordsData, error: recordsError } = await supabase
        .from("medicalrecords")
        .select(`
          id,
          patient_id,
          visit_date,
          diagnosis,
          patient:patients(
            user_id,
            user:users(
              full_name
            )
          )
        `)
        .eq("doctor_id", user.id)
        .order("visit_date", { ascending: false })
        .limit(5)

      if (recordsError) {
        console.error("Error fetching medical records:", recordsError)
        throw recordsError
      }
      setMedicalRecords(recordsData || [])

      // Получение количества уникальных пациентов
      const { data: uniquePatientsData, error: uniquePatientsError } = await supabase
        .from("medicalrecords")
        .select("patient_id", { count: "exact", head: true })
        .eq("doctor_id", user.id)

      if (uniquePatientsError) {
        console.error("Error fetching unique patients:", uniquePatientsError)
        throw uniquePatientsError
      }
      setPatientsCount(uniquePatientsData?.length || 0)
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить данные",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "scheduled":
        return (
          <Badge variant="outline" className="text-blue-500 border-blue-500">
            Запланирован
          </Badge>
        )
      case "completed":
        return (
          <Badge variant="outline" className="text-green-500 border-green-500">
            Завершен
          </Badge>
        )
      case "canceled":
        return (
          <Badge variant="outline" className="text-red-500 border-red-500">
            Отменен
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  // Check if appointment is soon (within the next hour)
  const isAppointmentSoon = (dateString: string) => {
    const appointmentTime = new Date(dateString)
    const now = new Date()
    const diffMs = appointmentTime.getTime() - now.getTime()
    const diffHours = diffMs / (1000 * 60 * 60)
    return diffHours > 0 && diffHours <= 1
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Панель управления</h1>
        <p className="text-muted-foreground">
          Добро пожаловать, {user?.full_name}! Здесь вы можете управлять вашими записями и медицинскими картами
          пациентов.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Записи на сегодня</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <Skeleton className="h-8 w-16" /> : todayAppointments.length}
              </div>
              <p className="text-xs text-muted-foreground">Запланированные приёмы на сегодня</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Всего приёмов</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <Skeleton className="h-8 w-16" /> : appointments.length}
              </div>
              <p className="text-xs text-muted-foreground">Активные записи на приём к вам</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Медицинские записи</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <Skeleton className="h-8 w-16" /> : medicalRecords.length}
              </div>
              <p className="text-xs text-muted-foreground">Созданные вами медицинские записи</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Пациенты</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{isLoading ? <Skeleton className="h-8 w-16" /> : patientsCount}</div>
              <p className="text-xs text-muted-foreground">Количество ваших пациентов</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Записи на сегодня</CardTitle>
              <CardDescription>Пациенты, записанные к вам на сегодня</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex flex-col space-y-2">
                      <Skeleton className="h-5 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                      <Skeleton className="h-4 w-1/4" />
                    </div>
                  ))}
                </div>
              ) : todayAppointments.length > 0 ? (
                <div className="space-y-4">
                  {todayAppointments.map((appointment) => (
                    <div
                      key={appointment.id}
                      className={`flex flex-col space-y-2 p-3 border rounded-lg ${
                        isAppointmentSoon(appointment.appointment_time) ? "border-orange-300 bg-orange-50" : ""
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <User className="h-5 w-5 text-muted-foreground mr-2" />
                          <span className="font-medium">{appointment.patient?.user?.full_name}</span>
                        </div>
                        {getStatusBadge(appointment.status)}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{formatTime(appointment.appointment_time)}</span>
                      </div>
                      {isAppointmentSoon(appointment.appointment_time) && (
                        <div className="text-sm text-orange-600 font-medium">Скоро начнется!</div>
                      )}
                      <div className="flex justify-end">
                        <Button size="sm" onClick={() => router.push(`/doctor/appointments/${appointment.id}`)}>
                          Начать приём
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">У вас нет записей на сегодня</div>
              )}
              {appointments.length > 0 && (
                <div className="mt-4 text-center">
                  <Button variant="outline" onClick={() => router.push("/doctor/appointments")}>
                    Посмотреть все записи
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Недавние медицинские записи</CardTitle>
              <CardDescription>Последние созданные вами медицинские записи</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex flex-col space-y-2">
                      <Skeleton className="h-5 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                      <Skeleton className="h-4 w-1/4" />
                    </div>
                  ))}
                </div>
              ) : medicalRecords.length > 0 ? (
                <div className="space-y-4">
                  {medicalRecords.map((record) => (
                    <div key={record.id} className="flex flex-col space-y-2 p-3 border rounded-lg">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-muted-foreground mr-2" />
                        <span className="font-medium">Запись от {formatDate(record.visit_date)}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">Пациент: {record.patient?.user?.full_name}</div>
                      <div className="text-sm">
                        <span className="font-medium">Диагноз:</span> {record.diagnosis}
                      </div>
                      <div className="flex justify-end">
                        <Button variant="outline" size="sm" onClick={() => router.push(`/doctor/records/${record.id}`)}>
                          Подробнее
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">У вас нет медицинских записей</div>
              )}
              {medicalRecords.length > 0 && (
                <div className="mt-4 text-center">
                  <Button variant="outline" onClick={() => router.push("/doctor/records")}>
                    Посмотреть все записи
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Быстрые действия</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Button variant="outline" onClick={() => router.push("/doctor/appointments")}>
                <Calendar className="h-4 w-4 mr-2" />
                Все записи
              </Button>
              <Button variant="outline" onClick={() => router.push("/doctor/schedule")}>
                <Clock className="h-4 w-4 mr-2" />
                Расписание
              </Button>
              <Button variant="outline" onClick={() => router.push("/doctor/patients")}>
                <User className="h-4 w-4 mr-2" />
                Пациенты
              </Button>
              <Button variant="outline" onClick={() => router.push("/doctor/records")}>
                <FileText className="h-4 w-4 mr-2" />
                Медкарты
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
