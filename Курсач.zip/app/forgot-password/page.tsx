"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/components/supabase-provider"

export default function ForgotPasswordPage() {
  const { supabase } = useSupabase()
  const { toast } = useToast()

  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setSuccess(false)

    try {
      // Проверяем, существует ли пользователь с таким email
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("*")
        .eq("email", email)
        .maybeSingle()

      if (userError) {
        throw new Error("Ошибка при проверке email")
      }

      if (!userData) {
        throw new Error("Пользователь с таким email не найден")
      }

      // Отправляем письмо для сброса пароля
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      })

      if (resetError) {
        throw resetError
      }

      setSuccess(true)
      toast({
        title: "Письмо отправлено",
        description: "Проверьте вашу электронную почту для сброса пароля",
      })
    } catch (error: any) {
      setError(error.message || "Ошибка при отправке письма для сброса пароля")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        <div className="bg-white p-8 rounded-lg shadow-sm border">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Восстановление пароля</h1>
            <p className="text-gray-600 mt-1">Введите ваш email для сброса пароля</p>
          </div>

          {error && <div className="bg-red-50 text-red-700 p-3 rounded-md mb-4 text-sm">{error}</div>}

          {success ? (
            <div className="text-center space-y-4">
              <div className="bg-green-50 text-green-700 p-3 rounded-md mb-4 text-sm">
                Письмо с инструкциями по сбросу пароля отправлено на ваш email.
              </div>
              <p className="text-sm text-gray-600">
                Не получили письмо?{" "}
                <button onClick={handleResetPassword} className="text-blue-600 hover:underline" disabled={loading}>
                  Отправить повторно
                </button>
              </p>
              <Link href="/login" className="text-blue-600 hover:underline block">
                Вернуться на страницу входа
              </Link>
            </div>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ваш@email.com"
                  required
                  className="mt-1"
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Отправка..." : "Отправить инструкции"}
              </Button>

              <p className="text-center text-sm text-gray-600 mt-4">
                Вспомнили пароль?{" "}
                <Link href="/login" className="text-blue-600 hover:underline">
                  Войти
                </Link>
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
