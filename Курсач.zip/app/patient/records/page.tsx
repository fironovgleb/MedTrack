"use client"

import { useState, useEffect } from "react"
import { Calendar, FileText, Search, User } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useSupabase } from "@/components/supabase-provider"
import { useAuth } from "@/contexts/auth-context"
import { formatDate } from "@/lib/utils"

interface MedicalRecord {
  id: number
  doctor_id: number
  visit_date: string
  diagnosis: string
  treatment: string
  comments: string
  doctor_name?: string
  doctor_specialization?: string
}

export default function PatientRecords() {
  const { user } = useAuth()
  const { supabase } = useSupabase()
  const [records, setRecords] = useState<MedicalRecord[]>([])
  const [filteredRecords, setFilteredRecords] = useState<MedicalRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null)
  const [openDialog, setOpenDialog] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (user) {
      fetchRecords()
    }
  }, [user])

  useEffect(() => {
    filterRecords()
  }, [records, searchQuery])

  const fetchRecords = async () => {
    setLoading(true)
    setError(null)

    try {
      console.log("Fetching medical records...")

      // First, fetch the medical records
      const { data: medicalRecords, error: recordsError } = await supabase
        .from("medicalrecords")
        .select("*")
        .eq("patient_id", user?.id)
        .order("visit_date", { ascending: false })

      if (recordsError) {
        console.error("Error fetching medical records:", recordsError)
        throw new Error(`Ошибка при получении записей: ${recordsError.message}`)
      }

      if (!medicalRecords || medicalRecords.length === 0) {
        setRecords([])
        setFilteredRecords([])
        setLoading(false)
        return
      }

      // Get all unique doctor IDs from the records
      const doctorIds = [...new Set(medicalRecords.map((record) => record.doctor_id))]

      // Fetch doctor information separately
      const { data: doctors, error: doctorsError } = await supabase
        .from("doctors")
        .select("user_id, specialization")
        .in("user_id", doctorIds)

      if (doctorsError) {
        console.error("Error fetching doctors:", doctorsError)
        // Continue with partial data
      }

      // Create a map of doctor IDs to specializations
      const doctorSpecializations = new Map()
      if (doctors) {
        doctors.forEach((doctor) => {
          doctorSpecializations.set(doctor.user_id, doctor.specialization || "Общая практика")
        })
      }

      // Fetch user information for doctors
      const { data: users, error: usersError } = await supabase
        .from("users")
        .select("id, full_name")
        .in("id", doctorIds)

      if (usersError) {
        console.error("Error fetching users:", usersError)
        // Continue with partial data
      }

      // Create a map of user IDs to names
      const userNames = new Map()
      if (users) {
        users.forEach((user) => {
          userNames.set(user.id, user.full_name)
        })
      }

      // Combine the data
      const enrichedRecords = medicalRecords.map((record) => ({
        ...record,
        doctor_name: userNames.get(record.doctor_id) || "Неизвестный врач",
        doctor_specialization: doctorSpecializations.get(record.doctor_id) || "Неизвестная специализация",
      }))

      setRecords(enrichedRecords)
      setFilteredRecords(enrichedRecords)
    } catch (error: any) {
      console.error("Error in fetchRecords:", error)
      setError(error.message || "Не удалось загрузить медицинские записи")
    } finally {
      setLoading(false)
    }
  }

  const filterRecords = () => {
    if (!searchQuery) {
      setFilteredRecords(records)
      return
    }

    const query = searchQuery.toLowerCase()
    const filtered = records.filter(
      (record) =>
        record.diagnosis.toLowerCase().includes(query) ||
        record.treatment.toLowerCase().includes(query) ||
        (record.doctor_name && record.doctor_name.toLowerCase().includes(query)) ||
        (record.doctor_specialization && record.doctor_specialization.toLowerCase().includes(query)),
    )

    setFilteredRecords(filtered)
  }

  const openRecordDetails = (record: MedicalRecord) => {
    setSelectedRecord(record)
    setOpenDialog(true)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Медицинские записи</h1>
          <p className="text-muted-foreground">Просмотр вашей истории болезни и записей о лечении</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Все записи</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative mb-6">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Поиск по диагнозу, лечению или врачу..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {loading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="h-24 bg-muted animate-pulse rounded" />
                ))}
              </div>
            ) : error ? (
              <div className="text-center py-10 text-red-500">
                <p>{error}</p>
                <Button onClick={fetchRecords} className="mt-4">
                  Повторить попытку
                </Button>
              </div>
            ) : filteredRecords.length > 0 ? (
              <div className="space-y-4">
                {filteredRecords.map((record) => (
                  <div
                    key={record.id}
                    className="p-4 border rounded-lg cursor-pointer hover:bg-muted/50"
                    onClick={() => openRecordDetails(record)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <FileText className="h-5 w-5 text-blue-500 mr-2" />
                        <span className="font-medium">Визит {formatDate(record.visit_date)}</span>
                      </div>
                      <Button variant="ghost" size="sm" className="text-blue-600">
                        Подробнее
                      </Button>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-muted-foreground">
                      <User className="h-4 w-4 mr-1" />
                      <span>
                        Врач: {record.doctor_name} ({record.doctor_specialization})
                      </span>
                    </div>
                    <div className="mt-2 text-sm">
                      <span className="font-medium">Диагноз:</span> {record.diagnosis}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                {records.length > 0 ? "Нет записей, соответствующих поиску" : "У вас еще нет медицинских записей"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Детали медицинской записи</DialogTitle>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Дата визита</p>
                  <p className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    {formatDate(selectedRecord.visit_date)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Врач</p>
                  <p className="flex items-center">
                    <User className="h-4 w-4 mr-2 text-muted-foreground" />
                    {selectedRecord.doctor_name}
                  </p>
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Специализация</p>
                <p>{selectedRecord.doctor_specialization}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Диагноз</p>
                <p className="p-2 bg-muted rounded-md">{selectedRecord.diagnosis}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Лечение</p>
                <p className="p-2 bg-muted rounded-md whitespace-pre-line">{selectedRecord.treatment}</p>
              </div>
              {selectedRecord.comments && (
                <div>
                  <p className="text-sm text-muted-foreground">Комментарии</p>
                  <p className="p-2 bg-muted rounded-md whitespace-pre-line">{selectedRecord.comments}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
