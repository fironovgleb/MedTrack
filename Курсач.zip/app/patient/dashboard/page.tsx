"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Calendar, FileText, AlertCircle } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useSupabase } from "@/components/supabase-provider"
import { useAuth } from "@/contexts/auth-context"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"

interface Appointment {
  id: number
  doctor_id: number
  appointment_time: string
  status: string
  doctor: {
    specialization: string
    user: {
      full_name: string
    }
  }
}

interface MedicalRecord {
  id: number
  doctor_id: number
  visit_date: string
  diagnosis: string
  doctor: {
    specialization: string
    user: {
      full_name: string
    }
  }
}

export default function PatientDashboard() {
  const { user } = useAuth()
  const { supabase } = useSupabase()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [records, setRecords] = useState<MedicalRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  useEffect(() => {
    if (user) {
      fetchData()
    }
  }, [user, refreshTrigger])

  // Set up a refresh interval (every 2 minutes)
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTrigger((prev) => prev + 1)
    }, 120000)

    return () => clearInterval(interval)
  }, [])

  const fetchData = async () => {
    setLoading(true)
    try {
      console.log("Fetching patient dashboard data for user:", user?.id)

      // Получение записей на приём
      const { data: appointmentsData, error: appointmentsError } = await supabase
        .from("appointments")
        .select(`
        id,
        doctor_id,
        appointment_time,
        status,
        doctor:doctors(
          specialization,
          user:users(
            full_name
          )
        )
      `)
        .eq("patient_id", user?.id)
        .eq("status", "scheduled")
        .order("appointment_time", { ascending: true })
        .limit(3)

      if (appointmentsError) {
        console.error("Error fetching appointments:", appointmentsError)
        throw appointmentsError
      }

      console.log("Fetched appointments:", appointmentsData)
      setAppointments(appointmentsData || [])

      // Получение медицинских записей
      const { data: recordsData, error: recordsError } = await supabase
        .from("medicalrecords")
        .select(`
          id,
          doctor_id,
          visit_date,
          diagnosis,
          doctor:doctors(
            specialization,
            user:users(
              full_name
            )
          )
        `)
        .eq("patient_id", user?.id)
        .order("visit_date", { ascending: false })
        .limit(3)

      if (recordsError) {
        console.error("Error fetching medical records:", recordsError)
        throw recordsError
      }

      setRecords(recordsData || [])
    } catch (error) {
      console.error("Ошибка при получении данных:", error)
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU")
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
  }

  // Check if appointment is today
  const isToday = (dateString: string) => {
    const appointmentDate = new Date(dateString)
    const today = new Date()
    return (
      appointmentDate.getDate() === today.getDate() &&
      appointmentDate.getMonth() === today.getMonth() &&
      appointmentDate.getFullYear() === today.getFullYear()
    )
  }

  // Check if appointment is soon (within the next hour)
  const isAppointmentSoon = (dateString: string) => {
    const appointmentTime = new Date(dateString)
    const now = new Date()
    const diffMs = appointmentTime.getTime() - now.getTime()
    const diffHours = diffMs / (1000 * 60 * 60)
    return diffHours > 0 && diffHours <= 1
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Добро пожаловать, {user?.full_name}</h1>
          <p className="text-gray-600">Управляйте вашими медицинскими записями и приёмами</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Предстоящие приёмы */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-lg">
                <Calendar className="h-5 w-5 mr-2 text-blue-500" />
                Предстоящие приёмы
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  {[...Array(2)].map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : appointments.length > 0 ? (
                <div className="space-y-3">
                  {appointments.map((appointment) => (
                    <div
                      key={appointment.id}
                      className={`p-3 border rounded-md ${
                        isAppointmentSoon(appointment.appointment_time)
                          ? "border-orange-300 bg-orange-50"
                          : isToday(appointment.appointment_time)
                            ? "border-blue-300 bg-blue-50"
                            : ""
                      }`}
                    >
                      <div className="font-medium">{appointment.doctor?.user?.full_name}</div>
                      <div className="text-sm text-gray-600">{appointment.doctor?.specialization}</div>
                      <div className="flex items-center justify-between mt-1">
                        <div className="text-sm text-gray-500">
                          {formatDate(appointment.appointment_time)} в {formatTime(appointment.appointment_time)}
                        </div>
                        {isToday(appointment.appointment_time) && (
                          <Badge variant="outline" className="text-blue-600 border-blue-600">
                            Сегодня
                          </Badge>
                        )}
                      </div>
                      {isAppointmentSoon(appointment.appointment_time) && (
                        <div className="mt-1 text-sm text-orange-600 flex items-center">
                          <AlertCircle className="h-4 w-4 mr-1" />
                          Скоро начнется!
                        </div>
                      )}
                    </div>
                  ))}
                  <div className="mt-2">
                    <Link href="/patient/appointments">
                      <Button variant="outline" size="sm" className="w-full">
                        Все приёмы
                      </Button>
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-gray-500">
                  Нет предстоящих приёмов
                  <div className="mt-2">
                    <Link href="/patient/appointments/new">
                      <Button size="sm">Записаться на приём</Button>
                    </Link>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Недавние медицинские записи */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center text-lg">
                <FileText className="h-5 w-5 mr-2 text-blue-500" />
                Недавние медицинские записи
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  {[...Array(2)].map((_, i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : records.length > 0 ? (
                <div className="space-y-3">
                  {records.map((record) => (
                    <div key={record.id} className="p-3 border rounded-md">
                      <div className="font-medium">Визит {formatDate(record.visit_date)}</div>
                      <div className="text-sm text-gray-600">Врач: {record.doctor?.user?.full_name}</div>
                      <div className="text-sm text-gray-500 mt-1">Диагноз: {record.diagnosis}</div>
                    </div>
                  ))}
                  <div className="mt-2">
                    <Link href="/patient/records">
                      <Button variant="outline" size="sm" className="w-full">
                        Все записи
                      </Button>
                    </Link>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-gray-500">Медицинских записей не найдено</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Быстрые действия */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Быстрые действия</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Link href="/patient/appointments/new">
                <Button variant="outline" className="w-full">
                  <Calendar className="h-4 w-4 mr-2" />
                  Новый приём
                </Button>
              </Link>
              <Link href="/patient/profile">
                <Button variant="outline" className="w-full">
                  <FileText className="h-4 w-4 mr-2" />
                  Мой профиль
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
