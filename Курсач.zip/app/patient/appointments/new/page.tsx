"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Calendar, Clock, User, MapPin, Phone, Info, AlertCircle } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { TimeSlotPicker } from "@/components/appointment/time-slot-picker"

interface Doctor {
  user_id: number
  specialization: string
  office: string | null
  languages: string | null
  user: {
    full_name: string
    email: string
    phone: string | null
  }
}

export default function NewAppointment() {
  const router = useRouter()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [specializations, setSpecializations] = useState<string[]>([])
  const [selectedSpecialization, setSelectedSpecialization] = useState("")
  const [selectedDoctor, setSelectedDoctor] = useState("")
  const [date, setDate] = useState("")
  const [time, setTime] = useState("")
  const [notes, setNotes] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([])
  const [error, setError] = useState<string | null>(null)
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({})

  // Add appointment type selection
  const [appointmentType, setAppointmentType] = useState("")
  const [appointmentTypes] = useState([
    "Первичный прием",
    "Повторный прием",
    "Консультация",
    "Диагностика",
    "Процедура",
  ])

  useEffect(() => {
    if (!loading && user && user.role === "patient") {
      fetchDoctors()
      // Set default date to today
      const today = new Date().toISOString().split("T")[0]
      setDate(today)
    }
  }, [user, loading])

  useEffect(() => {
    // Filter doctors by selected specialization
    if (selectedSpecialization && selectedSpecialization !== "all") {
      setFilteredDoctors(doctors.filter((doctor) => doctor.specialization === selectedSpecialization))
    } else {
      setFilteredDoctors(doctors)
    }

    // Reset selected doctor when specialization changes
    setSelectedDoctor("")
    setTime("")
  }, [selectedSpecialization, doctors])

  const fetchDoctors = async () => {
    setIsLoading(true)
    setError(null)

    try {
      console.log("Fetching doctors...")

      // Определяем имя таблицы doctors
      let doctorsTableName = "doctors"
      let usersTableName = "users"

      // Проверяем таблицу doctors
      const { error: doctorsError } = await supabase.from("doctors").select("user_id").limit(1)

      if (doctorsError) {
        // Пробуем с заглавной буквы
        const { error: upperCaseDoctorsError } = await supabase.from("Doctors").select("user_id").limit(1)

        if (!upperCaseDoctorsError) {
          doctorsTableName = "Doctors"
        } else {
          throw new Error("Не удалось получить доступ к таблице врачей")
        }
      }

      // Проверяем таблицу users
      const { error: usersError } = await supabase.from("users").select("id").limit(1)

      if (usersError) {
        // Пробуем с заглавной буквы
        const { error: upperCaseUsersError } = await supabase.from("Users").select("id").limit(1)

        if (!upperCaseUsersError) {
          usersTableName = "Users"
        } else {
          throw new Error("Не удалось получить доступ к таблице пользователей")
        }
      }

      // Get the column names from the first row to check what's available
      const { data: tableInfo } = await supabase.from(doctorsTableName).select("*").limit(1)
      const availableColumns = tableInfo && tableInfo.length > 0 ? Object.keys(tableInfo[0]) : []
      console.log("Available columns in doctors table:", availableColumns)

      // Build the query based on available columns
      let query = `
        user_id,
        specialization,
        office
      `

      // Add optional columns if they exist
      if (availableColumns.includes("languages")) {
        query += `, languages`
      }

      // Now fetch the actual doctor data
      const { data: doctorsData, error: doctorsDataError } = await supabase.from(doctorsTableName).select(query)

      if (doctorsDataError) {
        console.error("Error fetching doctors:", doctorsDataError)
        throw new Error(`Не удалось загрузить список врачей: ${doctorsDataError.message}`)
      }

      // Fetch user information for each doctor
      const doctorUserIds = doctorsData.map((doctor) => doctor.user_id)
      const { data: usersData, error: usersDataError } = await supabase
        .from(usersTableName)
        .select("id, full_name, email, phone")
        .in("id", doctorUserIds)

      if (usersDataError) {
        console.error("Error fetching user data for doctors:", usersDataError)
        throw new Error(`Не удалось загрузить информацию о врачах: ${usersDataError.message}`)
      }

      // Create a map of user data
      const userMap = new Map()
      usersData.forEach((user) => {
        userMap.set(user.id, user)
      })

      // Combine doctor and user data
      const combinedData = doctorsData.map((doctor) => ({
        ...doctor,
        user: userMap.get(doctor.user_id) || { full_name: "Неизвестный врач", email: "", phone: null },
      }))

      console.log("Combined doctor data:", combinedData)

      if (!combinedData || combinedData.length === 0) {
        setDoctors([])
        setSpecializations([])
        setFilteredDoctors([])
        setError("В системе не найдено ни одного врача. Пожалуйста, обратитесь к администратору.")
        return
      }

      const doctorsWithDefaults = combinedData.map((doctor) => ({
        ...doctor,
        specialization: doctor.specialization || "Общая практика", // Provide default if missing
      }))

      setDoctors(doctorsWithDefaults)

      // Extract unique specializations
      const uniqueSpecializations = Array.from(
        new Set(doctorsWithDefaults.map((doctor) => doctor.specialization || "Общая практика")),
      ).filter(Boolean) // Remove any empty values

      console.log("Unique specializations:", uniqueSpecializations)
      setSpecializations(uniqueSpecializations)
      setFilteredDoctors(doctorsWithDefaults)
    } catch (error: any) {
      console.error("Error in fetchDoctors:", error)
      setError(error.message || "Не удалось загрузить список врачей")
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить список врачей",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Update the form validation
  const validateForm = () => {
    const errors: Record<string, string> = {}
    let isValid = true

    if (!selectedDoctor) {
      errors.doctor = "Пожалуйста, выберите врача"
      isValid = false
    }

    if (!date) {
      errors.date = "Пожалуйста, выберите дату"
      isValid = false
    }

    if (!time) {
      errors.time = "Пожалуйста, выберите время"
      isValid = false
    }

    if (!appointmentType) {
      errors.appointmentType = "Пожалуйста, выберите тип приема"
      isValid = false
    }

    // Create date and time in ISO format
    if (date && time) {
      const appointmentTime = new Date(`${date}T${time}:00`)

      // Check if date is not in the past
      if (appointmentTime < new Date()) {
        errors.date = "Нельзя записаться на прием в прошлом"
        isValid = false
      }
    }

    setValidationErrors(errors)

    if (!isValid) {
      // Показываем только первую ошибку в тосте
      const firstError = Object.values(errors)[0]
      toast({
        title: "Ошибка валидации",
        description: firstError,
        variant: "destructive",
      })
    }

    return isValid
  }

  // Update the handleSubmit function to include appointment type
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsSubmitting(true)

    try {
      // Определяем имя таблицы appointments
      let appointmentsTableName = "appointments"

      // Проверяем таблицу appointments
      const { error: appointmentsError } = await supabase.from("appointments").select("id").limit(1)

      if (appointmentsError) {
        // Пробуем с заглавной буквы
        const { error: upperCaseAppointmentsError } = await supabase.from("Appointments").select("id").limit(1)

        if (!upperCaseAppointmentsError) {
          appointmentsTableName = "Appointments"
        } else {
          throw new Error("Не удалось получить доступ к таблице записей на прием")
        }
      }

      // Create date and time in ISO format
      const appointmentTime = new Date(`${date}T${time}:00`)

      // Check for overlapping appointments
      const { data: existingAppointments, error: checkError } = await supabase
        .from(appointmentsTableName)
        .select("id")
        .eq("doctor_id", selectedDoctor)
        .eq("status", "scheduled")
        .gte("appointment_time", new Date(appointmentTime.getTime() - 15 * 60 * 1000).toISOString())
        .lte("appointment_time", new Date(appointmentTime.getTime() + 15 * 60 * 1000).toISOString())

      if (checkError) {
        console.error("Error checking existing appointments:", checkError)
        throw new Error("Не удалось проверить доступность времени")
      }

      if (existingAppointments && existingAppointments.length > 0) {
        toast({
          title: "Время занято",
          description: "Выбранное время уже занято. Пожалуйста, выберите другое время",
          variant: "destructive",
        })
        setIsSubmitting(false)
        return
      }

      // Check if patient already has an appointment at the same time
      const { data: patientExistingAppointments, error: patientCheckError } = await supabase
        .from(appointmentsTableName)
        .select("id")
        .eq("patient_id", user.id)
        .eq("status", "scheduled")
        .gte("appointment_time", new Date(appointmentTime.getTime() - 15 * 60 * 1000).toISOString())
        .lte("appointment_time", new Date(appointmentTime.getTime() + 15 * 60 * 1000).toISOString())

      if (patientCheckError) {
        console.error("Error checking patient existing appointments:", patientCheckError)
        throw new Error("Не удалось проверить ваши существующие записи")
      }

      if (patientExistingAppointments && patientExistingAppointments.length > 0) {
        toast({
          title: "Конфликт записей",
          description: "У вас уже есть запись на прием в это время",
          variant: "destructive",
        })
        setIsSubmitting(false)
        return
      }

      // Create new appointment with required fields only
      const appointmentData: any = {
        patient_id: user.id,
        doctor_id: selectedDoctor,
        appointment_time: appointmentTime.toISOString(),
        status: "scheduled",
      }

      // Check if notes column exists before adding it
      try {
        const { data: notesColumnCheck, error: notesColumnError } = await supabase
          .from(appointmentsTableName)
          .select("notes")
          .limit(1)

        // If no error, the column exists
        if (!notesColumnError && notes) {
          appointmentData.notes = notes
        }
      } catch (e) {
        console.log("notes column doesn't exist, skipping")
      }

      // Check if appointment_type column exists before adding it
      try {
        const { data: columnCheck, error: columnError } = await supabase
          .from(appointmentsTableName)
          .select("appointment_type")
          .limit(1)

        // If no error, the column exists
        if (!columnError) {
          appointmentData.appointment_type = appointmentType
        }
      } catch (e) {
        console.log("appointment_type column doesn't exist, skipping")
      }

      const { data: newAppointment, error } = await supabase
        .from(appointmentsTableName)
        .insert([appointmentData])
        .select()

      if (error) {
        console.error("Error creating appointment:", error)
        throw error
      }

      // Определяем имя таблицы auditlogs
      let auditLogsTableName = "auditlogs"

      // Проверяем таблицу auditlogs
      const { error: auditLogsError } = await supabase.from("auditlogs").select("id").limit(1)

      if (auditLogsError) {
        // Пробуем с заглавной буквы
        const { error: upperCaseAuditLogsError } = await supabase.from("AuditLogs").select("id").limit(1)

        if (!upperCaseAuditLogsError) {
          auditLogsTableName = "AuditLogs"
        }
      }

      // Add audit log
      const { error: auditError } = await supabase.from(auditLogsTableName).insert([
        {
          user_id: user.id,
          action: "create_appointment",
          target_type: "appointment",
          target_id: newAppointment?.[0]?.id || null,
          timestamp: new Date().toISOString(),
        },
      ])

      if (auditError) {
        console.error("Error creating audit log:", auditError)
      }

      toast({
        title: "Успешно",
        description: "Вы успешно записались на прием",
      })

      router.push("/patient/appointments")
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось создать запись на прием",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Получение минимальной даты (сегодня)
  // Get minimum date (today)
  const getMinDate = () => {
    const today = new Date()
    return today.toISOString().split("T")[0]
  }

  // Get maximum date (3 months from now)
  const getMaxDate = () => {
    const maxDate = new Date()
    maxDate.setMonth(maxDate.getMonth() + 3)
    return maxDate.toISOString().split("T")[0]
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Новая запись на прием</h1>
            <p className="text-muted-foreground">Запишитесь на прием к врачу</p>
          </div>
          <Button variant="outline" onClick={() => router.push("/patient/appointments")}>
            Назад к записям
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Форма записи</CardTitle>
            <CardDescription>Заполните форму для записи на прием к врачу</CardDescription>
          </CardHeader>

          {error ? (
            <CardContent>
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
              <div className="mt-4 flex justify-center">
                <Button onClick={fetchDoctors}>Повторить попытку</Button>
              </div>
            </CardContent>
          ) : (
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-6">
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Запись на прием возможна не позднее чем за 30 минут до желаемого времени приема. Вы можете
                    записаться на прием в течение ближайших 3 месяцев.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label htmlFor="specialization">Специализация врача</Label>
                  <Select value={selectedSpecialization} onValueChange={setSelectedSpecialization}>
                    <SelectTrigger id="specialization">
                      <SelectValue placeholder="Выберите специализацию" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Все специализации</SelectItem>
                      {specializations.map((spec) => (
                        <SelectItem key={spec} value={spec}>
                          {spec}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {isLoading && (
                    <div className="text-sm text-muted-foreground flex items-center mt-2">
                      <div className="animate-spin h-3 w-3 border-2 border-primary rounded-full border-t-transparent mr-2"></div>
                      Загрузка специализаций...
                    </div>
                  )}
                  {!isLoading && specializations.length === 0 && (
                    <p className="text-sm text-muted-foreground mt-2">
                      Специализации не найдены. Пожалуйста, обратитесь к администратору.
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doctor" className={validationErrors.doctor ? "text-red-500" : ""}>
                    Врач {validationErrors.doctor && "*"}
                  </Label>
                  <Select
                    value={selectedDoctor}
                    onValueChange={(value) => {
                      setSelectedDoctor(value)
                      // Очищаем ошибку при выборе
                      if (validationErrors.doctor) {
                        setValidationErrors({ ...validationErrors, doctor: "" })
                      }
                    }}
                    disabled={isLoading || filteredDoctors.length === 0}
                    required
                  >
                    <SelectTrigger id="doctor" className={validationErrors.doctor ? "border-red-500" : ""}>
                      <SelectValue placeholder="Выберите врача" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredDoctors.map((doctor) => (
                        <SelectItem key={doctor.user_id} value={doctor.user_id.toString()}>
                          {doctor.user.full_name} - {doctor.specialization || "Общая практика"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {validationErrors.doctor && <p className="text-sm text-red-500 mt-1">{validationErrors.doctor}</p>}
                  {isLoading && (
                    <div className="text-sm text-muted-foreground flex items-center mt-2">
                      <div className="animate-spin h-3 w-3 border-2 border-primary rounded-full border-t-transparent mr-2"></div>
                      Загрузка врачей...
                    </div>
                  )}
                  {!isLoading && filteredDoctors.length === 0 && (
                    <p className="text-sm text-muted-foreground mt-2">
                      {selectedSpecialization
                        ? `Нет доступных врачей по специализации "${selectedSpecialization}"`
                        : "Нет доступных врачей"}
                    </p>
                  )}
                </div>

                {selectedDoctor && (
                  <div className="p-4 border rounded-lg bg-muted/50">
                    {filteredDoctors
                      .filter((d) => d.user_id.toString() === selectedDoctor)
                      .map((doctor) => (
                        <div key={doctor.user_id} className="space-y-2">
                          <div className="flex items-center">
                            <User className="h-5 w-5 text-muted-foreground mr-2" />
                            <span className="font-medium">{doctor.user.full_name}</span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Специализация: {doctor.specialization || "Общая практика"}
                          </div>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <MapPin className="h-4 w-4 mr-1" />
                            Кабинет: {doctor.office || "Не указан"}
                          </div>
                          {doctor.languages && (
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Info className="h-4 w-4 mr-1" />
                              Языки: {doctor.languages}
                            </div>
                          )}
                          {doctor.user.phone && (
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Phone className="h-4 w-4 mr-1" />
                              Телефон: {doctor.user.phone}
                            </div>
                          )}
                        </div>
                      ))}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="appointmentType" className={validationErrors.appointmentType ? "text-red-500" : ""}>
                    Тип приема {validationErrors.appointmentType && "*"}
                  </Label>
                  <Select
                    value={appointmentType}
                    onValueChange={(value) => {
                      setAppointmentType(value)
                      // Очищаем ошибку при выборе
                      if (validationErrors.appointmentType) {
                        setValidationErrors({ ...validationErrors, appointmentType: "" })
                      }
                    }}
                    required
                  >
                    <SelectTrigger
                      id="appointmentType"
                      className={validationErrors.appointmentType ? "border-red-500" : ""}
                    >
                      <SelectValue placeholder="Выберите тип приема" />
                    </SelectTrigger>
                    <SelectContent>
                      {appointmentTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {validationErrors.appointmentType && (
                    <p className="text-sm text-red-500 mt-1">{validationErrors.appointmentType}</p>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label
                      htmlFor="date"
                      className={`flex items-center ${validationErrors.date ? "text-red-500" : ""}`}
                    >
                      <Calendar className="h-4 w-4 mr-2" />
                      Дата {validationErrors.date && "*"}
                    </Label>
                    <Input
                      id="date"
                      type="date"
                      value={date}
                      onChange={(e) => {
                        setDate(e.target.value)
                        setTime("") // Reset time when date changes
                        // Очищаем ошибку при выборе
                        if (validationErrors.date) {
                          setValidationErrors({ ...validationErrors, date: "" })
                        }
                      }}
                      min={getMinDate()}
                      max={getMaxDate()}
                      required
                      className={validationErrors.date ? "border-red-500" : ""}
                    />
                    {validationErrors.date && <p className="text-sm text-red-500 mt-1">{validationErrors.date}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label className={`flex items-center ${validationErrors.time ? "text-red-500" : ""}`}>
                      <Clock className="h-4 w-4 mr-2" />
                      Время {validationErrors.time && "*"}
                    </Label>
                    {date && selectedDoctor ? (
                      <TimeSlotPicker
                        date={date}
                        doctorId={selectedDoctor}
                        onSelectTime={(value) => {
                          setTime(value)
                          // Очищаем ошибку при выборе
                          if (validationErrors.time) {
                            setValidationErrors({ ...validationErrors, time: "" })
                          }
                        }}
                        selectedTime={time}
                      />
                    ) : (
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          Выберите дату и врача для просмотра доступных слотов времени
                        </AlertDescription>
                      </Alert>
                    )}
                    {validationErrors.time && <p className="text-sm text-red-500 mt-1">{validationErrors.time}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes" className="flex items-center">
                    <Info className="h-4 w-4 mr-2" />
                    Комментарий (не обязательно)
                  </Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Опишите причину обращения или укажите дополнительную информацию"
                    rows={3}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => router.push("/patient/appointments")}
                  disabled={isSubmitting}
                >
                  Отмена
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Создание записи..." : "Записаться на прием"}
                </Button>
              </CardFooter>
            </form>
          )}
        </Card>
      </div>
    </DashboardLayout>
  )
}
