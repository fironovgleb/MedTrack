"use client"

import { useState, useEffect, useCallback } from "react"
import Link from "next/link"
import { Calendar, Filter, Search, Clock, MapPin } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useSupabase } from "@/components/supabase-provider"
import { useAuth } from "@/contexts/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { Skeleton } from "@/components/ui/skeleton"
import { AppointmentCard } from "@/components/appointment/appointment-card"
import {
  formatAppointmentDate,
  formatAppointmentTime,
  getAppointmentStatusText,
  getAppointmentStatusColor,
} from "@/lib/appointment-utils"

interface Appointment {
  id: number
  doctor_id: number
  appointment_time: string
  status: string
  doctor: {
    specialization: string
    office: string
    user: {
      full_name: string
      phone: string | null
    }
  }
}

export default function PatientAppointments() {
  const { user } = useAuth()
  const { supabase } = useSupabase()
  const { toast } = useToast()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [filteredAppointments, setFilteredAppointments] = useState<Appointment[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [cancelingId, setCancelingId] = useState<number | null>(null)
  const [refreshTrigger, setRefreshTrigger] = useState(0)

  // Dialog state
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null)
  const [confirmCancelDialog, setConfirmCancelDialog] = useState(false)
  const [appointmentDetailsDialog, setAppointmentDetailsDialog] = useState(false)

  // Set up a refresh interval (every 2 minutes)
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTrigger((prev) => prev + 1)
    }, 120000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (user) {
      fetchAppointments()
    }
  }, [user, refreshTrigger])

  useEffect(() => {
    filterAppointments()
  }, [appointments, searchQuery, statusFilter])

  const fetchAppointments = async () => {
    setLoading(true)
    try {
      console.log("Fetching appointments for patient:", user?.id)
      const { data, error } = await supabase
        .from("appointments")
        .select(`
          id,
          doctor_id,
          appointment_time,
          status,
          doctor:doctors(
            specialization,
            office,
            user:users(
              full_name,
              phone
            )
          )
        `)
        .eq("patient_id", user?.id)
        .order("appointment_time", { ascending: true })

      if (error) {
        console.error("Error fetching appointments:", error)
        throw error
      }

      console.log("Fetched appointments:", data?.length)
      setAppointments(data || [])
    } catch (error) {
      console.error("Ошибка при получении записей на приём:", error)
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить записи на приём",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const filterAppointments = useCallback(() => {
    let filtered = [...appointments]

    // Фильтрация по поисковому запросу
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (appointment) =>
          appointment.doctor?.user?.full_name.toLowerCase().includes(query) ||
          appointment.doctor?.specialization.toLowerCase().includes(query),
      )
    }

    // Фильтрация по статусу
    if (statusFilter !== "all") {
      filtered = filtered.filter((appointment) => appointment.status === statusFilter)
    }

    setFilteredAppointments(filtered)
  }, [appointments, searchQuery, statusFilter])

  const openAppointmentDetails = (appointmentId: number) => {
    const appointment = appointments.find((a) => a.id === appointmentId)
    if (appointment) {
      setSelectedAppointment(appointment)
      setAppointmentDetailsDialog(true)
    }
  }

  const openCancelDialog = (appointmentId: number) => {
    const appointment = appointments.find((a) => a.id === appointmentId)
    if (appointment) {
      setSelectedAppointment(appointment)
      setConfirmCancelDialog(true)
    }
  }

  const cancelAppointment = async () => {
    if (!selectedAppointment) return

    setCancelingId(selectedAppointment.id)
    try {
      const { error } = await supabase
        .from("appointments")
        .update({ status: "canceled" })
        .eq("id", selectedAppointment.id)
        .eq("patient_id", user?.id)

      if (error) throw error

      // Добавление записи в аудит
      await supabase.from("auditlogs").insert([
        {
          user_id: user?.id,
          action: "cancel_appointment",
          target_type: "appointment",
          target_id: selectedAppointment.id,
          timestamp: new Date().toISOString(),
        },
      ])

      toast({
        title: "Успешно",
        description: "Запись на приём отменена",
      })

      // Обновление списка записей
      setAppointments(
        appointments.map((appointment) =>
          appointment.id === selectedAppointment.id ? { ...appointment, status: "canceled" } : appointment,
        ),
      )

      setConfirmCancelDialog(false)
      setAppointmentDetailsDialog(false)
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось отменить запись",
        variant: "destructive",
      })
    } finally {
      setCancelingId(null)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Мои записи на приём</h1>
            <p className="text-muted-foreground">Управление записями на приём к врачам</p>
          </div>
          <Link href="/patient/appointments/new">
            <Button>Новая запись</Button>
          </Link>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Все записи</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по врачу или специализации..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все статусы" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все статусы</SelectItem>
                    <SelectItem value="scheduled">Запланированные</SelectItem>
                    <SelectItem value="completed">Завершенные</SelectItem>
                    <SelectItem value="canceled">Отмененные</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {loading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : filteredAppointments.length > 0 ? (
              <div className="space-y-4">
                {filteredAppointments.map((appointment) => (
                  <AppointmentCard
                    key={appointment.id}
                    appointment={appointment}
                    userRole="patient"
                    onViewDetails={openAppointmentDetails}
                    onCancel={appointment.status === "scheduled" ? (id) => openCancelDialog(id) : undefined}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-10 text-muted-foreground">
                {appointments.length > 0 ? "Нет записей, соответствующих фильтрам" : "У вас еще нет записей на приём"}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Appointment Details Dialog */}
      <Dialog open={appointmentDetailsDialog} onOpenChange={setAppointmentDetailsDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Детали записи на приём</DialogTitle>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Врач</p>
                <p className="font-medium">{selectedAppointment.doctor?.user?.full_name}</p>
                <p className="text-sm text-muted-foreground">{selectedAppointment.doctor?.specialization}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Дата</p>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span>{formatAppointmentDate(selectedAppointment.appointment_time)}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Время</p>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span>{formatAppointmentTime(selectedAppointment.appointment_time)}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Кабинет</p>
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1 text-muted-foreground" />
                    <span>{selectedAppointment.doctor?.office}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Статус</p>
                  <div className={`flex items-center ${getAppointmentStatusColor(selectedAppointment.status)}`}>
                    <span>{getAppointmentStatusText(selectedAppointment.status)}</span>
                  </div>
                </div>
              </div>

              {selectedAppointment.doctor?.user?.phone && (
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Телефон врача</p>
                  <p className="text-sm">{selectedAppointment.doctor.user.phone}</p>
                </div>
              )}

              <DialogFooter>
                {selectedAppointment.status === "scheduled" && (
                  <Button
                    variant="outline"
                    className="text-red-600"
                    onClick={() => {
                      setAppointmentDetailsDialog(false)
                      openCancelDialog(selectedAppointment.id)
                    }}
                  >
                    Отменить запись
                  </Button>
                )}
                <Button onClick={() => setAppointmentDetailsDialog(false)}>Закрыть</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Cancel Confirmation Dialog */}
      <Dialog open={confirmCancelDialog} onOpenChange={setConfirmCancelDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Подтверждение отмены</DialogTitle>
            <DialogDescription>
              Вы уверены, что хотите отменить запись на приём? Это действие нельзя отменить.
            </DialogDescription>
          </DialogHeader>
          {selectedAppointment && (
            <div className="space-y-4">
              <div className="p-4 border rounded-lg bg-muted/50">
                <div className="font-medium">{selectedAppointment.doctor?.user?.full_name}</div>
                <div className="text-sm text-muted-foreground">{selectedAppointment.doctor?.specialization}</div>
                <div className="flex items-center mt-2 text-sm">
                  <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                  <span>{formatAppointmentDate(selectedAppointment.appointment_time)}</span>
                  <Clock className="h-4 w-4 ml-2 mr-1 text-muted-foreground" />
                  <span>{formatAppointmentTime(selectedAppointment.appointment_time)}</span>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setConfirmCancelDialog(false)} disabled={cancelingId !== null}>
                  Не отменять
                </Button>
                <Button variant="destructive" onClick={cancelAppointment} disabled={cancelingId !== null}>
                  {cancelingId !== null ? "Отмена..." : "Да, отменить запись"}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
