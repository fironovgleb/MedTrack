"use client"

import { useState, useEffect } from "react"
import { User, Phone, Calendar, CreditCard, MapPin, Pencil, AlertCircle, Shield, Heart } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/components/supabase-provider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { formatDate } from "@/lib/utils"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function PatientProfile() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [patientData, setPatientData] = useState<any>(null)
  const [medicalHistory, setMedicalHistory] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [activeTab, setActiveTab] = useState("personal")
  const [tableNames, setTableNames] = useState({
    patients: "Patients",
    users: "Users",
    medicalRecords: "MedicalRecords",
    doctors: "Doctors",
  })

  // Состояния для редактируемых полей
  const [fullName, setFullName] = useState("")
  const [phone, setPhone] = useState("")
  const [birthDate, setBirthDate] = useState("")
  const [gender, setGender] = useState("")
  const [insuranceNumber, setInsuranceNumber] = useState("")
  const [address, setAddress] = useState("")
  const [emergencyContact, setEmergencyContact] = useState("")
  const [allergies, setAllergies] = useState("")
  const [chronicConditions, setChronicConditions] = useState("")
  const [bloodType, setBloodType] = useState("")

  // Состояние для ошибок валидации
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (!loading && user && user.role === "patient") {
      detectTableNames()
    }
  }, [user, loading])

  useEffect(() => {
    if (!loading && user && user.role === "patient" && tableNames.patients) {
      fetchPatientData()
      fetchMedicalHistory()
    }
  }, [user, loading, tableNames])

  // Функция для определения правильных имен таблиц
  const detectTableNames = async () => {
    try {
      // Проверка таблицы пациентов
      const { error: upperPatientsError } = await supabase.from("Patients").select("user_id").limit(1)
      if (upperPatientsError) {
        const { error: lowerPatientsError } = await supabase.from("patients").select("user_id").limit(1)
        if (!lowerPatientsError) {
          setTableNames((prev) => ({ ...prev, patients: "patients" }))
        }
      }

      // Проверка таблицы пользователей
      const { error: upperUsersError } = await supabase.from("Users").select("id").limit(1)
      if (upperUsersError) {
        const { error: lowerUsersError } = await supabase.from("users").select("id").limit(1)
        if (!lowerUsersError) {
          setTableNames((prev) => ({ ...prev, users: "users" }))
        }
      }

      // Проверка таблицы медицинских записей
      const { error: upperMedicalError } = await supabase.from("MedicalRecords").select("id").limit(1)
      if (upperMedicalError) {
        const { error: lowerMedicalError } = await supabase.from("medicalrecords").select("id").limit(1)
        if (!lowerMedicalError) {
          setTableNames((prev) => ({ ...prev, medicalRecords: "medicalrecords" }))
        }
      }

      // Проверка таблицы врачей
      const { error: upperDoctorsError } = await supabase.from("Doctors").select("user_id").limit(1)
      if (upperDoctorsError) {
        const { error: lowerDoctorsError } = await supabase.from("doctors").select("user_id").limit(1)
        if (!lowerDoctorsError) {
          setTableNames((prev) => ({ ...prev, doctors: "doctors" }))
        }
      }
    } catch (error) {
      // Скрываем технические ошибки от пользователя
    }
  }

  const fetchPatientData = async () => {
    setIsLoading(true)
    try {
      // Получаем данные пользователя
      const { data: userData, error: userError } = await supabase
        .from(tableNames.users)
        .select("*")
        .eq("id", user.id)
        .single()

      if (userError) throw userError

      // Получаем данные пациента
      const { data: patientData, error: patientError } = await supabase
        .from(tableNames.patients)
        .select("*")
        .eq("user_id", user.id)
        .single()

      if (patientError && patientError.code !== "PGRST116") throw patientError

      // Объединяем данные
      const combinedData = {
        ...userData,
        ...(patientData || {}),
      }

      setPatientData(combinedData)

      // Устанавливаем состояние формы
      setFullName(combinedData.full_name || "")
      setPhone(combinedData.phone || "")
      setBirthDate(combinedData.birth_date || "")
      setGender(combinedData.gender || "")
      setInsuranceNumber(combinedData.insurance_number || "")
      setAddress(combinedData.address || "")
      setEmergencyContact(combinedData.emergency_contact || "")
      setAllergies(combinedData.allergies || "")
      setChronicConditions(combinedData.chronic_conditions || "")
      setBloodType(combinedData.blood_type || "")
    } catch (error: any) {
      // Скрываем технические детали ошибки
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные профиля",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const fetchMedicalHistory = async () => {
    try {
      const { data, error } = await supabase
        .from(tableNames.medicalRecords)
        .select(`
          id,
          visit_date,
          diagnosis,
          treatment,
          doctor:${tableNames.doctors}(
            user:${tableNames.users}(
              full_name
            ),
            specialization
          )
        `)
        .eq("patient_id", user.id)
        .order("visit_date", { ascending: false })
        .limit(3)

      if (error) throw error

      setMedicalHistory(data || [])
    } catch (error: any) {
      // Скрываем технические ошибки
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    let isValid = true

    // Валидация номера телефона (если он указан)
    if (phone && !phone.match(/^\+7 $$\d{3}$$ \d{3}-\d{2}-\d{2}$/)) {
      newErrors.phone = "Пожалуйста, введите корректный номер телефона в формате +7 (XXX) XXX-XX-XX"
      isValid = false
    }

    // Валидация номера страхового полиса (если он указан)
    if (insuranceNumber && insuranceNumber.length !== 16 && !insuranceNumber.match(/^\d{4} \d{4} \d{4} \d{4}$/)) {
      newErrors.insuranceNumber = "Номер страхового полиса должен содержать 16 цифр"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  const handleSaveProfile = async () => {
    if (!validateForm()) {
      return
    }

    setIsSaving(true)
    try {
      // Обновление данных в таблице users
      const { error: userError } = await supabase
        .from(tableNames.users)
        .update({
          full_name: fullName,
          phone: phone,
        })
        .eq("id", user.id)

      if (userError) throw userError

      // Обновление данных в таблице patients
      const { error: patientError } = await supabase
        .from(tableNames.patients)
        .update({
          birth_date: birthDate || null,
          gender: gender || null,
          insurance_number: insuranceNumber || null,
          address: address || null,
          emergency_contact: emergencyContact || null,
          allergies: allergies || null,
          chronic_conditions: chronicConditions || null,
          blood_type: bloodType || null,
        })
        .eq("user_id", user.id)

      if (patientError) throw patientError

      toast({
        title: "Успешно",
        description: "Профиль успешно обновлен",
      })

      setIsEditing(false)
      fetchPatientData() // Обновление данных после сохранения
    } catch (error: any) {
      // Скрываем технические детали ошибки
      toast({
        title: "Ошибка",
        description: "Не удалось обновить профиль",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const getCompletionPercentage = () => {
    const fields = [
      fullName,
      phone,
      birthDate,
      gender,
      insuranceNumber,
      address,
      emergencyContact,
      bloodType,
      allergies,
      chronicConditions,
    ]

    const filledFields = fields.filter((field) => field && field.trim() !== "").length
    return Math.round((filledFields / fields.length) * 100)
  }

  const completionPercentage = getCompletionPercentage()

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <div>
            <h1 className="text-2xl font-bold">Профиль пациента</h1>
            <p className="text-muted-foreground">Управление личной информацией и медицинскими данными</p>
          </div>
          {!isEditing ? (
            <Button onClick={() => setIsEditing(true)} size="sm">
              <Pencil className="mr-2 h-4 w-4" />
              Редактировать
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving} size="sm">
                Отмена
              </Button>
              <Button onClick={handleSaveProfile} disabled={isSaving} size="sm">
                {isSaving ? "Сохранение..." : "Сохранить"}
              </Button>
            </div>
          )}
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
                <div className="space-y-2">
                  <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Левая колонка - основная информация */}
            <div className="md:col-span-2 space-y-6">
              {isEditing ? (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Редактирование профиля</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="personal">Личные данные</TabsTrigger>
                        <TabsTrigger value="medical">Медицинская информация</TabsTrigger>
                      </TabsList>
                      <TabsContent value="personal" className="space-y-4 mt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="fullName">ФИО</Label>
                            <Input
                              id="fullName"
                              value={fullName}
                              onChange={(e) => setFullName(e.target.value)}
                              placeholder="Иванов Иван Иванович"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Номер телефона</Label>
                            <Input
                              id="phone"
                              value={phone}
                              onChange={(e) => setPhone(e.target.value)}
                              placeholder="+7 (999) 123-45-67"
                            />
                            {errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="birthDate">Дата рождения</Label>
                            <Input
                              id="birthDate"
                              type="date"
                              value={birthDate}
                              onChange={(e) => setBirthDate(e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Пол</Label>
                            <RadioGroup value={gender} onValueChange={setGender} className="flex space-x-4">
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="male" id="male" />
                                <Label htmlFor="male">Мужской</Label>
                              </div>
                              <div className="flex items-center space-x-2">
                                <RadioGroupItem value="female" id="female" />
                                <Label htmlFor="female">Женский</Label>
                              </div>
                            </RadioGroup>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="insuranceNumber">Номер страхового полиса</Label>
                            <Input
                              id="insuranceNumber"
                              value={insuranceNumber}
                              onChange={(e) => setInsuranceNumber(e.target.value)}
                              placeholder="1234 5678 9012 3456"
                            />
                            {errors.insuranceNumber && <p className="text-sm text-red-500">{errors.insuranceNumber}</p>}
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="address">Адрес</Label>
                            <Input
                              id="address"
                              value={address}
                              onChange={(e) => setAddress(e.target.value)}
                              placeholder="г. Москва, ул. Примерная, д. 1, кв. 1"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="emergencyContact">Экстренный контакт</Label>
                            <Input
                              id="emergencyContact"
                              value={emergencyContact}
                              onChange={(e) => setEmergencyContact(e.target.value)}
                              placeholder="Иванов Иван, +7 (999) 123-45-67"
                            />
                          </div>
                        </div>
                      </TabsContent>
                      <TabsContent value="medical" className="space-y-4 mt-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="bloodType">Группа крови</Label>
                            <Select value={bloodType} onValueChange={setBloodType}>
                              <SelectTrigger id="bloodType">
                                <SelectValue placeholder="Выберите группу крови" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="not_specified">Не указано</SelectItem>
                                <SelectItem value="O(I) Rh+">O(I) Rh+</SelectItem>
                                <SelectItem value="O(I) Rh-">O(I) Rh-</SelectItem>
                                <SelectItem value="A(II) Rh+">A(II) Rh+</SelectItem>
                                <SelectItem value="A(II) Rh-">A(II) Rh-</SelectItem>
                                <SelectItem value="B(III) Rh+">B(III) Rh+</SelectItem>
                                <SelectItem value="B(III) Rh-">B(III) Rh-</SelectItem>
                                <SelectItem value="AB(IV) Rh+">AB(IV) Rh+</SelectItem>
                                <SelectItem value="AB(IV) Rh-">AB(IV) Rh-</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="allergies">Аллергии</Label>
                          <Textarea
                            id="allergies"
                            value={allergies}
                            onChange={(e) => setAllergies(e.target.value)}
                            placeholder="Укажите ваши аллергии, если есть"
                            rows={2}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="chronicConditions">Хронические заболевания</Label>
                          <Textarea
                            id="chronicConditions"
                            value={chronicConditions}
                            onChange={(e) => setChronicConditions(e.target.value)}
                            placeholder="Укажите ваши хронические заболевания, если есть"
                            rows={2}
                          />
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving}>
                      Отмена
                    </Button>
                    <Button onClick={handleSaveProfile} disabled={isSaving}>
                      {isSaving ? "Сохранение..." : "Сохранить"}
                    </Button>
                  </CardFooter>
                </Card>
              ) : (
                <>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Личная информация</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4 mb-6">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                          <User className="h-8 w-8 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-xl font-medium">{patientData?.full_name || "Пациент"}</h3>
                          <p className="text-muted-foreground">{patientData?.email}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Телефон</p>
                          <p className="flex items-center">
                            <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                            {patientData?.phone || "Не указан"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Дата рождения</p>
                          <p className="flex items-center">
                            <Calendar className="h-4 w-4 text-muted-foreground mr-2" />
                            {formatDate(patientData?.birth_date) || "Не указана"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Страховой полис</p>
                          <p className="flex items-center">
                            <CreditCard className="h-4 w-4 text-muted-foreground mr-2" />
                            {patientData?.insurance_number || "Не указан"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Адрес</p>
                          <p className="flex items-center">
                            <MapPin className="h-4 w-4 text-muted-foreground mr-2" />
                            {patientData?.address || "Не указан"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Пол</p>
                          <p>
                            {patientData?.gender === "male"
                              ? "Мужской"
                              : patientData?.gender === "female"
                                ? "Женский"
                                : "Не указан"}
                          </p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Экстренный контакт</p>
                          <p>{patientData?.emergency_contact || "Не указан"}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Медицинская информация</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Группа крови</p>
                          <Badge variant="outline" className="font-normal">
                            {patientData?.blood_type === "not_specified"
                              ? "Не указана"
                              : patientData?.blood_type || "Не указана"}
                          </Badge>
                        </div>
                      </div>

                      <Separator className="my-4" />

                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium mb-2 flex items-center">
                            <AlertCircle className="h-4 w-4 mr-2 text-amber-500" />
                            Аллергии
                          </h4>
                          <p className="text-sm bg-muted/50 p-2 rounded">{patientData?.allergies || "Не указаны"}</p>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium mb-2 flex items-center">
                            <Heart className="h-4 w-4 mr-2 text-red-500" />
                            Хронические заболевания
                          </h4>
                          <p className="text-sm bg-muted/50 p-2 rounded">
                            {patientData?.chronic_conditions || "Не указаны"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            {/* Правая колонка - дополнительная информация */}
            <div className="space-y-6">
              {!isEditing && (
                <>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Заполненность профиля</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Прогресс</span>
                          <span>{completionPercentage}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2.5">
                          <div
                            className="bg-primary h-2.5 rounded-full"
                            style={{ width: `${completionPercentage}%` }}
                          ></div>
                        </div>
                        {completionPercentage < 70 && (
                          <p className="text-xs text-muted-foreground mt-2">
                            Заполните больше информации для улучшения качества медицинского обслуживания
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  {medicalHistory.length > 0 ? (
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Последние записи</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {medicalHistory.map((record) => (
                            <div key={record.id} className="text-sm p-3 bg-muted/50 rounded-lg">
                              <div className="flex justify-between items-center">
                                <span className="font-medium">{formatDate(record.visit_date)}</span>
                                <Badge variant="outline" className="font-normal text-xs">
                                  {record.doctor?.specialization}
                                </Badge>
                              </div>
                              <p className="mt-1 font-medium">{record.diagnosis}</p>
                              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{record.treatment}</p>
                            </div>
                          ))}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full mt-3"
                          onClick={() => (window.location.href = "/patient/records")}
                        >
                          Все записи
                        </Button>
                      </CardContent>
                    </Card>
                  ) : (
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Медицинские записи</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center py-6">
                          <Shield className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                          <p className="text-sm text-muted-foreground">У вас пока нет медицинских записей</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Важно</AlertTitle>
                    <AlertDescription>
                      Пожалуйста, поддерживайте вашу медицинскую информацию в актуальном состоянии для обеспечения
                      качественного лечения.
                    </AlertDescription>
                  </Alert>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
