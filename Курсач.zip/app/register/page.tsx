"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useAuth } from "@/contexts/auth-context"

export default function RegisterPage() {
  const router = useRouter()
  const { register } = useAuth()

  // Состояние формы
  const [fullName, setFullName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [role, setRole] = useState("patient")

  // Поля для врача
  const [specialization, setSpecialization] = useState("")
  const [office, setOffice] = useState("")

  // Поля для пациента
  const [gender, setGender] = useState("")
  const [birthDate, setBirthDate] = useState("")
  const [insuranceNumber, setInsuranceNumber] = useState("")
  const [address, setAddress] = useState("")

  // UI состояния
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Создаем объект для ошибок валидации
    const newErrors: Record<string, string> = {}
    let hasErrors = false

    // Базовая валидация
    if (password !== confirmPassword) {
      newErrors.confirmPassword = "Пароли не совпадают"
      hasErrors = true
    }

    if (password.length < 6) {
      newErrors.password = "Пароль должен содержать не менее 6 символов"
      hasErrors = true
    }

    if (role === "doctor" && (!specialization || !office)) {
      newErrors.doctor = "Пожалуйста, заполните все поля для врача"
      hasErrors = true
    }

    if (role === "patient" && (!gender || !birthDate || !insuranceNumber || !address)) {
      newErrors.patient = "Пожалуйста, заполните все поля для пациента"
      hasErrors = true
    }

    // Если есть ошибки, показываем первую из них
    if (hasErrors) {
      const firstError = Object.values(newErrors)[0]
      setError(firstError)
      setLoading(false)
      return
    }

    try {
      await register({
        fullName,
        email,
        password,
        role,
        gender,
        birthDate,
        insuranceNumber,
        address,
        specialization,
        office,
      })

      // Перенаправление происходит в функции register
    } catch (error: any) {
      console.error("Registration error:", error)
      setError(error.message || "Ошибка регистрации. Пожалуйста, попробуйте снова.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-lg">
        <div className="bg-white p-8 rounded-lg shadow-sm border">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Создание аккаунта</h1>
            <p className="text-gray-600 mt-1">Присоединяйтесь к MedTrack для управления медицинскими записями</p>
          </div>

          {error && <div className="bg-red-50 text-red-700 p-3 rounded-md mb-4 text-sm">{error}</div>}

          <form onSubmit={handleRegister} className="space-y-4">
            {/* Выбор роли */}
            <div>
              <Label>Я</Label>
              <Tabs defaultValue="patient" onValueChange={setRole} className="mt-1">
                <TabsList className="grid grid-cols-2">
                  <TabsTrigger value="patient">Пациент</TabsTrigger>
                  <TabsTrigger value="doctor">Врач</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Основная информация */}
            <div>
              <Label htmlFor="fullName">ФИО</Label>
              <Input
                id="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Иванов Иван Иванович"
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ваш@email.com"
                required
                className="mt-1"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="password">Пароль</Label>
                <div className="relative mt-1">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    minLength={6}
                  />
                  <button
                    type="button"
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div>
                <Label htmlFor="confirmPassword">Подтверждение пароля</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="mt-1"
                />
              </div>
            </div>

            {/* Поля в зависимости от роли */}
            {role === "patient" ? (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="gender">Пол</Label>
                  <RadioGroup value={gender} onValueChange={setGender} className="flex space-x-4 mt-1">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male">Мужской</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female">Женский</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other">Другой</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="birthDate">Дата рождения</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    required
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="insuranceNumber">Номер страхового полиса</Label>
                  <Input
                    id="insuranceNumber"
                    value={insuranceNumber}
                    onChange={(e) => setInsuranceNumber(e.target.value)}
                    placeholder="1234567890123456"
                    required
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="address">Адрес</Label>
                  <Textarea
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Ваш полный адрес"
                    required
                    className="mt-1"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="specialization">Специализация</Label>
                  <Select value={specialization} onValueChange={setSpecialization}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Выберите специализацию" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Терапевт">Терапевт</SelectItem>
                      <SelectItem value="Кардиолог">Кардиолог</SelectItem>
                      <SelectItem value="Дерматолог">Дерматолог</SelectItem>
                      <SelectItem value="Невролог">Невролог</SelectItem>
                      <SelectItem value="Педиатр">Педиатр</SelectItem>
                      <SelectItem value="Психиатр">Психиатр</SelectItem>
                      <SelectItem value="Хирург">Хирург</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="office">Номер кабинета</Label>
                  <Input
                    id="office"
                    value={office}
                    onChange={(e) => setOffice(e.target.value)}
                    placeholder="123"
                    required
                    className="mt-1"
                  />
                </div>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Создание аккаунта..." : "Зарегистрироваться"}
            </Button>

            <p className="text-center text-sm text-gray-600 mt-4">
              Уже есть аккаунт?{" "}
              <Link href="/login" className="text-blue-600 hover:underline">
                Войти
              </Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  )
}
