import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowLeft, Award, Clock, Heart, Shield, Users } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex items-center justify-between h-16 mx-auto px-4">
          <Link href="/" className="flex items-center">
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
              MedTrack
            </h1>
          </Link>
          <div className="space-x-4">
            <Link href="/login">
              <Button variant="outline">Войти</Button>
            </Link>
            <Link href="/register">
              <Button>Регистрация</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-12">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Вернуться на главную
          </Link>

          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">О нас</h1>

            <div className="prose prose-lg max-w-none mb-12">
              <p className="text-xl text-muted-foreground mb-8">
                MedTrack — это современная платформа для управления медицинскими записями и консультациями,
                разработанная с учетом потребностей пациентов и медицинских работников.
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">Наша миссия</h2>
              <p>
                Наша миссия — сделать медицинское обслуживание более доступным, эффективным и персонализированным для
                каждого пациента. Мы стремимся создать единую экосистему, где пациенты и врачи могут взаимодействовать
                без лишних барьеров, а медицинская информация всегда доступна тем, кто в ней нуждается, при соблюдении
                высочайших стандартов конфиденциальности.
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">История создания</h2>
              <p>
                MedTrack был основан в 2023 году группой специалистов в области медицины и информационных технологий.
                Идея создания платформы возникла из личного опыта основателей, столкнувшихся с неэффективностью
                традиционных методов ведения медицинской документации и сложностями при записи на прием к врачам.
              </p>
              <p>
                За короткое время наша платформа превратилась в надежный инструмент для тысяч пациентов и сотен
                медицинских специалистов по всей стране. Мы постоянно развиваемся, внедряя новые функции и улучшая
                существующие на основе отзывов наших пользователей.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card>
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Для всех</h3>
                  <p className="text-muted-foreground">
                    Наша платформа разработана для удобства как пациентов, так и медицинских работников
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Безопасность</h3>
                  <p className="text-muted-foreground">
                    Мы обеспечиваем высочайший уровень защиты персональных и медицинских данных
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                    <Clock className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Экономия времени</h3>
                  <p className="text-muted-foreground">
                    Удобный интерфейс и автоматизация рутинных процессов экономят время всех пользователей
                  </p>
                </CardContent>
              </Card>
            </div>

            <h2 className="text-2xl font-semibold mb-6">Наша команда</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-gray-200 rounded-full mb-4"></div>
                <h3 className="text-lg font-semibold">Александр Иванов</h3>
                <p className="text-muted-foreground">Основатель и CEO</p>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-gray-200 rounded-full mb-4"></div>
                <h3 className="text-lg font-semibold">Елена Петрова</h3>
                <p className="text-muted-foreground">Медицинский директор</p>
              </div>

              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-gray-200 rounded-full mb-4"></div>
                <h3 className="text-lg font-semibold">Дмитрий Сидоров</h3>
                <p className="text-muted-foreground">Технический директор</p>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-8 mb-12">
              <div className="flex items-center mb-4">
                <Award className="h-8 w-8 text-blue-600 mr-3" />
                <h2 className="text-2xl font-semibold">Наши достижения</h2>
              </div>
              <ul className="space-y-4 ml-6 list-disc">
                <li>Более 10,000 активных пользователей платформы</li>
                <li>Сотрудничество с 50+ медицинскими учреждениями</li>
                <li>Средняя оценка удовлетворенности пользователей — 4.8 из 5</li>
                <li>Победитель конкурса "Инновации в медицине 2023"</li>
                <li>Сокращение времени на административные задачи на 40%</li>
              </ul>
            </div>

            <div className="text-center">
              <h2 className="text-2xl font-semibold mb-6">Присоединяйтесь к нам</h2>
              <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">
                Станьте частью растущего сообщества MedTrack и получите доступ к современным инструментам управления
                медицинской информацией.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/register">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                  >
                    <Heart className="mr-2 h-5 w-5" />
                    Зарегистрироваться
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button size="lg" variant="outline">
                    Связаться с нами
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Link href="/" className="flex items-center">
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
                  MedTrack
                </h1>
              </Link>
              <p className="mt-4 text-muted-foreground">Управляйте медицинскими записями и консультациями эффективно</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Ссылки</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                    О нас
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                    Контакты
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Правовая информация</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                    Политика конфиденциальности
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                    Условия использования
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} MedTrack. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
