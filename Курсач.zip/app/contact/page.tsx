import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Mail, MapPin, Phone, Send } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function ContactPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex items-center justify-between h-16 mx-auto px-4">
          <Link href="/" className="flex items-center">
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
              MedTrack
            </h1>
          </Link>
          <div className="space-x-4">
            <Link href="/login">
              <Button variant="outline">Войти</Button>
            </Link>
            <Link href="/register">
              <Button>Регистрация</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-12">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Вернуться на главную
          </Link>

          <div className="max-w-5xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">Свяжитесь с нами</h1>
            <p className="text-xl text-muted-foreground mb-12 max-w-3xl">
              У вас есть вопросы о нашей платформе или предложения по улучшению? Мы всегда рады обратной связи и готовы
              помочь вам.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
              <Card>
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Телефон</h3>
                  <p className="text-muted-foreground mb-4">
                    Наша служба поддержки работает с 9:00 до 18:00 по московскому времени
                  </p>
                  <a href="tel:+74951234567" className="text-blue-600 font-medium">
                    +7 (495) 123-45-67
                  </a>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Email</h3>
                  <p className="text-muted-foreground mb-4">Напишите нам, и мы ответим в течение 24 часов</p>
                  <a href="mailto:info@medtrack.ru" className="text-blue-600 font-medium">
                    info@medtrack.ru
                  </a>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                    <MapPin className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Адрес</h3>
                  <p className="text-muted-foreground mb-4">Наш офис расположен в центре Москвы</p>
                  <p className="text-foreground">г. Москва, ул. Тверская, д. 1, офис 123</p>
                </CardContent>
              </Card>
            </div>

            <Card className="mb-12">
              <CardHeader>
                <CardTitle>Форма обратной связи</CardTitle>
                <CardDescription>Заполните форму ниже, и мы свяжемся с вами в ближайшее время</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Ваше имя</Label>
                      <Input id="name" placeholder="Иван Иванов" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="ivan@example.com" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Тема</Label>
                    <Input id="subject" placeholder="Тема вашего сообщения" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Сообщение</Label>
                    <Textarea id="message" placeholder="Введите ваше сообщение..." rows={5} />
                  </div>

                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600"
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Отправить сообщение
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-8">
              <h2 className="text-2xl font-semibold mb-4">Часто задаваемые вопросы</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">Как зарегистрироваться на платформе?</h3>
                  <p className="text-muted-foreground">
                    Для регистрации нажмите кнопку "Регистрация" в верхнем меню и заполните необходимые поля.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-2">Как записаться на прием к врачу?</h3>
                  <p className="text-muted-foreground">
                    После входа в систему перейдите в раздел "Записи на прием" и нажмите кнопку "Новая запись".
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-2">Как получить доступ к медицинской карте?</h3>
                  <p className="text-muted-foreground">
                    Медицинская карта доступна в личном кабинете пациента в разделе "Медицинская карта".
                  </p>
                </div>
              </div>
              <div className="mt-6">
                <Link href="/faq">
                  <Button variant="outline">Все вопросы и ответы</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Link href="/" className="flex items-center">
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
                  MedTrack
                </h1>
              </Link>
              <p className="mt-4 text-muted-foreground">Управляйте медицинскими записями и консультациями эффективно</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Ссылки</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                    О нас
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                    Контакты
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Правовая информация</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                    Политика конфиденциальности
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                    Условия использования
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} MedTrack. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
