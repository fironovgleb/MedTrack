import { SupabaseConnectionTest } from "@/components/supabase-connection-test"

export default function TestConnectionPage() {
  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-6">Supabase Connection Test</h1>
      <SupabaseConnectionTest />

      <div className="mt-8 p-4 bg-gray-100 rounded-md">
        <h2 className="text-lg font-semibold mb-2">Environment Variables</h2>
        <p className="mb-2">The following environment variables are configured:</p>
        <ul className="list-disc pl-6">
          <li>NEXT_PUBLIC_SUPABASE_URL</li>
          <li>NEXT_PUBLIC_SUPABASE_ANON_KEY</li>
        </ul>
      </div>
    </div>
  )
}
