"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { login, user, loading: authLoading } = useAuth()
  const { toast } = useToast()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  // Проверяем, был ли пользователь только что зарегистрирован
  useEffect(() => {
    const registered = searchParams.get("registered")
    if (registered === "true") {
      toast({
        title: "Регистрация успешна",
        description: "Теперь вы можете войти в систему",
      })
    }
  }, [searchParams, toast])

  // Если пользователь уже авторизован, перенаправляем его
  useEffect(() => {
    if (!authLoading && user) {
      router.push(`/${user.role}/dashboard`)
    }
  }, [user, authLoading, router])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Базовая валидация
    if (!email || !password) {
      setError("Пожалуйста, заполните все поля")
      setLoading(false)
      return
    }

    try {
      await login(email, password)
      // Перенаправление происходит в useEffect выше
    } catch (error: any) {
      console.error("Login error:", error)
      // Улучшенная обработка ошибок с понятными сообщениями на русском
      if (error.message?.includes("Invalid login credentials")) {
        setError("Неверный email или пароль. Пожалуйста, проверьте введенные данные.")
      } else if (error.message?.includes("network")) {
        setError("Ошибка сети. Пожалуйста, проверьте подключение к интернету.")
      } else {
        setError(error.message || "Ошибка входа. Пожалуйста, попробуйте снова позже.")
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-md">
        <div className="bg-white p-8 rounded-lg shadow-sm border">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Вход в систему</h1>
            <p className="text-gray-600 mt-1">Войдите в свой аккаунт MedTrack</p>
          </div>

          {error && <div className="bg-red-50 text-red-700 p-3 rounded-md mb-4 text-sm">{error}</div>}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ваш@email.com"
                required
                className="mt-1"
              />
            </div>

            <div>
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Пароль</Label>
                <Link href="/forgot-password" className="text-sm text-blue-600 hover:underline">
                  Забыли пароль?
                </Link>
              </div>
              <div className="relative mt-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="pr-10"
                />
                <button
                  type="button"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Вход..." : "Войти"}
            </Button>

            <p className="text-center text-sm text-gray-600 mt-4">
              Нет аккаунта?{" "}
              <Link href="/register" className="text-blue-600 hover:underline">
                Зарегистрироваться
              </Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  )
}
