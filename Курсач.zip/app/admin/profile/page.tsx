"use client"

import { useState, useEffect } from "react"
import { User, Phone, Shield, Pencil } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { useSupabase } from "@/components/supabase-provider"

export default function AdminProfile() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()

  const [adminData, setAdminData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [tableNames, setTableNames] = useState({
    users: "Users",
  })

  // Состояния для редактируемых полей
  const [fullName, setFullName] = useState("")
  const [phone, setPhone] = useState("")

  // Состояние для ошибок валидации
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    if (!loading && user && user.role === "admin") {
      detectTableNames()
    }
  }, [user, loading])

  useEffect(() => {
    if (!loading && user && user.role === "admin" && tableNames.users) {
      fetchAdminData()
    }
  }, [user, loading, tableNames])

  // Функция для определения правильных имен таблиц
  const detectTableNames = async () => {
    try {
      // Проверка таблицы пользователей
      const { error: upperUsersError } = await supabase.from("Users").select("id").limit(1)
      if (upperUsersError) {
        const { error: lowerUsersError } = await supabase.from("users").select("id").limit(1)
        if (!lowerUsersError) {
          setTableNames((prev) => ({ ...prev, users: "users" }))
        }
      }
    } catch (error) {
      // Скрываем технические ошибки
    }
  }

  const fetchAdminData = async () => {
    setIsLoading(true)
    try {
      // Получение основных данных пользователя
      const { data: userData, error: userError } = await supabase
        .from(tableNames.users)
        .select("*")
        .eq("id", user.id)
        .single()

      if (userError) throw userError

      setAdminData(userData)

      // Заполнение состояний для редактирования
      setFullName(userData.full_name || "")
      setPhone(userData.phone || "")
    } catch (error: any) {
      // Скрываем технические детали ошибки
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить данные профиля",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    let isValid = true

    // Валидация номера телефона (если он указан)
    if (phone && !phone.match(/^\+7 $$\d{3}$$ \d{3}-\d{2}-\d{2}$/)) {
      newErrors.phone = "Пожалуйста, введите корректный номер телефона в формате +7 (XXX) XXX-XX-XX"
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  const handleSaveProfile = async () => {
    if (!validateForm()) {
      return
    }

    setIsSaving(true)
    try {
      // Обновление данных в таблице users
      const { error: userError } = await supabase
        .from(tableNames.users)
        .update({
          full_name: fullName,
          phone: phone,
        })
        .eq("id", user.id)

      if (userError) throw userError

      toast({
        title: "Успешно",
        description: "Профиль успешно обновлен",
      })

      setIsEditing(false)
      fetchAdminData() // Обновление данных после сохранения
    } catch (error: any) {
      // Скрываем технические детали ошибки
      toast({
        title: "Ошибка",
        description: "Не удалось обновить профиль",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <h1 className="text-2xl font-bold">Профиль</h1>
          {!isEditing ? (
            <Button onClick={() => setIsEditing(true)} size="sm">
              <Pencil className="mr-2 h-4 w-4" />
              Редактировать
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving} size="sm">
                Отмена
              </Button>
              <Button onClick={handleSaveProfile} disabled={isSaving} size="sm">
                {isSaving ? "Сохранение..." : "Сохранить"}
              </Button>
            </div>
          )}
        </div>

        {isLoading ? (
          <Card>
            <CardContent className="p-4">
              <div className="h-6 bg-muted animate-pulse rounded w-1/3 mb-4" />
              <div className="space-y-2">
                <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
              </div>
            </CardContent>
          </Card>
        ) : isEditing ? (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Редактирование профиля</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">ФИО</Label>
                  <Input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Иванов Иван Иванович"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Номер телефона</Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+7 (999) 123-45-67"
                  />
                  {errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" value={adminData?.email} disabled className="bg-muted" />
                  <p className="text-xs text-muted-foreground">Email нельзя изменить</p>
                </div>
              </div>
              <div className="flex justify-end space-x-2 mt-4">
                <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSaving} size="sm">
                  Отмена
                </Button>
                <Button onClick={handleSaveProfile} disabled={isSaving} size="sm">
                  {isSaving ? "Сохранение..." : "Сохранить"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                  <User className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <h3 className="font-medium">{adminData?.full_name || "Администратор"}</h3>
                  <p className="text-sm text-muted-foreground">{adminData?.email}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div className="flex items-center">
                  <Phone className="h-4 w-4 text-muted-foreground mr-2" />
                  <span>{adminData?.phone || "Не указан"}</span>
                </div>
                <div className="flex items-center">
                  <Shield className="h-4 w-4 text-muted-foreground mr-2" />
                  <span>Администратор системы</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  )
}
