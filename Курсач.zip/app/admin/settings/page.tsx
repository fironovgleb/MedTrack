"use client"

import { useState, useEffect } from "react"
import {
  Settings,
  Database,
  Shield,
  Bell,
  Mail,
  Server,
  HardDrive,
  RefreshCw,
  User,
  Calendar,
  FileText,
} from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { EmptyState } from "@/components/ui/empty-state"

interface SystemInfo {
  database_size: string
  users_count: number
  appointments_count: number
  records_count: number
  version: string
  uptime: string
}

export default function AdminSettings() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("general")
  const [isLoading, setIsLoading] = useState(true)
  const [systemInfo, setSystemInfo] = useState<SystemInfo>({
    database_size: "0 MB",
    users_count: 0,
    appointments_count: 0,
    records_count: 0,
    version: "1.0.0",
    uptime: "0 дней",
  })
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    if (!loading && user && user.role === "admin") {
      fetchSystemInfo()
    }
  }, [user, loading])

  const fetchSystemInfo = async () => {
    setIsLoading(true)
    try {
      // Получение количества пользователей
      const { count: usersCount, error: usersError } = await supabase
        .from("users")
        .select("*", { count: "exact", head: true })

      if (usersError) throw usersError

      // Получение количества записей на приём
      const { count: appointmentsCount, error: appointmentsError } = await supabase
        .from("appointments")
        .select("*", { count: "exact", head: true })

      if (appointmentsError) throw appointmentsError

      // Получение количества медицинских записей
      const { count: recordsCount, error: recordsError } = await supabase
        .from("medicalrecords")
        .select("*", { count: "exact", head: true })

      if (recordsError) throw recordsError

      // Имитация получения размера базы данных (в реальном приложении это может быть API запрос)
      const databaseSize =
        ((usersCount || 0) * 0.1 + (appointmentsCount || 0) * 0.05 + (recordsCount || 0) * 0.2).toFixed(2) + " MB"

      // Имитация получения времени работы системы
      const uptime = Math.floor(Math.random() * 30) + 1 + " дней"

      setSystemInfo({
        database_size: databaseSize,
        users_count: usersCount || 0,
        appointments_count: appointmentsCount || 0,
        records_count: recordsCount || 0,
        version: "1.0.0",
        uptime: uptime,
      })
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить информацию о системе",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const refreshSystemInfo = async () => {
    setIsRefreshing(true)
    await fetchSystemInfo()
    setIsRefreshing(false)
    toast({
      title: "Обновлено",
      description: "Информация о системе обновлена",
    })
  }

  const handleSaveSettings = () => {
    toast({
      title: "Настройки сохранены",
      description: "Изменения успешно сохранены",
    })
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Настройки</h1>
            <p className="text-muted-foreground">Управление настройками системы</p>
          </div>
        </div>

        <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 mb-6">
            <TabsTrigger value="general">
              <Settings className="h-4 w-4 mr-2" />
              Общие
            </TabsTrigger>
            <TabsTrigger value="security">
              <Shield className="h-4 w-4 mr-2" />
              Безопасность
            </TabsTrigger>
            <TabsTrigger value="notifications">
              <Bell className="h-4 w-4 mr-2" />
              Уведомления
            </TabsTrigger>
            <TabsTrigger value="email">
              <Mail className="h-4 w-4 mr-2" />
              Email
            </TabsTrigger>
            <TabsTrigger value="database">
              <Database className="h-4 w-4 mr-2" />
              База данных
            </TabsTrigger>
            <TabsTrigger value="system">
              <Server className="h-4 w-4 mr-2" />
              Система
            </TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>Общие настройки</CardTitle>
                <CardDescription>Настройте основные параметры системы</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="site-name">Название сайта</Label>
                    <Input id="site-name" defaultValue="MedTrack" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="site-description">Описание сайта</Label>
                    <Textarea
                      id="site-description"
                      defaultValue="Система управления медицинскими записями и приёмами"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="maintenance-mode">Режим обслуживания</Label>
                      <p className="text-sm text-muted-foreground">
                        Временно закрыть доступ к сайту для всех пользователей, кроме администраторов
                      </p>
                    </div>
                    <Switch id="maintenance-mode" />
                  </div>
                </div>
                <Button onClick={handleSaveSettings}>Сохранить настройки</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security">
            <Card>
              <CardHeader>
                <CardTitle>Настройки безопасности</CardTitle>
                <CardDescription>Управление параметрами безопасности системы</CardDescription>
              </CardHeader>
              <CardContent>
                <EmptyState
                  title="Раздел в разработке"
                  description="Настройки безопасности будут доступны в ближайшем обновлении"
                  icon={<Shield className="h-10 w-10 text-muted-foreground" />}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Настройки уведомлений</CardTitle>
                <CardDescription>Управление системой уведомлений</CardDescription>
              </CardHeader>
              <CardContent>
                <EmptyState
                  title="Раздел в разработке"
                  description="Настройки уведомлений будут доступны в ближайшем обновлении"
                  icon={<Bell className="h-10 w-10 text-muted-foreground" />}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="email">
            <Card>
              <CardHeader>
                <CardTitle>Настройки Email</CardTitle>
                <CardDescription>Настройка отправки электронной почты</CardDescription>
              </CardHeader>
              <CardContent>
                <EmptyState
                  title="Раздел в разработке"
                  description="Настройки Email будут доступны в ближайшем обновлении"
                  icon={<Mail className="h-10 w-10 text-muted-foreground" />}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="database">
            <Card>
              <CardHeader>
                <CardTitle>Настройки базы данных</CardTitle>
                <CardDescription>Управление базой данных системы</CardDescription>
              </CardHeader>
              <CardContent>
                <EmptyState
                  title="Раздел в разработке"
                  description="Настройки базы данных будут доступны в ближайшем обновлении"
                  icon={<Database className="h-10 w-10 text-muted-foreground" />}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="system">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div>
                  <CardTitle>Информация о системе</CardTitle>
                  <CardDescription>Технические данные о работе системы</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={refreshSystemInfo} disabled={isRefreshing}>
                  <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
                  Обновить
                </Button>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[...Array(6)].map((_, i) => (
                      <div key={i} className="flex justify-between">
                        <div className="h-5 bg-muted animate-pulse rounded w-1/3" />
                        <div className="h-5 bg-muted animate-pulse rounded w-1/4" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <HardDrive className="h-5 w-5 text-muted-foreground mr-2" />
                              <span className="font-medium">Размер базы данных</span>
                            </div>
                            <span>{systemInfo.database_size}</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <User className="h-5 w-5 text-muted-foreground mr-2" />
                              <span className="font-medium">Пользователей</span>
                            </div>
                            <span>{systemInfo.users_count}</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Calendar className="h-5 w-5 text-muted-foreground mr-2" />
                              <span className="font-medium">Записей на приём</span>
                            </div>
                            <span>{systemInfo.appointments_count}</span>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <FileText className="h-5 w-5 text-muted-foreground mr-2" />
                              <span className="font-medium">Медицинских записей</span>
                            </div>
                            <span>{systemInfo.records_count}</span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <span className="font-medium">Версия системы</span>
                        <span>{systemInfo.version}</span>
                      </div>
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <span className="font-medium">Время работы</span>
                        <span>{systemInfo.uptime}</span>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
