"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Activity, Calendar, FileText, User, Users } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"

interface Stats {
  usersCount: number
  patientsCount: number
  doctorsCount: number
  appointmentsCount: number
  recordsCount: number
  recentUsers: {
    id: number
    full_name: string
    email: string
    role: string
    created_at: string
  }[]
  recentAppointments: {
    id: number
    appointment_time: string
    status: string
    patient: {
      user: {
        full_name: string
      }
    }
    doctor: {
      user: {
        full_name: string
      }
    }
  }[]
}

export default function AdminDashboard() {
  const router = useRouter()
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()
  const [stats, setStats] = useState<Stats>({
    usersCount: 0,
    patientsCount: 0,
    doctorsCount: 0,
    appointmentsCount: 0,
    recordsCount: 0,
    recentUsers: [],
    recentAppointments: [],
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (!loading && user && user.role === "admin") {
      fetchStats()
    }
  }, [user, loading])

  const fetchStats = async () => {
    setIsLoading(true)
    try {
      // Получение количества пользователей
      const { count: usersCount, error: usersError } = await supabase
        .from("Users")
        .select("*", { count: "exact", head: true })

      if (usersError) throw usersError

      // Получение количества пациентов
      const { count: patientsCount, error: patientsError } = await supabase
        .from("Patients")
        .select("*", { count: "exact", head: true })

      if (patientsError) throw patientsError

      // Получение количества врачей
      const { count: doctorsCount, error: doctorsError } = await supabase
        .from("Doctors")
        .select("*", { count: "exact", head: true })

      if (doctorsError) throw doctorsError

      // Получение количества записей на приём
      const { count: appointmentsCount, error: appointmentsError } = await supabase
        .from("Appointments")
        .select("*", { count: "exact", head: true })

      if (appointmentsError) throw appointmentsError

      // Получение количества медицинских записей
      const { count: recordsCount, error: recordsError } = await supabase
        .from("MedicalRecords")
        .select("*", { count: "exact", head: true })

      if (recordsError) throw recordsError

      // Получение последних зарегистрированных пользователей
      const { data: recentUsers, error: recentUsersError } = await supabase
        .from("Users")
        .select("id, full_name, email, role, created_at")
        .order("created_at", { ascending: false })
        .limit(5)

      if (recentUsersError) throw recentUsersError

      // Получение последних записей на приём
      const { data: recentAppointments, error: recentAppointmentsError } = await supabase
        .from("Appointments")
        .select(`
          id,
          appointment_time,
          status,
          patient:Patients(
            user:Users(
              full_name
            )
          ),
          doctor:Doctors(
            user:Users(
              full_name
            )
          )
        `)
        .order("appointment_time", { ascending: false })
        .limit(5)

      if (recentAppointmentsError) throw recentAppointmentsError

      setStats({
        usersCount: usersCount || 0,
        patientsCount: patientsCount || 0,
        doctorsCount: doctorsCount || 0,
        appointmentsCount: appointmentsCount || 0,
        recordsCount: recordsCount || 0,
        recentUsers: recentUsers || [],
        recentAppointments: recentAppointments || [],
      })
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить статистику",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getRoleText = (role: string) => {
    switch (role) {
      case "admin":
        return "Администратор"
      case "doctor":
        return "Врач"
      case "patient":
        return "Пациент"
      default:
        return role
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "scheduled":
        return "Запланирован"
      case "completed":
        return "Завершен"
      case "canceled":
        return "Отменен"
      default:
        return status
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold">Панель управления</h1>
        <p className="text-muted-foreground">
          Добро пожаловать, {user?.full_name}! Здесь вы можете управлять системой и просматривать статистику.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Пользователи</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <div className="h-8 w-16 bg-muted animate-pulse rounded" /> : stats.usersCount}
              </div>
              <p className="text-xs text-muted-foreground">Всего пользователей в системе</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Пациенты</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <div className="h-8 w-16 bg-muted animate-pulse rounded" /> : stats.patientsCount}
              </div>
              <p className="text-xs text-muted-foreground">Зарегистрированные пациенты</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Врачи</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <div className="h-8 w-16 bg-muted animate-pulse rounded" /> : stats.doctorsCount}
              </div>
              <p className="text-xs text-muted-foreground">Зарегистрированные врачи</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Записи на приём</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <div className="h-8 w-16 bg-muted animate-pulse rounded" /> : stats.appointmentsCount}
              </div>
              <p className="text-xs text-muted-foreground">Всего записей на приём</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Медицинские записи</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? <div className="h-8 w-16 bg-muted animate-pulse rounded" /> : stats.recordsCount}
              </div>
              <p className="text-xs text-muted-foreground">Всего медицинских записей</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Новые пользователи</CardTitle>
              <CardDescription>Последние зарегистрированные пользователи</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex flex-col space-y-2">
                      <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                    </div>
                  ))}
                </div>
              ) : stats.recentUsers.length > 0 ? (
                <div className="space-y-4">
                  {stats.recentUsers.map((user) => (
                    <div key={user.id} className="flex flex-col space-y-2 p-3 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <User className="h-5 w-5 text-muted-foreground mr-2" />
                          <span className="font-medium">{user.full_name}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">{getRoleText(user.role)}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                      <div className="text-sm text-muted-foreground">
                        Зарегистрирован: {formatDate(user.created_at)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">Нет данных о пользователях</div>
              )}
              {stats.recentUsers.length > 0 && (
                <div className="mt-4 text-center">
                  <Button variant="outline" onClick={() => router.push("/admin/users")}>
                    Все пользователи
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>Последние записи на приём</CardTitle>
              <CardDescription>Недавно созданные записи на приём</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex flex-col space-y-2">
                      <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                      <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                    </div>
                  ))}
                </div>
              ) : stats.recentAppointments.length > 0 ? (
                <div className="space-y-4">
                  {stats.recentAppointments.map((appointment) => (
                    <div key={appointment.id} className="flex flex-col space-y-2 p-3 border rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Calendar className="h-5 w-5 text-muted-foreground mr-2" />
                          <span className="font-medium">
                            {formatDate(appointment.appointment_time)} {formatTime(appointment.appointment_time)}
                          </span>
                        </div>
                        <span className="text-sm text-muted-foreground">{getStatusText(appointment.status)}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Пациент: {appointment.patient?.user?.full_name}
                      </div>
                      <div className="text-sm text-muted-foreground">Врач: {appointment.doctor?.user?.full_name}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">Нет данных о записях на приём</div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Активность системы</CardTitle>
              <CardDescription>Общая статистика использования системы</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-full">
                    <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Соотношение пациентов к врачам</p>
                    <p className="text-xl font-bold">
                      {isLoading ? (
                        <div className="h-6 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        `${stats.patientsCount} : ${stats.doctorsCount}`
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-green-100 dark:bg-green-900 rounded-full">
                    <Calendar className="h-6 w-6 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Записей на приём на врача</p>
                    <p className="text-xl font-bold">
                      {isLoading ? (
                        <div className="h-6 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        `${stats.doctorsCount ? (stats.appointmentsCount / stats.doctorsCount).toFixed(1) : 0}`
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-full">
                    <FileText className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Записей на пациента</p>
                    <p className="text-xl font-bold">
                      {isLoading ? (
                        <div className="h-6 w-16 bg-muted animate-pulse rounded" />
                      ) : (
                        `${stats.patientsCount ? (stats.recordsCount / stats.patientsCount).toFixed(1) : 0}`
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="p-2 bg-amber-100 dark:bg-amber-900 rounded-full">
                    <Activity className="h-6 w-6 text-amber-600 dark:text-amber-400" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Активность системы</p>
                    <Button variant="outline" size="sm" onClick={() => router.push("/admin/audit")}>
                      Журнал аудита
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
