"use client"

import { useState, useEffect } from "react"
import { Calendar, Clock, Filter, Search, User, Download, RefreshCw, Activity } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { EmptyState } from "@/components/ui/empty-state"

interface AuditLog {
  id: number
  user_id: number
  action: string
  target_type: string
  target_id: number | null
  timestamp: string
  details?: string
  ip_address?: string
  user?: {
    full_name: string
    role: string
  }
}

export default function AdminAudit() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [filteredLogs, setFilteredLogs] = useState<AuditLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [actionFilter, setActionFilter] = useState("all")
  const [userRoleFilter, setUserRoleFilter] = useState("all")
  const [activeTab, setActiveTab] = useState("all")
  const [uniqueActions, setUniqueActions] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)
  const [hasDetailsColumn, setHasDetailsColumn] = useState(false)
  const [hasIpAddressColumn, setHasIpAddressColumn] = useState(false)
  const [tableNames, setTableNames] = useState({
    auditlogs: "auditlogs",
    users: "users",
  })

  useEffect(() => {
    if (!loading && user && user.role === "admin") {
      detectTableNames()
    }
  }, [user, loading])

  useEffect(() => {
    // Применение фильтров при изменении исходных данных, поискового запроса или фильтров
    filterLogs()
  }, [logs, searchQuery, actionFilter, userRoleFilter, activeTab])

  // Определение правильных имен таблиц
  const detectTableNames = async () => {
    try {
      // Проверка таблицы журнала аудита
      const { error: lowerAuditError } = await supabase.from("auditlogs").select("id").limit(1)
      if (lowerAuditError) {
        const { error: upperAuditError } = await supabase.from("AuditLogs").select("id").limit(1)
        if (!upperAuditError) {
          setTableNames((prev) => ({ ...prev, auditlogs: "AuditLogs" }))
        }
      }

      // Проверка таблицы пользователей
      const { error: lowerUsersError } = await supabase.from("users").select("id").limit(1)
      if (lowerUsersError) {
        const { error: upperUsersError } = await supabase.from("Users").select("id").limit(1)
        if (!upperUsersError) {
          setTableNames((prev) => ({ ...prev, users: "Users" }))
        }
      }

      // После определения имен таблиц проверяем наличие столбцов
      checkTableColumns()
    } catch (error) {
      console.error("Ошибка при определении имен таблиц:", error)
      // Продолжаем с проверкой столбцов даже при ошибке
      checkTableColumns()
    }
  }

  // Проверка наличия столбцов в таблице
  const checkTableColumns = async () => {
    try {
      // Проверяем наличие столбца details
      const { data: detailsData, error: detailsError } = await supabase
        .from(tableNames.auditlogs)
        .select("details")
        .limit(1)

      if (!detailsError) {
        setHasDetailsColumn(true)
      }

      // Проверяем наличие столбца ip_address
      const { data: ipData, error: ipError } = await supabase.from(tableNames.auditlogs).select("ip_address").limit(1)

      if (!ipError) {
        setHasIpAddressColumn(true)
      }

      // После проверки загружаем журнал аудита
      fetchAuditLogs()
    } catch (error) {
      console.error("Ошибка при проверке столбцов:", error)
      // Продолжаем загрузку журнала даже при ошибке проверки
      fetchAuditLogs()
    }
  }

  const fetchAuditLogs = async () => {
    setIsLoading(true)
    setError(null)
    try {
      // Формируем базовый запрос
      let selectQuery = `
        id,
        user_id,
        action,
        target_type,
        target_id,
        timestamp,
        user:${tableNames.users}(
          full_name,
          role
        )
      `

      // Добавляем столбцы, если они существуют
      if (hasDetailsColumn) {
        selectQuery += `, details`
      }

      if (hasIpAddressColumn) {
        selectQuery += `, ip_address`
      }

      const { data, error } = await supabase
        .from(tableNames.auditlogs)
        .select(selectQuery)
        .order("timestamp", { ascending: false })
        .limit(500)

      if (error) throw error

      // Обработка записей без связанного пользователя
      const processedData =
        data?.map((log) => {
          if (!log.user) {
            return {
              ...log,
              user: {
                full_name: "Неизвестный пользователь",
                role: "unknown",
              },
            }
          }
          return log
        }) || []

      setLogs(processedData)

      // Извлечение уникальных действий для фильтра
      const actions = Array.from(new Set(processedData.map((log) => log.action) || []))
      setUniqueActions(actions)
    } catch (error: any) {
      console.error("Ошибка при загрузке журнала аудита:", error)
      setError(error.message || "Не удалось загрузить журнал аудита")
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить журнал аудита",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const refreshLogs = async () => {
    setIsRefreshing(true)
    await fetchAuditLogs()
    setIsRefreshing(false)
  }

  const filterLogs = () => {
    let filtered = [...logs]

    // Фильтрация по периоду
    const now = new Date()
    if (activeTab === "today") {
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString()
      filtered = filtered.filter((log) => log.timestamp >= startOfDay)
    } else if (activeTab === "week") {
      const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7).toISOString()
      filtered = filtered.filter((log) => log.timestamp >= startOfWeek)
    }

    // Фильтрация по поисковому запросу
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (log) =>
          (log.user?.full_name && log.user.full_name.toLowerCase().includes(query)) ||
          log.action.toLowerCase().includes(query) ||
          log.target_type.toLowerCase().includes(query) ||
          (hasDetailsColumn && log.details && log.details.toLowerCase().includes(query)),
      )
    }

    // Фильтрация по действию
    if (actionFilter !== "all") {
      filtered = filtered.filter((log) => log.action === actionFilter)
    }

    // Фильтрация по роли пользователя
    if (userRoleFilter !== "all") {
      filtered = filtered.filter((log) => log.user?.role === userRoleFilter)
    }

    setFilteredLogs(filtered)
  }

  const exportToCSV = () => {
    try {
      // Подготовка данных для экспорта
      const csvData = filteredLogs.map((log) => ({
        id: log.id,
        user: log.user?.full_name || "Неизвестно",
        role: getRoleText(log.user?.role) || "Неизвестно",
        action: getActionText(log.action),
        target_type: getTargetTypeText(log.target_type),
        target_id: log.target_id || "",
        timestamp: formatDateTime(log.timestamp),
        details: hasDetailsColumn ? log.details || "" : "",
        ip_address: hasIpAddressColumn ? log.ip_address || "" : "",
      }))

      // Заголовки CSV
      const headers = ["ID", "Пользователь", "Роль", "Действие", "Тип объекта", "ID объекта", "Время"]

      if (hasDetailsColumn) {
        headers.push("Детали")
      }

      if (hasIpAddressColumn) {
        headers.push("IP адрес")
      }

      // Создание CSV строки
      const csvContent =
        "data:text/csv;charset=utf-8," +
        headers.join(",") +
        "\n" +
        csvData
          .map((row) =>
            Object.values(row)
              .map((value) => `"${value}"`)
              .join(","),
          )
          .join("\n")

      // Создание ссылки для скачивания
      const encodedUri = encodeURI(csvContent)
      const link = document.createElement("a")
      link.setAttribute("href", encodedUri)
      link.setAttribute("download", `audit_log_${new Date().toISOString().slice(0, 10)}.csv`)
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Экспорт выполнен",
        description: `Экспортировано ${csvData.length} записей`,
      })
    } catch (error: any) {
      toast({
        title: "Ошибка экспорта",
        description: error.message || "Не удалось экспортировать данные",
        variant: "destructive",
      })
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  const getActionText = (action: string) => {
    switch (action) {
      case "create_appointment":
        return "Создание записи на приём"
      case "cancel_appointment":
        return "Отмена записи на приём"
      case "complete_appointment":
        return "Завершение приёма"
      case "create_medical_record":
        return "Создание медицинской записи"
      case "update_profile":
        return "Обновление профиля"
      case "login":
        return "Вход в систему"
      case "logout":
        return "Выход из системы"
      default:
        return action
    }
  }

  const getTargetTypeText = (targetType: string) => {
    switch (targetType) {
      case "appointment":
        return "Запись на приём"
      case "medical_record":
        return "Медицинская запись"
      case "user":
        return "Пользователь"
      default:
        return targetType
    }
  }

  const getRoleText = (role: string | undefined) => {
    if (!role) return "Неизвестно"
    switch (role) {
      case "admin":
        return "Администратор"
      case "doctor":
        return "Врач"
      case "patient":
        return "Пациент"
      default:
        return role
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Журнал аудита</h1>
            <p className="text-muted-foreground">Просмотр действий пользователей в системе</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={refreshLogs} disabled={isRefreshing}>
              <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
              Обновить
            </Button>
            <Button variant="outline" onClick={exportToCSV} disabled={filteredLogs.length === 0}>
              <Download className="mr-2 h-4 w-4" />
              Экспорт CSV
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Журнал действий</CardTitle>
            <CardDescription>История действий пользователей в системе</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="all">Все записи</TabsTrigger>
                <TabsTrigger value="today">Сегодня</TabsTrigger>
                <TabsTrigger value="week">За неделю</TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по пользователю или действию..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={actionFilter} onValueChange={setActionFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все действия" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все действия</SelectItem>
                    {uniqueActions.map((action) => (
                      <SelectItem key={action} value={action}>
                        {getActionText(action)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <Select value={userRoleFilter} onValueChange={setUserRoleFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все роли" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все роли</SelectItem>
                    <SelectItem value="admin">Администраторы</SelectItem>
                    <SelectItem value="doctor">Врачи</SelectItem>
                    <SelectItem value="patient">Пациенты</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-700 p-4 rounded-md mb-6">
                <p className="font-medium">Ошибка загрузки данных</p>
                <p>{error}</p>
                <Button variant="outline" className="mt-2" onClick={fetchAuditLogs}>
                  Повторить попытку
                </Button>
              </div>
            )}

            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex flex-col space-y-2 p-4 border rounded-lg">
                    <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  </div>
                ))}
              </div>
            ) : filteredLogs.length > 0 ? (
              <div className="space-y-4">
                {filteredLogs.map((log) => (
                  <div key={log.id} className="flex flex-col space-y-2 p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <User className="h-5 w-5 text-muted-foreground mr-2" />
                        <span className="font-medium">{log.user?.full_name || "Неизвестный пользователь"}</span>
                        <span className="ml-2 text-sm px-2 py-0.5 bg-muted rounded-md">
                          {getRoleText(log.user?.role)}
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>{formatDate(log.timestamp)}</span>
                        <Clock className="h-4 w-4 ml-2 mr-1" />
                        <span>{formatTime(log.timestamp)}</span>
                      </div>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Действие:</span> {getActionText(log.action)}
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Объект:</span> {getTargetTypeText(log.target_type)}
                      {log.target_id && ` (ID: ${log.target_id})`}
                    </div>
                    {hasDetailsColumn && log.details && (
                      <div className="text-sm">
                        <span className="font-medium">Детали:</span> {log.details}
                      </div>
                    )}
                    {hasIpAddressColumn && log.ip_address && (
                      <div className="text-sm">
                        <span className="font-medium">IP адрес:</span> {log.ip_address}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="Журнал пуст"
                description={
                  logs.length > 0 ? "Не найдено записей, соответствующих выбранным фильтрам" : "Журнал аудита пуст"
                }
                icon={<Activity className="h-10 w-10 text-muted-foreground" />}
              />
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
