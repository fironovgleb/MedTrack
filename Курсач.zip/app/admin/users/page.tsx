"use client"

import { useState, useEffect } from "react"
import { Filter, Search, User, UserPlus, Trash2, Check, X, Mail, Phone } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"
import { EmptyState } from "@/components/ui/empty-state"

interface UserData {
  id: number
  full_name: string
  email: string
  phone: string | null
  role: string
  created_at: string
  is_active?: boolean
  last_login?: string
}

interface PatientData {
  user_id: number
  birth_date?: string
  gender?: string
  insurance_number?: string
  address?: string
}

interface DoctorData {
  user_id: number
  specialization: string
  office: string
}

export default function AdminUsers() {
  const { supabase, user, loading } = useSupabase()
  const { toast } = useToast()
  const [users, setUsers] = useState<UserData[]>([])
  const [filteredUsers, setFilteredUsers] = useState<UserData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [roleFilter, setRoleFilter] = useState("all")
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null)
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const [patientDetails, setPatientDetails] = useState<PatientData | null>(null)
  const [doctorDetails, setDoctorDetails] = useState<DoctorData | null>(null)
  const [isLoadingDetails, setIsLoadingDetails] = useState(false)
  const [openDetailsDialog, setOpenDetailsDialog] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [hasIsActiveColumn, setHasIsActiveColumn] = useState(false)
  // Добавить новую переменную состояния для отслеживания наличия столбца last_login
  const [hasLastLoginColumn, setHasLastLoginColumn] = useState(false)

  useEffect(() => {
    if (!loading && user && user.role === "admin") {
      checkTableColumns()
    }
  }, [user, loading])

  useEffect(() => {
    // Применение фильтров при изменении исходных данных, поискового запроса или фильтра роли
    filterUsers()
  }, [users, searchQuery, roleFilter, activeTab, hasIsActiveColumn])

  // Проверка наличия столбцов в таблице
  const checkTableColumns = async () => {
    try {
      // Проверяем наличие столбца is_active
      const { data: isActiveData, error: isActiveError } = await supabase.from("users").select("is_active").limit(1)
      if (!isActiveError) {
        setHasIsActiveColumn(true)
      }

      // Проверяем наличие столбца last_login
      const { data: lastLoginData, error: lastLoginError } = await supabase.from("users").select("last_login").limit(1)
      if (!lastLoginError) {
        setHasLastLoginColumn(true)
      }

      // После проверки загружаем пользователей
      fetchUsers()
    } catch (error) {
      console.error("Ошибка при проверке столбцов:", error)
      // Продолжаем загрузку пользователей даже при ошибке проверки
      fetchUsers()
    }
  }

  // Обновить функцию fetchUsers для условного включения столбца last_login
  const fetchUsers = async () => {
    setIsLoading(true)
    setError(null)
    try {
      // Формируем базовый запрос
      let query = supabase.from("users").select("id, full_name, email, phone, role, created_at")

      // Добавляем столбец is_active только если он существует
      if (hasIsActiveColumn) {
        query = supabase.from("users").select("id, full_name, email, phone, role, created_at, is_active")
      }

      // Добавляем столбец last_login только если он существует
      if (hasLastLoginColumn) {
        query = hasIsActiveColumn
          ? supabase.from("users").select("id, full_name, email, phone, role, created_at, is_active, last_login")
          : supabase.from("users").select("id, full_name, email, phone, role, created_at, last_login")
      }

      const { data, error } = await query.order("created_at", { ascending: false })

      if (error) throw error
      setUsers(data || [])
    } catch (error: any) {
      console.error("Ошибка при загрузке пользователей:", error)
      setError(error.message || "Не удалось загрузить список пользователей")
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить список пользователей",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const filterUsers = () => {
    let filtered = [...users]

    // Фильтрация по активности только если столбец существует
    if (hasIsActiveColumn) {
      if (activeTab === "active") {
        filtered = filtered.filter((user) => user.is_active !== false)
      } else if (activeTab === "inactive") {
        filtered = filtered.filter((user) => user.is_active === false)
      }
    }

    // Фильтрация по поисковому запросу
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (user) =>
          user.full_name.toLowerCase().includes(query) ||
          user.email.toLowerCase().includes(query) ||
          (user.phone && user.phone.toLowerCase().includes(query)),
      )
    }

    // Фильтрация по роли
    if (roleFilter !== "all") {
      filtered = filtered.filter((user) => user.role === roleFilter)
    }

    setFilteredUsers(filtered)
  }

  const fetchUserDetails = async (userId: number, role: string) => {
    setIsLoadingDetails(true)
    try {
      if (role === "patient") {
        const { data, error } = await supabase
          .from("patients")
          .select("user_id, birth_date, gender, insurance_number, address")
          .eq("user_id", userId)
          .single()

        if (error && error.code !== "PGRST116") throw error // PGRST116 - не найдено
        setPatientDetails(data || null)
        setDoctorDetails(null)
      } else if (role === "doctor") {
        const { data, error } = await supabase
          .from("doctors")
          .select("user_id, specialization, office")
          .eq("user_id", userId)
          .single()

        if (error && error.code !== "PGRST116") throw error
        setDoctorDetails(data || null)
        setPatientDetails(null)
      }
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось загрузить детали пользователя",
        variant: "destructive",
      })
    } finally {
      setIsLoadingDetails(false)
    }
  }

  const handleViewDetails = async (userData: UserData) => {
    setSelectedUser(userData)
    await fetchUserDetails(userData.id, userData.role)
    setOpenDetailsDialog(true)
  }

  const handleDeleteUser = async () => {
    if (!selectedUser) return

    setIsDeleting(true)
    try {
      // Проверка, не пытается ли админ удалить самого себя
      if (selectedUser.id === user.id) {
        throw new Error("Вы не можете удалить свою учетную запись")
      }

      // Удаление пользователя
      const { error } = await supabase.from("users").delete().eq("id", selectedUser.id)

      if (error) throw error

      toast({
        title: "Успешно",
        description: "Пользователь успешно удален",
      })

      // Обновление списка пользователей
      setUsers(users.filter((u) => u.id !== selectedUser.id))
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось удалить пользователя",
        variant: "destructive",
      })
    } finally {
      setIsDeleting(false)
      setOpenDeleteDialog(false)
      setSelectedUser(null)
    }
  }

  const toggleUserStatus = async (userData: UserData) => {
    // Проверяем наличие столбца is_active
    if (!hasIsActiveColumn) {
      toast({
        title: "Функция недоступна",
        description: "Управление статусом пользователей недоступно в текущей версии базы данных",
        variant: "destructive",
      })
      return
    }

    try {
      const newStatus = userData.is_active === false
      const { error } = await supabase.from("users").update({ is_active: newStatus }).eq("id", userData.id)

      if (error) throw error

      // Обновление списка пользователей
      setUsers(users.map((u) => (u.id === userData.id ? { ...u, is_active: newStatus } : u)))

      toast({
        title: "Успешно",
        description: `Пользователь ${newStatus ? "активирован" : "деактивирован"}`,
      })
    } catch (error: any) {
      toast({
        title: "Ошибка",
        description: error.message || "Не удалось изменить статус пользователя",
        variant: "destructive",
      })
    }
  }

  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return "Не указано"
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  }

  const formatDateTime = (dateString: string | null | undefined) => {
    if (!dateString) return "Не указано"
    return new Date(dateString).toLocaleString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getRoleText = (role: string) => {
    switch (role) {
      case "admin":
        return "Администратор"
      case "doctor":
        return "Врач"
      case "patient":
        return "Пациент"
      default:
        return role
    }
  }

  const getGenderText = (gender: string | undefined) => {
    if (!gender) return "Не указан"
    switch (gender) {
      case "male":
        return "Мужской"
      case "female":
        return "Женский"
      case "other":
        return "Другой"
      default:
        return gender
    }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Пользователи</h1>
            <p className="text-muted-foreground">Управление пользователями системы</p>
          </div>
          <Button>
            <UserPlus className="mr-2 h-4 w-4" />
            Добавить пользователя
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Все пользователи</CardTitle>
            <CardDescription>Просмотр и управление учетными записями пользователей</CardDescription>
          </CardHeader>
          <CardContent>
            {hasIsActiveColumn && (
              <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="mb-6">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="all">Все пользователи</TabsTrigger>
                  <TabsTrigger value="active">Активные</TabsTrigger>
                  <TabsTrigger value="inactive">Неактивные</TabsTrigger>
                </TabsList>
              </Tabs>
            )}

            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по имени, email или телефону..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="w-full sm:w-48 flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Все роли" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все роли</SelectItem>
                    <SelectItem value="admin">Администраторы</SelectItem>
                    <SelectItem value="doctor">Врачи</SelectItem>
                    <SelectItem value="patient">Пациенты</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-700 p-4 rounded-md mb-6">
                <p className="font-medium">Ошибка загрузки данных</p>
                <p>{error}</p>
                <Button variant="outline" className="mt-2" onClick={fetchUsers}>
                  Повторить попытку
                </Button>
              </div>
            )}

            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex flex-col space-y-2 p-4 border rounded-lg">
                    <div className="h-5 bg-muted animate-pulse rounded w-3/4" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/2" />
                    <div className="h-4 bg-muted animate-pulse rounded w-1/4" />
                  </div>
                ))}
              </div>
            ) : filteredUsers.length > 0 ? (
              <div className="space-y-4">
                {filteredUsers.map((userData) => (
                  <div key={userData.id} className="flex flex-col space-y-3 p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <User className="h-5 w-5 text-muted-foreground mr-2" />
                        <span className="font-medium">{userData.full_name}</span>
                        {hasIsActiveColumn && userData.is_active === false && (
                          <span className="ml-2 text-xs px-2 py-1 bg-red-100 text-red-800 rounded-full">Неактивен</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm px-2 py-1 bg-muted rounded-md">{getRoleText(userData.role)}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => handleViewDetails(userData)}
                        >
                          <User className="h-4 w-4" />
                        </Button>
                        {hasIsActiveColumn && (
                          <Button
                            variant="outline"
                            size="icon"
                            className={`h-8 w-8 ${userData.is_active === false ? "text-green-500" : "text-amber-500"}`}
                            onClick={() => toggleUserStatus(userData)}
                          >
                            {userData.is_active === false ? <Check className="h-4 w-4" /> : <X className="h-4 w-4" />}
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => {
                            setSelectedUser(userData)
                            setOpenDeleteDialog(true)
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <Mail className="h-4 w-4 mr-2" />
                        {userData.email}
                      </div>
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-2" />
                        {userData.phone || "Не указан"}
                      </div>
                    </div>
                    {/* Обновить отображение информации о последнем входе в список пользователей */}
                    {/* Найдите блок кода, где отображается last_login и замените его на: */}
                    <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium">Дата регистрации:</span> {formatDate(userData.created_at)}
                      </div>
                      {hasLastLoginColumn && userData.last_login && (
                        <div>
                          <span className="font-medium">Последний вход:</span> {formatDateTime(userData.last_login)}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="Нет пользователей"
                description={
                  users.length > 0
                    ? "Не найдено пользователей, соответствующих выбранным фильтрам"
                    : "Нет зарегистрированных пользователей"
                }
                icon={<User className="h-10 w-10 text-muted-foreground" />}
              />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Диалог с деталями пользователя */}
      <Dialog open={openDetailsDialog} onOpenChange={setOpenDetailsDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Информация о пользователе</DialogTitle>
            <DialogDescription>Детальная информация о пользователе</DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div className="flex items-center justify-center mb-4">
                <div className="h-20 w-20 rounded-full bg-muted flex items-center justify-center">
                  <User className="h-10 w-10 text-muted-foreground" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="font-semibold">Имя:</div>
                <div>{selectedUser.full_name}</div>
                <div className="font-semibold">Email:</div>
                <div>{selectedUser.email}</div>
                <div className="font-semibold">Телефон:</div>
                <div>{selectedUser.phone || "Не указан"}</div>
                <div className="font-semibold">Роль:</div>
                <div>{getRoleText(selectedUser.role)}</div>
                {hasIsActiveColumn && (
                  <>
                    <div className="font-semibold">Статус:</div>
                    <div>
                      {selectedUser.is_active === false ? (
                        <span className="text-red-500">Неактивен</span>
                      ) : (
                        <span className="text-green-500">Активен</span>
                      )}
                    </div>
                  </>
                )}
                {/* Обновить отображение информации о последнем входе в диалоге с деталями пользователя */}
                {/* Найдите блок кода в диалоге, где отображается last_login и замените его на: */}
                <div className="font-semibold">Дата регистрации:</div>
                <div>{formatDate(selectedUser.created_at)}</div>
                {hasLastLoginColumn && selectedUser.last_login && (
                  <>
                    <div className="font-semibold">Последний вход:</div>
                    <div>{formatDateTime(selectedUser.last_login)}</div>
                  </>
                )}
              </div>

              {isLoadingDetails ? (
                <div className="py-4 text-center">
                  <div className="animate-spin h-6 w-6 border-2 border-blue-600 border-t-transparent rounded-full mx-auto"></div>
                  <p className="mt-2 text-sm text-muted-foreground">Загрузка данных...</p>
                </div>
              ) : (
                <>
                  {selectedUser.role === "patient" && patientDetails && (
                    <div className="mt-4 pt-4 border-t">
                      <h4 className="font-semibold mb-2">Данные пациента</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="font-semibold">Дата рождения:</div>
                        <div>{patientDetails.birth_date ? formatDate(patientDetails.birth_date) : "Не указана"}</div>
                        <div className="font-semibold">Пол:</div>
                        <div>{getGenderText(patientDetails.gender)}</div>
                        <div className="font-semibold">Номер страховки:</div>
                        <div>{patientDetails.insurance_number || "Не указан"}</div>
                        <div className="font-semibold">Адрес:</div>
                        <div>{patientDetails.address || "Не указан"}</div>
                      </div>
                    </div>
                  )}

                  {selectedUser.role === "doctor" && doctorDetails && (
                    <div className="mt-4 pt-4 border-t">
                      <h4 className="font-semibold mb-2">Данные врача</h4>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="font-semibold">Специализация:</div>
                        <div>{doctorDetails.specialization}</div>
                        <div className="font-semibold">Кабинет:</div>
                        <div>{doctorDetails.office}</div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setOpenDetailsDialog(false)}>Закрыть</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Диалог подтверждения удаления */}
      <Dialog open={openDeleteDialog} onOpenChange={setOpenDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Удаление пользователя</DialogTitle>
            <DialogDescription>
              Вы уверены, что хотите удалить этого пользователя? Это действие нельзя отменить.
            </DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-2 py-4">
              <p>
                <span className="font-semibold">Имя:</span> {selectedUser.full_name}
              </p>
              <p>
                <span className="font-semibold">Email:</span> {selectedUser.email}
              </p>
              <p>
                <span className="font-semibold">Роль:</span> {getRoleText(selectedUser.role)}
              </p>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setOpenDeleteDialog(false)
                setSelectedUser(null)
              }}
              disabled={isDeleting}
            >
              Отмена
            </Button>
            <Button variant="destructive" onClick={handleDeleteUser} disabled={isDeleting}>
              {isDeleting ? "Удаление..." : "Удалить пользователя"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
