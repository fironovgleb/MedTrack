import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Shield } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex items-center justify-between h-16 mx-auto px-4">
          <Link href="/" className="flex items-center">
            <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
              MedTrack
            </h1>
          </Link>
          <div className="space-x-4">
            <Link href="/login">
              <Button variant="outline">Войти</Button>
            </Link>
            <Link href="/register">
              <Button>Регистрация</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <section className="container mx-auto px-4 py-12">
          <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Вернуться на главную
          </Link>

          <div className="max-w-4xl mx-auto">
            <div className="flex items-center mb-8">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-4xl font-bold">Политика конфиденциальности</h1>
            </div>

            <div className="prose prose-lg max-w-none">
              <p className="text-muted-foreground">Последнее обновление: 1 мая 2023 г.</p>

              <p>
                Настоящая Политика конфиденциальности описывает, как MedTrack ("мы", "нас" или "наш") собирает,
                использует и раскрывает вашу информацию при использовании нашего веб-сайта и платформы для управления
                медицинскими записями и консультациями (далее - "Сервис").
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">1. Информация, которую мы собираем</h2>

              <p>
                Мы собираем несколько типов информации для различных целей, чтобы предоставить и улучшить наш Сервис для
                вас.
              </p>

              <h3 className="text-xl font-semibold mt-6 mb-3">1.1. Личная информация</h3>

              <p>
                При использовании нашего Сервиса мы можем запросить у вас определенную личную информацию, которая может
                быть использована для связи с вами или идентификации вас. Личная информация может включать, но не
                ограничивается следующим:
              </p>

              <ul className="list-disc pl-6 mb-4">
                <li>Имя и фамилия</li>
                <li>Адрес электронной почты</li>
                <li>Номер телефона</li>
                <li>Дата рождения</li>
                <li>Адрес</li>
                <li>Медицинская информация</li>
                <li>Данные страхового полиса</li>
              </ul>

              <h3 className="text-xl font-semibold mt-6 mb-3">1.2. Данные об использовании</h3>

              <p>
                Мы также можем собирать информацию о том, как вы получаете доступ и используете Сервис ("Данные об
                использовании"). Эти Данные об использовании могут включать такую информацию, как тип вашего устройства,
                IP-адрес, тип и версия браузера, страницы нашего Сервиса, которые вы посещаете, время и дата вашего
                посещения, время, проведенное на этих страницах, и другую диагностическую информацию.
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">2. Использование данных</h2>

              <p>MedTrack использует собранные данные для различных целей:</p>

              <ul className="list-disc pl-6 mb-4">
                <li>Для предоставления и поддержания нашего Сервиса</li>
                <li>Для уведомления вас об изменениях в нашем Сервисе</li>
                <li>Для предоставления поддержки клиентов</li>
                <li>Для сбора аналитических данных, которые помогут нам улучшить наш Сервис</li>
                <li>Для мониторинга использования нашего Сервиса</li>
                <li>Для обнаружения, предотвращения и решения технических проблем</li>
                <li>
                  Для выполнения наших обязательств и соблюдения наших прав, вытекающих из любых договоров, заключенных
                  между вами и нами
                </li>
              </ul>

              <h2 className="text-2xl font-semibold mt-8 mb-4">3. Передача данных</h2>

              <p>
                Ваша информация, включая Личные данные, может быть передана и храниться на компьютерах, расположенных за
                пределами вашего региона, провинции, страны или другой государственной юрисдикции, где законы о защите
                данных могут отличаться от законов вашей юрисдикции.
              </p>

              <p>
                Ваше согласие с этой Политикой конфиденциальности, за которым следует предоставление такой информации,
                представляет собой ваше согласие на такую передачу.
              </p>

              <p>
                MedTrack предпримет все разумно необходимые шаги для обеспечения безопасного обращения с вашими данными
                в соответствии с настоящей Политикой конфиденциальности, и никакая передача ваших Личных данных не будет
                осуществляться организации или стране, если не будет обеспечен адекватный контроль, включая безопасность
                ваших данных и другой личной информации.
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">4. Раскрытие данных</h2>

              <h3 className="text-xl font-semibold mt-6 mb-3">4.1. Требования законодательства</h3>

              <p>
                MedTrack может раскрыть ваши Личные данные, если добросовестно полагает, что такое действие необходимо
                для:
              </p>

              <ul className="list-disc pl-6 mb-4">
                <li>Соблюдения юридического обязательства</li>
                <li>Защиты и отстаивания прав или собственности MedTrack</li>
                <li>Предотвращения или расследования возможных правонарушений в связи с Сервисом</li>
                <li>Защиты личной безопасности пользователей Сервиса или общественности</li>
                <li>Защиты от юридической ответственности</li>
              </ul>

              <h2 className="text-2xl font-semibold mt-8 mb-4">5. Безопасность данных</h2>

              <p>
                Безопасность ваших данных важна для нас, но помните, что ни один метод передачи через Интернет или метод
                электронного хранения не является 100% безопасным. Хотя мы стремимся использовать коммерчески приемлемые
                средства для защиты ваших Личных данных, мы не можем гарантировать их абсолютную безопасность.
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">6. Ваши права на защиту данных</h2>

              <p>
                Вы имеете определенные права на защиту данных в соответствии с законодательством. Эти права включают:
              </p>

              <ul className="list-disc pl-6 mb-4">
                <li>Право на доступ, обновление или удаление информации, которую мы имеем о вас</li>
                <li>Право на исправление</li>
                <li>Право на возражение</li>
                <li>Право на ограничение</li>
                <li>Право на переносимость данных</li>
                <li>Право на отзыв согласия</li>
              </ul>

              <h2 className="text-2xl font-semibold mt-8 mb-4">7. Изменения в политике конфиденциальности</h2>

              <p>
                Мы можем обновлять нашу Политику конфиденциальности время от времени. Мы уведомим вас о любых
                изменениях, разместив новую Политику конфиденциальности на этой странице.
              </p>

              <p>
                Мы сообщим вам по электронной почте и/или заметным уведомлением на нашем Сервисе до того, как изменения
                вступят в силу, и обновим дату "последнего обновления" в верхней части этой Политики конфиденциальности.
              </p>

              <p>
                Рекомендуется периодически просматривать эту Политику конфиденциальности на предмет изменений. Изменения
                в этой Политике конфиденциальности вступают в силу, когда они размещаются на этой странице.
              </p>

              <h2 className="text-2xl font-semibold mt-8 mb-4">8. Контактная информация</h2>

              <p>
                Если у вас есть какие-либо вопросы об этой Политике конфиденциальности, пожалуйста, свяжитесь с нами:
              </p>

              <ul className="list-none pl-0 mb-4">
                <li>По электронной почте: privacy@medtrack.ru</li>
                <li>По телефону: +7 (495) 123-45-67</li>
                <li>По почте: г. Москва, ул. Тверская, д. 1, офис 123</li>
              </ul>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Link href="/" className="flex items-center">
                <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">
                  MedTrack
                </h1>
              </Link>
              <p className="mt-4 text-muted-foreground">Управляйте медицинскими записями и консультациями эффективно</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Ссылки</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                    О нас
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                    Контакты
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="text-muted-foreground hover:text-foreground transition-colors">
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Правовая информация</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                    Политика конфиденциальности
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                    Условия использования
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} MedTrack. Все права защищены.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
