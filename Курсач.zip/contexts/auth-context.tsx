"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { useSupabase } from "@/components/supabase-provider"
import { useToast } from "@/components/ui/use-toast"

interface User {
  id: number
  full_name: string
  email: string
  role: "admin" | "doctor" | "patient"
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (userData: RegisterData) => Promise<void>
  logout: () => Promise<void>
}

interface RegisterData {
  fullName: string
  email: string
  password: string
  role: string
  gender?: string
  birthDate?: string
  insuranceNumber?: string
  address?: string
  specialization?: string
  office?: string
  phone?: string
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const router = useRouter()
  const { supabase } = useSupabase()

  useEffect(() => {
    const getUser = async () => {
      try {
        setLoading(true)

        // Безопасное получение сессии с обработкой ошибок
        let sessionData
        try {
          sessionData = await supabase.auth.getSession()
          if (sessionData.error) {
            console.warn("Auth context: Ошибка получения сессии (не критично):", sessionData.error.message)
            setUser(null)
            setLoading(false)
            return
          }
        } catch (err) {
          console.warn("Auth context: Непредвиденная ошибка при получении сессии (не критично):", err)
          setUser(null)
          setLoading(false)
          return
        }

        if (sessionData.data.session?.user) {
          try {
            // Исправление: Проверяем наличие email перед запросом
            const userEmail = sessionData.data.session.user.email
            if (!userEmail) {
              console.warn("Auth context: Email пользователя отсутствует в сессии")
              setUser(null)
              setLoading(false)
              return
            }

            // Исправление: Сначала пробуем с заглавной буквы в имени таблицы
            let userData = null
            const userError = null

            const { data: upperCaseData, error: upperCaseError } = await supabase
              .from("Users")
              .select("*")
              .eq("email", userEmail)
              .maybeSingle()

            if (upperCaseError) {
              console.log("Попытка с заглавной буквой не удалась, пробуем строчную:", upperCaseError)
              const { data: lowerCaseData, error: lowerCaseError } = await supabase
                .from("users")
                .select("*")
                .eq("email", userEmail)
                .maybeSingle()

              if (lowerCaseError) {
                console.error("Ошибка получения данных пользователя:", lowerCaseError)
                setUser(null)
              } else {
                userData = lowerCaseData
              }
            } else {
              userData = upperCaseData
            }

            if (userData) {
              setUser(userData)
            } else {
              setUser(null)
            }
          } catch (err) {
            console.error("Ошибка получения данных пользователя:", err)
            setUser(null)
          }
        } else {
          setUser(null)
        }

        const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, session) => {
          if (session?.user) {
            try {
              // Добавляем небольшую задержку, чтобы дать время на создание записи в базе данных
              await new Promise((resolve) => setTimeout(resolve, 1000))

              // Исправление: Проверяем наличие email перед запросом
              const userEmail = session.user.email
              if (!userEmail) {
                console.warn("Auth context: Email пользователя отсутствует в сессии")
                setUser(null)
                return
              }

              // Исправление: Сначала пробуем с заглавной буквы в имени таблицы
              let userData = null
              const userError = null

              const { data: upperCaseData, error: upperCaseError } = await supabase
                .from("Users")
                .select("*")
                .eq("email", userEmail)
                .maybeSingle()

              if (upperCaseError) {
                console.log("Попытка с заглавной буквой не удалась, пробуем строчную:", upperCaseError)
                const { data: lowerCaseData, error: lowerCaseError } = await supabase
                  .from("users")
                  .select("*")
                  .eq("email", userEmail)
                  .maybeSingle()

                if (lowerCaseError) {
                  console.error("Ошибка получения данных пользователя:", lowerCaseError)
                  setUser(null)
                } else {
                  userData = lowerCaseData
                }
              } else {
                userData = upperCaseData
              }

              if (userData) {
                setUser(userData)
              } else {
                console.log("Пользователь не найден в таблице users после изменения состояния аутентификации")
                setUser(null)
              }
            } catch (err) {
              console.error("Ошибка в изменении состояния аутентификации:", err)
              setUser(null)
            }
          } else {
            setUser(null)
          }
        })

        setLoading(false)

        return () => {
          authListener.subscription.unsubscribe()
        }
      } catch (err) {
        console.error("Непредвиденная ошибка в getUser:", err)
        setLoading(false)
        setUser(null)
      }
    }

    getUser()
  }, [supabase])

  const login = async (email: string, password: string) => {
    try {
      // Проверяем, существует ли пользователь
      // Исправление: Сначала пробуем с заглавной буквы в имени таблицы
      let userData = null
      const userError = null

      const { data: upperCaseData, error: upperCaseError } = await supabase
        .from("Users")
        .select("*")
        .eq("email", email)
        .maybeSingle()

      if (upperCaseError) {
        console.log("Попытка с заглавной буквой не удалась, пробуем строчную:", upperCaseError)
        const { data: lowerCaseData, error: lowerCaseError } = await supabase
          .from("users")
          .select("*")
          .eq("email", email)
          .maybeSingle()

        if (lowerCaseError) {
          throw new Error("Ошибка при поиске пользователя")
        }
        userData = lowerCaseData
      } else {
        userData = upperCaseData
      }

      if (!userData) {
        throw new Error("Пользователь не найден")
      }

      // Вход через Supabase Auth
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        throw new Error(error.message)
      }

      setUser(userData)
      toast({ title: "Вход выполнен успешно" })

      // Перенаправление в зависимости от роли
      router.push(`/${userData.role}/dashboard`)
    } catch (error: any) {
      toast({
        title: "Ошибка входа",
        description: error.message || "Проверьте ваши учетные данные",
        variant: "destructive",
      })
      throw error
    }
  }

  const register = async (userData: RegisterData) => {
    try {
      // Проверяем, существует ли пользователь
      // Исправление: Сначала пробуем с заглавной буквы в имени таблицы
      let existingUser = null
      const checkError = null

      const { data: upperCaseData, error: upperCaseError } = await supabase
        .from("Users")
        .select("*")
        .eq("email", userData.email)
        .maybeSingle()

      if (upperCaseError) {
        console.log("Попытка с заглавной буквой не удалась, пробуем строчную:", upperCaseError)
        const { data: lowerCaseData, error: lowerCaseError } = await supabase
          .from("users")
          .select("*")
          .eq("email", userData.email)
          .maybeSingle()

        if (lowerCaseError && lowerCaseError.code !== "PGRST116") {
          console.error("Ошибка при проверке существующего пользователя:", lowerCaseError)
          throw new Error("Ошибка при проверке существующего пользователя")
        }
        existingUser = lowerCaseData
      } else {
        existingUser = upperCaseData
      }

      if (existingUser) {
        throw new Error("Пользователь с таким email уже существует")
      }

      // Валидация данных
      const validationErrors: Record<string, string> = {}
      let hasErrors = false

      if (!userData.email || !userData.password || !userData.fullName) {
        validationErrors.general = "Пожалуйста, заполните все обязательные поля"
        hasErrors = true
      }

      if (userData.password && userData.password.length < 6) {
        validationErrors.password = "Пароль должен содержать не менее 6 символов"
        hasErrors = true
      }

      if (
        userData.role === "patient" &&
        (!userData.gender || !userData.birthDate || !userData.insuranceNumber || !userData.address)
      ) {
        validationErrors.patient = "Пожалуйста, заполните все поля для пациента"
        hasErrors = true
      }

      if (userData.role === "doctor" && (!userData.specialization || !userData.office)) {
        validationErrors.doctor = "Пожалуйста, заполните все поля для врача"
        hasErrors = true
      }

      // Проверка номера телефона, если он предоставлен
      if (userData.phone && !userData.phone.match(/^\+7 $$\d{3}$$ \d{3}-\d{2}-\d{2}$/)) {
        validationErrors.phone = "Пожалуйста, введите корректный номер телефона в формате +7 (XXX) XXX-XX-XX"
        hasErrors = true
      }

      if (hasErrors) {
        const firstError = Object.values(validationErrors)[0]
        throw new Error(firstError)
      }

      // Регистрация через Supabase Auth
      const { error: authError } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
      })

      if (authError) {
        throw authError
      }

      // Определяем имя таблицы для пользователей
      // Исправление: Проверяем обе версии имени таблицы
      let usersTableName = "Users"
      const { error: testUpperCase } = await supabase.from("Users").select("id").limit(1)
      if (testUpperCase) {
        console.log("Таблица Users не найдена, пробуем users:", testUpperCase)
        const { error: testLowerCase } = await supabase.from("users").select("id").limit(1)
        if (testLowerCase) {
          console.error("Ни одна из таблиц пользователей не найдена:", testLowerCase)
          throw new Error("Ошибка при создании пользователя: таблица не найдена")
        }
        usersTableName = "users"
      }

      // Добавление пользователя в таблицу users
      const { data: createdUser, error: userError } = await supabase
        .from(usersTableName)
        .insert([
          {
            full_name: userData.fullName,
            email: userData.email,
            password_hash: userData.password, // Примечание: в реальном приложении никогда не храните пароли в открытом виде
            role: userData.role,
            phone: userData.phone || null,
          },
        ])
        .select()

      if (userError) {
        console.error("Ошибка создания пользователя:", userError)
        throw new Error("Ошибка при создании пользователя")
      }

      if (!createdUser || createdUser.length === 0) {
        throw new Error("Не удалось создать пользователя")
      }

      const userId = createdUser[0].id

      // Определяем имя таблицы для врачей/пациентов
      // Исправление: Проверяем обе версии имени таблицы для врачей
      if (userData.role === "doctor" && userData.specialization && userData.office) {
        let doctorsTableName = "Doctors"
        const { error: testUpperCase } = await supabase.from("Doctors").select("user_id").limit(1)
        if (testUpperCase) {
          console.log("Таблица Doctors не найдена, пробуем doctors:", testUpperCase)
          const { error: testLowerCase } = await supabase.from("doctors").select("user_id").limit(1)
          if (testLowerCase) {
            console.error("Ни одна из таблиц врачей не найдена:", testLowerCase)
            throw new Error("Ошибка при создании профиля врача: таблица не найдена")
          }
          doctorsTableName = "doctors"
        }

        const { error: doctorError } = await supabase.from(doctorsTableName).insert([
          {
            user_id: userId,
            specialization: userData.specialization,
            office: userData.office,
          },
        ])

        if (doctorError) {
          console.error("Ошибка создания врача:", doctorError)
          throw new Error("Ошибка при создании профиля врача")
        }
      } else if (
        userData.role === "patient" &&
        userData.gender &&
        userData.birthDate &&
        userData.insuranceNumber &&
        userData.address
      ) {
        // Исправление: Проверяем обе версии имени таблицы для пациентов
        let patientsTableName = "Patients"
        const { error: testUpperCase } = await supabase.from("Patients").select("user_id").limit(1)
        if (testUpperCase) {
          console.log("Таблица Patients не найдена, пробуем patients:", testUpperCase)
          const { error: testLowerCase } = await supabase.from("patients").select("user_id").limit(1)
          if (testLowerCase) {
            console.error("Ни одна из таблиц пациентов не найдена:", testLowerCase)
            throw new Error("Ошибка при создании профиля пациента: таблица не найдена")
          }
          patientsTableName = "patients"
        }

        const { error: patientError } = await supabase.from(patientsTableName).insert([
          {
            user_id: userId,
            birth_date: userData.birthDate,
            gender: userData.gender,
            insurance_number: userData.insuranceNumber,
            address: userData.address,
          },
        ])

        if (patientError) {
          console.error("Ошибка создания пациента:", patientError)
          throw new Error("Ошибка при создании профиля пациента")
        }
      }

      toast({ title: "Регистрация успешна" })

      // Добавляем задержку перед перенаправлением, чтобы дать время на обработку данных
      await new Promise((resolve) => setTimeout(resolve, 1500))

      router.push("/login?registered=true")
    } catch (error: any) {
      toast({
        title: "Ошибка регистрации",
        description: error.message || "Пожалуйста, попробуйте снова",
        variant: "destructive",
      })
      throw error
    }
  }

  const logout = async () => {
    try {
      await supabase.auth.signOut()
      setUser(null)
      router.push("/login")
    } catch (error) {
      console.error("Ошибка выхода:", error)
      // Всё равно перенаправляем на страницу входа, даже если есть ошибка
      router.push("/login")
    }
  }

  return <AuthContext.Provider value={{ user, loading, login, register, logout }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth должен использоваться внутри AuthProvider")
  }
  return context
}
