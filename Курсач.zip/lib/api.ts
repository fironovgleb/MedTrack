// Централизованный API для работы с Supabase
import { createClient } from "@supabase/supabase-js"
import type { User, Patient, Doctor, Appointment, MedicalRecord, AuditLog } from "./types"

// Инициализация Supabase клиента
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Аутентификация
export const auth = {
  // Регистрация
  signUp: async (email: string, password: string) => {
    return await supabase.auth.signUp({ email, password })
  },

  // Вход
  signIn: async (email: string, password: string) => {
    return await supabase.auth.signInWithPassword({ email, password })
  },

  // Выход
  signOut: async () => {
    return await supabase.auth.signOut()
  },

  // Получение текущей сессии
  getSession: async () => {
    return await supabase.auth.getSession()
  },
}

// Пользователи
export const users = {
  // Создание пользователя
  create: async (userData: Partial<User>) => {
    return await supabase.from("users").insert([userData]).select()
  },

  // Получение пользователя по email
  getByEmail: async (email: string) => {
    return await supabase.from("users").select("*").eq("email", email).single()
  },

  // Получение пользователя по ID
  getById: async (id: number) => {
    return await supabase.from("users").select("*").eq("id", id).single()
  },

  // Обновление пользователя
  update: async (id: number, userData: Partial<User>) => {
    return await supabase.from("users").update(userData).eq("id", id)
  },

  // Удаление пользователя
  delete: async (id: number) => {
    return await supabase.from("users").delete().eq("id", id)
  },

  // Получение всех пользователей
  getAll: async () => {
    return await supabase.from("users").select("*").order("created_at", { ascending: false })
  },
}

// Пациенты
export const patients = {
  // Создание пациента
  create: async (patientData: Partial<Patient>) => {
    return await supabase.from("patients").insert([patientData]).select()
  },

  // Получение пациента по ID пользователя
  getByUserId: async (userId: number) => {
    return await supabase
      .from("patients")
      .select(
        `
        user_id,
        birth_date,
        gender,
        insurance_number,
        address,
        user:users(
          full_name,
          email,
          phone
        )
      `,
      )
      .eq("user_id", userId)
      .single()
  },

  // Обновление пациента
  update: async (userId: number, patientData: Partial<Patient>) => {
    return await supabase.from("patients").update(patientData).eq("user_id", userId)
  },
}

// Врачи
export const doctors = {
  // Создание врача
  create: async (doctorData: Partial<Doctor>) => {
    return await supabase.from("doctors").insert([doctorData]).select()
  },

  // Получение врача по ID пользователя
  getByUserId: async (userId: number) => {
    return await supabase
      .from("doctors")
      .select(
        `
        user_id,
        specialization,
        office,
        user:users(
          full_name,
          email,
          phone
        )
      `,
      )
      .eq("user_id", userId)
      .single()
  },

  // Получение всех врачей
  getAll: async () => {
    return await supabase.from("doctors").select(`
      user_id,
      specialization,
      office,
      user:users(
        full_name,
        email,
        phone
      )
    `)
  },

  // Обновление врача
  update: async (userId: number, doctorData: Partial<Doctor>) => {
    return await supabase.from("doctors").update(doctorData).eq("user_id", userId)
  },
}

// Записи на приём
export const appointments = {
  // Создание записи на приём
  create: async (appointmentData: Partial<Appointment>) => {
    return await supabase.from("appointments").insert([appointmentData]).select()
  },

  // Получение записи на приём по ID
  getById: async (id: number) => {
    return await supabase
      .from("appointments")
      .select(
        `
        id,
        patient_id,
        doctor_id,
        appointment_time,
        status,
        created_at,
        patient:patients(
          user_id,
          user:users(
            full_name,
            email,
            phone
          )
        ),
        doctor:doctors(
          user_id,
          specialization,
          office,
          user:users(
            full_name
          )
        )
      `,
      )
      .eq("id", id)
      .single()
  },

  // Получение записей на приём для пациента
  getByPatientId: async (patientId: number) => {
    return await supabase
      .from("appointments")
      .select(
        `
        id,
        doctor_id,
        appointment_time,
        status,
        doctor:doctors(
          user_id,
          specialization,
          office,
          user:users(
            full_name
          )
        )
      `,
      )
      .eq("patient_id", patientId)
      .order("appointment_time", { ascending: true })
  },

  // Получение записей на приём для врача
  getByDoctorId: async (doctorId: number) => {
    return await supabase
      .from("appointments")
      .select(
        `
        id,
        patient_id,
        appointment_time,
        status,
        patient:patients(
          user_id,
          user:users(
            full_name,
            phone
          )
        )
      `,
      )
      .eq("doctor_id", doctorId)
      .order("appointment_time", { ascending: true })
  },

  // Обновление статуса записи на приём
  updateStatus: async (id: number, status: "scheduled" | "completed" | "canceled") => {
    return await supabase.from("appointments").update({ status }).eq("id", id)
  },
}

// Медицинские записи
export const medicalRecords = {
  // Создание медицинской записи
  create: async (recordData: Partial<MedicalRecord>) => {
    return await supabase.from("medicalrecords").insert([recordData]).select()
  },

  // Получение медицинской записи по ID
  getById: async (id: number) => {
    return await supabase
      .from("medicalrecords")
      .select(
        `
        id,
        patient_id,
        doctor_id,
        visit_date,
        diagnosis,
        treatment,
        comments,
        patient:patients(
          user_id,
          user:users(
            full_name
          )
        ),
        doctor:doctors(
          user_id,
          specialization,
          user:users(
            full_name
          )
        )
      `,
      )
      .eq("id", id)
      .single()
  },

  // Получение медицинских записей для пациента
  getByPatientId: async (patientId: number) => {
    return await supabase
      .from("medicalrecords")
      .select(
        `
        id,
        doctor_id,
        visit_date,
        diagnosis,
        treatment,
        comments,
        doctor:doctors(
          user_id,
          specialization,
          user:users(
            full_name
          )
        )
      `,
      )
      .eq("patient_id", patientId)
      .order("visit_date", { ascending: false })
  },

  // Получение медицинских записей для врача
  getByDoctorId: async (doctorId: number) => {
    return await supabase
      .from("medicalrecords")
      .select(
        `
        id,
        patient_id,
        visit_date,
        diagnosis,
        treatment,
        patient:patients(
          user_id,
          user:users(
            full_name
          )
        )
      `,
      )
      .eq("doctor_id", doctorId)
      .order("visit_date", { ascending: false })
  },
}

// Аудит
export const auditLogs = {
  // Создание записи аудита
  create: async (logData: Partial<AuditLog>) => {
    return await supabase.from("auditlogs").insert([logData])
  },

  // Получение всех записей аудита
  getAll: async () => {
    return await supabase
      .from("auditlogs")
      .select(
        `
        id,
        user_id,
        action,
        target_type,
        target_id,
        timestamp,
        user:users(
          full_name,
          role
        )
      `,
      )
      .order("timestamp", { ascending: false })
  },
}
