// Типы данных для всего приложения

// Пользователи
export interface User {
  id: number
  full_name: string
  email: string
  role: "patient" | "doctor" | "admin"
  phone_number?: string
  created_at: string
}

// Пациенты
export interface Patient {
  user_id: number
  birth_date?: string
  gender?: "male" | "female" | "other"
  insurance_number?: string
  address?: string
  user?: User
}

// Врачи
export interface Doctor {
  user_id: number
  specialization: string
  office_number: string
  user?: User
}

// Записи на приём
export interface Appointment {
  id: number
  patient_id: number
  doctor_id: number
  appointment_time: string
  status: "scheduled" | "completed" | "canceled"
  created_at: string
  patient?: Patient & { user: User }
  doctor?: Doctor & { user: User }
}

// Медицинские записи
export interface MedicalRecord {
  id: number
  patient_id: number
  doctor_id: number
  visit_date: string
  diagnosis: string
  treatment: string
  comments?: string
  patient?: Patient & { user: User }
  doctor?: Doctor & { user: User }
}

// Аудит
export interface AuditLog {
  id: number
  user_id: number
  action: string
  target_type: string
  target_id?: number
  timestamp: string
  user?: User
}
