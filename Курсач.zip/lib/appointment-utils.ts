import type { Appointment } from "./types"

// Format date in a consistent way across the application
export function formatAppointmentDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })
}

// Format time in a consistent way across the application
export function formatAppointmentTime(dateString: string): string {
  return new Date(dateString).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  })
}

// Format date and time together
export function formatAppointmentDateTime(dateString: string): string {
  return `${formatAppointmentDate(dateString)} в ${formatAppointmentTime(dateString)}`
}

// Check if appointment is today
export function isAppointmentToday(dateString: string): boolean {
  const appointmentDate = new Date(dateString)
  const today = new Date()
  return (
    appointmentDate.getDate() === today.getDate() &&
    appointmentDate.getMonth() === today.getMonth() &&
    appointmentDate.getFullYear() === today.getFullYear()
  )
}

// Check if appointment is soon (within the next hour)
export function isAppointmentSoon(dateString: string): boolean {
  const appointmentTime = new Date(dateString)
  const now = new Date()
  const diffMs = appointmentTime.getTime() - now.getTime()
  const diffHours = diffMs / (1000 * 60 * 60)
  return diffHours > 0 && diffHours <= 1
}

// Check if appointment is in the past
export function isAppointmentPast(dateString: string): boolean {
  const appointmentTime = new Date(dateString)
  const now = new Date()
  return appointmentTime < now
}

// Get status text based on status code
export function getAppointmentStatusText(status: string): string {
  switch (status) {
    case "scheduled":
      return "Запланирован"
    case "completed":
      return "Завершен"
    case "canceled":
      return "Отменен"
    default:
      return status
  }
}

// Get status color based on status code
export function getAppointmentStatusColor(status: string): string {
  switch (status) {
    case "scheduled":
      return "text-blue-600 border-blue-600"
    case "completed":
      return "text-green-600 border-green-600"
    case "canceled":
      return "text-red-600 border-red-600"
    default:
      return "text-gray-600 border-gray-600"
  }
}

// Check if user has permission to view appointment
export function canViewAppointment(appointment: Appointment, userId: number, userRole: string): boolean {
  if (userRole === "admin") return true
  if (userRole === "doctor" && appointment.doctor_id === userId) return true
  if (userRole === "patient" && appointment.patient_id === userId) return true
  return false
}

// Check if user has permission to modify appointment
export function canModifyAppointment(appointment: Appointment, userId: number, userRole: string): boolean {
  // Only allow modification of scheduled appointments
  if (appointment.status !== "scheduled") return false

  if (userRole === "admin") return true
  if (userRole === "doctor" && appointment.doctor_id === userId) return true

  // Patients can only modify their own appointments and only if they're not too soon
  if (userRole === "patient" && appointment.patient_id === userId) {
    const appointmentTime = new Date(appointment.appointment_time)
    const now = new Date()
    const diffMs = appointmentTime.getTime() - now.getTime()
    const diffHours = diffMs / (1000 * 60 * 60)

    // Allow modification only if appointment is more than 2 hours away
    return diffHours > 2
  }

  return false
}
