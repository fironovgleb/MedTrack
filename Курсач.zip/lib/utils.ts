import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

// Утилита для объединения классов Tailwind
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Форматирование даты
export function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return "Не указана"

  try {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    })
  } catch (error) {
    return "Некорректная дата"
  }
}

// Форматирование времени
export function formatTime(dateString: string | null | undefined): string {
  if (!dateString) return ""

  try {
    return new Date(dateString).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
    })
  } catch (error) {
    return ""
  }
}

// Форматирование даты и времени
export function formatDateTime(dateString: string | null | undefined): string {
  if (!dateString) return "Не указана"

  try {
    return `${formatDate(dateString)}, ${formatTime(dateString)}`
  } catch (error) {
    return "Некорректная дата"
  }
}

// Получение текста для пола
export function getGenderText(gender: string | null | undefined): string {
  if (!gender) return "Не указан"
  switch (gender) {
    case "male":
      return "Мужской"
    case "female":
      return "Женский"
    default:
      return "Другой"
  }
}

// Получение текста для роли
export function getRoleText(role: string | null | undefined): string {
  if (!role) return ""
  switch (role) {
    case "admin":
      return "Администратор"
    case "doctor":
      return "Врач"
    case "patient":
      return "Пациент"
    default:
      return role
  }
}

// Получение текста для статуса записи
export function getAppointmentStatusText(status: string | null | undefined): string {
  if (!status) return ""
  switch (status) {
    case "scheduled":
      return "Запланирован"
    case "completed":
      return "Завершен"
    case "canceled":
      return "Отменен"
    default:
      return status
  }
}

// Получение цвета для статуса записи
export function getAppointmentStatusColor(status: string | null | undefined): string {
  if (!status) return ""
  switch (status) {
    case "scheduled":
      return "text-blue-600"
    case "completed":
      return "text-green-600"
    case "canceled":
      return "text-red-600"
    default:
      return ""
  }
}

// Получение возраста из даты рождения
export function getAgeFromBirthDate(birthDate: string | null | undefined): string {
  if (!birthDate) return "Не указан"

  try {
    const today = new Date()
    const birth = new Date(birthDate)

    // Проверка на валидность даты
    if (isNaN(birth.getTime())) {
      return "Некорректная дата"
    }

    let age = today.getFullYear() - birth.getFullYear()
    const monthDiff = today.getMonth() - birth.getMonth()

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--
    }

    // Склонение слова "год"
    let yearText = "лет"
    if (age % 10 === 1 && age % 100 !== 11) {
      yearText = "год"
    } else if ([2, 3, 4].includes(age % 10) && ![12, 13, 14].includes(age % 100)) {
      yearText = "года"
    }

    return `${age} ${yearText}`
  } catch (error) {
    return "Не указан"
  }
}

// Форматирование номера страхового полиса
export function formatInsuranceNumber(value: string): string {
  // Удаляем все нецифровые символы
  const cleaned = value.replace(/\D/g, "")

  // Ограничиваем длину до 16 цифр
  const limited = cleaned.substring(0, 16)

  // Форматируем номер в группы по 4 цифры
  let formatted = ""
  for (let i = 0; i < limited.length; i++) {
    if (i > 0 && i % 4 === 0) {
      formatted += " "
    }
    formatted += limited[i]
  }

  return formatted
}

// Получение минимальной даты (сегодня)
export function getMinDate(): string {
  const today = new Date()
  return today.toISOString().split("T")[0]
}

// Получение максимальной даты (через год)
export function getMaxDate(): string {
  const today = new Date()
  today.setFullYear(today.getFullYear() + 1)
  return today.toISOString().split("T")[0]
}

// Проверка, является ли дата сегодняшней
export function isToday(dateString: string): boolean {
  try {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    const date = new Date(dateString)

    return date >= today && date < tomorrow
  } catch (error) {
    return false
  }
}

// Проверка, является ли дата прошедшей
export function isPastDate(dateString: string): boolean {
  try {
    return new Date(dateString) < new Date()
  } catch (error) {
    return false
  }
}

// Безопасное получение значения из объекта
export function safeGet(obj: any, path: string, defaultValue: any = undefined): any {
  try {
    const keys = path.split(".")
    let result = obj

    for (const key of keys) {
      if (result === undefined || result === null) {
        return defaultValue
      }
      result = result[key]
    }

    return result === undefined ? defaultValue : result
  } catch (error) {
    return defaultValue
  }
}
